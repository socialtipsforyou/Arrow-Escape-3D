package com.example

import android.app.Activity
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ads.UnityAdsManager
import com.example.ads.UnityBannerAdView
import com.example.data.AuthScreenMode
import com.example.data.AuthUiState
import com.example.data.FirebaseAuthProfileManager
import com.example.data.RedeemOption
import com.example.data.RedemptionRecord
import com.example.domain.GameManager
import com.example.domain.ScreenDestination
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AuthPortalScreen
import com.example.ui.screens.GameplayScreen
import com.example.ui.screens.HowToPlayScreen
import com.example.ui.screens.LevelSelectScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.UnifiedUserAccountBar
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Initialize Unity Ads once in TEST MODE for Game ID 800387173
        UnityAdsManager.initialize(this)

        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val context = LocalContext.current
                    val authProfileManager = remember {
                        FirebaseAuthProfileManager(context.applicationContext)
                    }
                    val authState by authProfileManager.authState.collectAsState()
                    val gameManager: GameManager = viewModel(
                        factory = GameManager.provideFactory(context)
                    )

                    SideEffect {
                        gameManager.onAuthenticatedLevelCompleted = { completedLevelNumber ->
                            val awarded = authProfileManager.recordCompletedLevelAndAwardCoins(completedLevelNumber)
                            awarded
                        }
                        gameManager.onSafeGameplayMomentForInterstitial = {
                            if (UnityAdsManager.isInterstitialEligible() && UnityAdsManager.isInterstitialLoaded.value) {
                                UnityAdsManager.showInterstitialIfAppropriate(this@MainActivity)
                            }
                        }
                    }

                    val onWatchRewardedAdForCoins: () -> Unit = {
                        val currentUid = (authState as? AuthUiState.AuthenticatedUser)?.uid
                            ?: (authState as? AuthUiState.AuthenticatedAdmin)?.uid
                        if (currentUid.isNullOrBlank()) {
                            gameManager.showBannerMessage("Please log in to earn and redeem coins!")
                        } else {
                            UnityAdsManager.showRewardedAd(
                                activity = this@MainActivity,
                                onRewardGranted = { token ->
                                    val awarded = authProfileManager.recordRewardedAdAndAwardCoins(token)
                                    if (awarded > 0) {
                                        gameManager.awardDirectCoins(awarded, "+$awarded Coins (Ad Reward)")
                                        gameManager.markRewardedAdClaimedThisLevel()
                                    }
                                },
                                onAdClosed = {}
                            )
                        }
                    }

                    val onNextLevelWithInterstitial: () -> Unit = {
                        UnityAdsManager.showInterstitialIfAppropriate(
                            activity = this@MainActivity,
                            onAdDismissed = {
                                gameManager.startNextLevel()
                            }
                        )
                    }

                    val onWatchRewardedAdThenNextLevel: () -> Unit = {
                        val currentUid = (authState as? AuthUiState.AuthenticatedUser)?.uid
                            ?: (authState as? AuthUiState.AuthenticatedAdmin)?.uid
                        if (currentUid.isNullOrBlank()) {
                            gameManager.showBannerMessage("Please log in to earn and redeem coins!")
                            onNextLevelWithInterstitial()
                        } else {
                            UnityAdsManager.showRewardedAd(
                                activity = this@MainActivity,
                                onRewardGranted = { token ->
                                    val awarded = authProfileManager.recordRewardedAdAndAwardCoins(token)
                                    if (awarded > 0) {
                                        gameManager.awardDirectCoins(awarded, "+$awarded Coins (Ad Reward)")
                                        gameManager.markRewardedAdClaimedThisLevel()
                                    }
                                },
                                onAdClosed = {
                                    onNextLevelWithInterstitial()
                                }
                            )
                        }
                    }

                    val onWatchRewardedAdForHint: () -> Unit = {
                        val currentUid = (authState as? AuthUiState.AuthenticatedUser)?.uid
                            ?: (authState as? AuthUiState.AuthenticatedAdmin)?.uid
                        if (currentUid.isNullOrBlank()) {
                            gameManager.showBannerMessage("Please log in to earn and redeem coins!")
                            gameManager.useHint()
                        } else {
                            UnityAdsManager.showRewardedAd(
                                activity = this@MainActivity,
                                onRewardGranted = { token ->
                                    val awarded = authProfileManager.recordRewardedAdAndAwardCoins(token)
                                    if (awarded > 0) {
                                        gameManager.awardDirectCoins(awarded, "+$awarded Coins (Ad Reward)")
                                    }
                                },
                                onAdClosed = {
                                    gameManager.useHint()
                                }
                            )
                        }
                    }

                    val onCheckInterstitialBeforeHint: ((proceed: () -> Unit) -> Unit) = { proceed ->
                        if (UnityAdsManager.isInterstitialEligible() && UnityAdsManager.isInterstitialLoaded.value) {
                            UnityAdsManager.showInterstitialIfAppropriate(
                                activity = this@MainActivity,
                                onAdDismissed = {
                                    proceed()
                                }
                            )
                        } else {
                            proceed()
                        }
                    }

                    val onRewardedAdExtraLife: () -> Unit = {
                        UnityAdsManager.showRewardedAd(
                            activity = this@MainActivity,
                            onRewardGranted = { _ ->
                                gameManager.restoreHeartFromAd()
                            },
                            onAdClosed = {}
                        )
                    }

                    val isLocalUnitTest = remember {
                        Build.FINGERPRINT.equals("robolectric", ignoreCase = true)
                    }

                    when (val currentAuth = authState) {
                        is AuthUiState.AuthenticatedAdmin -> {
                            val profileCoins = currentAuth.profile?.coins ?: 0L
                            val profileCompleted = currentAuth.profile?.completedLevels ?: 0L
                            val profileRewarded = currentAuth.profile?.rewardedLevelIds ?: emptySet()
                            LaunchedEffect(
                                currentAuth.uid,
                                currentAuth.isPlayingGame,
                                profileCoins,
                                profileCompleted,
                                profileRewarded
                            ) {
                                if (currentAuth.isPlayingGame) {
                                    gameManager.bindAuthenticatedProfile(
                                        uid = currentAuth.uid,
                                        coins = profileCoins,
                                        completedLevelsCount = profileCompleted,
                                        rewardedLevelIds = profileRewarded
                                    )
                                }
                            }

                            if (currentAuth.isPlayingGame) {
                                BackHandler {
                                    authProfileManager.returnToAccountPanel()
                                }
                                ArrowEscape3DApp(
                                    accountDisplayName = currentAuth.displayName,
                                    accountEmail = currentAuth.email,
                                    accountCoins = currentAuth.profile?.coins,
                                    accountCompletedLevels = currentAuth.profile?.completedLevels,
                                    rewardFeedback = currentAuth.lastRewardFeedback,
                                    redemptionHistory = currentAuth.redemptionRequests,
                                    onSubmitRedemption = { option, payoutDetails ->
                                        authProfileManager.submitRedemptionRequest(option, payoutDetails)
                                    },
                                    onOpenAccountPanelClicked = {
                                        authProfileManager.returnToAccountPanel()
                                    },
                                    onSignOutClicked = {
                                        gameManager.clearAuthenticatedSession()
                                        authProfileManager.signOut(context)
                                    },
                                    onWatchRewardedAdCoins = onWatchRewardedAdForCoins,
                                    onNextLevelWithInterstitial = onNextLevelWithInterstitial,
                                    onWatchRewardedAdThenNextLevel = onWatchRewardedAdThenNextLevel,
                                    onWatchRewardedAdForHint = onWatchRewardedAdForHint,
                                    onCheckInterstitialBeforeHint = onCheckInterstitialBeforeHint,
                                    onRewardedAdLife = onRewardedAdExtraLife,
                                    gameManager = gameManager
                                )
                            } else {
                                AdminPanelScreen(
                                    adminEmail = currentAuth.email,
                                    usersList = currentAuth.usersList,
                                    redemptionRequests = currentAuth.redemptionRequests,
                                    isLoadingUsers = currentAuth.isLoadingUsers,
                                    errorMessage = currentAuth.adminErrorMessage,
                                    onRefreshUsers = {
                                        authProfileManager.refreshAdminUsersList()
                                    },
                                    onOpenGamePreview = {
                                        authProfileManager.openGame(openToSettings = false)
                                    },
                                    onLogoutClicked = {
                                        gameManager.clearAuthenticatedSession()
                                        authProfileManager.signOut(context)
                                    }
                                )
                            }
                        }

                        is AuthUiState.AuthenticatedUser -> {
                            val profileCoins = currentAuth.profile?.coins ?: 0L
                            val profileCompleted = currentAuth.profile?.completedLevels ?: 0L
                            val profileRewarded = currentAuth.profile?.rewardedLevelIds ?: emptySet()

                            LaunchedEffect(
                                currentAuth.uid,
                                profileCoins,
                                profileCompleted,
                                profileRewarded
                            ) {
                                gameManager.bindAuthenticatedProfile(
                                    uid = currentAuth.uid,
                                    coins = profileCoins,
                                    completedLevelsCount = profileCompleted,
                                    rewardedLevelIds = profileRewarded
                                )
                            }

                            LaunchedEffect(currentAuth.openGameToSettings) {
                                if (currentAuth.openGameToSettings) {
                                    gameManager.navigateTo(ScreenDestination.SETTINGS)
                                }
                            }

                            // Normal user enters the single unified main user + game screen directly
                            // with no separate intermediate "Play Game" screen.
                            ArrowEscape3DApp(
                                accountDisplayName = currentAuth.displayName,
                                accountEmail = currentAuth.email,
                                accountCoins = currentAuth.profile?.coins,
                                accountCompletedLevels = currentAuth.profile?.completedLevels,
                                rewardFeedback = currentAuth.lastRewardFeedback,
                                redemptionHistory = currentAuth.redemptionHistory,
                                onSubmitRedemption = { option, payoutDetails ->
                                    authProfileManager.submitRedemptionRequest(option, payoutDetails)
                                },
                                onOpenAccountPanelClicked = null,
                                onSignOutClicked = {
                                    gameManager.clearAuthenticatedSession()
                                    authProfileManager.signOut(context)
                                },
                                onWatchRewardedAdCoins = onWatchRewardedAdForCoins,
                                onNextLevelWithInterstitial = onNextLevelWithInterstitial,
                                onWatchRewardedAdThenNextLevel = onWatchRewardedAdThenNextLevel,
                                onWatchRewardedAdForHint = onWatchRewardedAdForHint,
                                onCheckInterstitialBeforeHint = onCheckInterstitialBeforeHint,
                                onRewardedAdLife = onRewardedAdExtraLife,
                                gameManager = gameManager
                            )
                        }

                        is AuthUiState.Unauthenticated -> {
                            if (isLocalUnitTest) {
                                ArrowEscape3DApp(gameManager = gameManager)
                            } else {
                                LaunchedEffect(Unit) {
                                    gameManager.clearAuthenticatedSession()
                                }
                                AuthPortalScreen(
                                    mode = currentAuth.mode,
                                    isLoading = currentAuth.isLoading,
                                    errorMessage = currentAuth.errorMessage,
                                    infoMessage = currentAuth.infoMessage,
                                    onSwitchMode = { newMode ->
                                        authProfileManager.setAuthScreenMode(newMode)
                                    },
                                    onLoginWithEmail = { email, password ->
                                        authProfileManager.signInWithEmail(email, password)
                                    },
                                    onSignUpWithEmail = { name, email, password, confirmPassword ->
                                        authProfileManager.signUpWithEmail(
                                            nameInput = name,
                                            emailInput = email,
                                            passwordInput = password,
                                            confirmPasswordInput = confirmPassword
                                        )
                                    },
                                    onForgotPassword = { email ->
                                        authProfileManager.sendPasswordReset(email)
                                    },
                                    onGoogleSignInClicked = {
                                        val activity = context as? Activity
                                        if (activity != null) {
                                            authProfileManager.signInWithGoogle(activity)
                                        }
                                    }
                                )
                            }
                        }

                        is AuthUiState.CheckingSession -> {
                            if (isLocalUnitTest) {
                                ArrowEscape3DApp(gameManager = gameManager)
                            } else {
                                AuthPortalScreen(
                                    mode = AuthScreenMode.LOGIN,
                                    isLoading = true,
                                    errorMessage = null,
                                    infoMessage = null,
                                    onSwitchMode = {},
                                    onLoginWithEmail = { _, _ -> },
                                    onSignUpWithEmail = { _, _, _, _ -> },
                                    onForgotPassword = {},
                                    onGoogleSignInClicked = {}
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ArrowEscape3DApp(
    accountDisplayName: String? = null,
    accountEmail: String? = null,
    accountCoins: Long? = null,
    accountCompletedLevels: Long? = null,
    rewardFeedback: String? = null,
    redemptionHistory: List<RedemptionRecord> = emptyList(),
    onSubmitRedemption: ((RedeemOption, String) -> Result<RedemptionRecord>)? = null,
    onOpenAccountPanelClicked: (() -> Unit)? = null,
    onSignOutClicked: (() -> Unit)? = null,
    onWatchRewardedAdCoins: (() -> Unit)? = null,
    onNextLevelWithInterstitial: (() -> Unit)? = null,
    onWatchRewardedAdThenNextLevel: (() -> Unit)? = null,
    onWatchRewardedAdForHint: (() -> Unit)? = null,
    onCheckInterstitialBeforeHint: (((proceed: () -> Unit) -> Unit))? = null,
    onRewardedAdLife: (() -> Unit)? = null,
    gameManager: GameManager = viewModel(
        factory = GameManager.provideFactory(LocalContext.current)
    )
) {
    val uiState by gameManager.uiState.collectAsStateWithLifecycle()
    val hasTopAccountBar = !accountEmail.isNullOrBlank()

    Column(modifier = Modifier.fillMaxSize()) {
        if (hasTopAccountBar) {
            UnifiedUserAccountBar(
                displayName = accountDisplayName ?: "Player",
                email = accountEmail ?: "",
                coins = accountCoins ?: uiState.coins.toLong(),
                completedLevels = accountCompletedLevels ?: uiState.completedLevels.size.toLong(),
                rewardFeedback = rewardFeedback,
                redemptionHistory = redemptionHistory,
                onSubmitRedemption = onSubmitRedemption,
                onWatchRewardedAd = onWatchRewardedAdCoins,
                onSettingsClicked = {
                    if (uiState.screen == ScreenDestination.SETTINGS) {
                        gameManager.navigateTo(ScreenDestination.PLAYING)
                    } else {
                        gameManager.navigateTo(ScreenDestination.SETTINGS)
                    }
                },
                onLogoutClicked = {
                    onSignOutClicked?.invoke()
                }
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (uiState.screen) {
                ScreenDestination.MAIN_MENU -> {
                    MainMenuScreen(
                        uiState = uiState,
                        onPlayClicked = {
                            gameManager.startLevel(uiState.currentLevelNumber)
                        },
                        onPlaySpecificMode = { mode ->
                            gameManager.startLevel(uiState.currentLevelNumber, forcedMode = mode)
                        },
                        onNavigate = { dest ->
                            gameManager.navigateTo(dest)
                        },
                        onWatchRewardedAd = {
                            onWatchRewardedAdCoins?.invoke()
                        },
                        hasTopAccountBar = hasTopAccountBar
                    )
                }

                ScreenDestination.PLAYING -> {
                    GameplayScreen(
                        uiState = uiState,
                        cameraController = gameManager.cameraController,
                        inputManager = gameManager.inputManager,
                        onBlockTapped = { blockId -> gameManager.onBlockTapped(blockId) },
                        onUseHint = { gameManager.useHint() },
                        onUndo = { gameManager.undoLastMove() },
                        onRestart = { gameManager.restartCurrentLevel() },
                        onTogglePause = { gameManager.togglePause() },
                        onToggleGridPegs = { gameManager.toggleGridPegs() },
                        onRotateCamera = { dYaw, dPitch -> gameManager.rotateCamera(dYaw, dPitch) },
                        onZoomCamera = { factor -> gameManager.zoomCamera(factor) },
                        onResetCamera = { gameManager.resetCamera() },
                        onToggle3DView = { gameManager.toggleCamera3DPreset() },
                        onNextLevel = {
                            onNextLevelWithInterstitial?.invoke() ?: gameManager.startNextLevel()
                        },
                        onContinueWithCoins = { gameManager.continueWithCoins() },
                        onRewardedAdExtraLife = {
                            onRewardedAdLife?.invoke() ?: gameManager.requestRewardedAdForExtraLife()
                        },
                        onRewardedAdDoubleCoins = {
                            onWatchRewardedAdCoins?.invoke() ?: gameManager.requestRewardedAdForDoubleCoins()
                        },
                        onWatchRewardedAdThenNextLevel = {
                            onWatchRewardedAdThenNextLevel?.invoke()
                        },
                        onWatchRewardedAdForHint = {
                            onWatchRewardedAdForHint?.invoke()
                        },
                        onCheckInterstitialBeforeHint = { proceed ->
                            onCheckInterstitialBeforeHint?.invoke(proceed) ?: proceed()
                        },
                        onSoundToggle = { gameManager.setSoundEnabled(it) },
                        onMusicToggle = { gameManager.setMusicEnabled(it) },
                        onVibrationToggle = { gameManager.setVibrationEnabled(it) },
                        onNavigate = { dest -> gameManager.navigateTo(dest) },
                        hasTopAccountBar = hasTopAccountBar
                    )
                }

                ScreenDestination.LEVEL_SELECT -> {
                    LevelSelectScreen(
                        uiState = uiState,
                        onSelectLevel = { levelNum ->
                            gameManager.selectLevelFromMap(levelNum)
                        },
                        onChangePage = { page ->
                            gameManager.setLevelSelectPage(page)
                        },
                        onNavigate = { dest ->
                            gameManager.navigateTo(dest)
                        }
                    )
                }

                ScreenDestination.SETTINGS -> {
                    SettingsScreen(
                        uiState = uiState,
                        onSoundToggle = { gameManager.setSoundEnabled(it) },
                        onMusicToggle = { gameManager.setMusicEnabled(it) },
                        onVibrationToggle = { gameManager.setVibrationEnabled(it) },
                        onGraphicsQualitySelected = { gameManager.setGraphicsQuality(it) },
                        onResetProgressConfirmed = { gameManager.resetAllProgress() },
                        onNavigate = { dest -> gameManager.navigateTo(dest) },
                        accountDisplayName = accountDisplayName,
                        accountEmail = accountEmail,
                        onOpenAccountPanelClicked = onOpenAccountPanelClicked,
                        onSignOutClicked = onSignOutClicked
                    )
                }

                ScreenDestination.HOW_TO_PLAY -> {
                    HowToPlayScreen(
                        onStartPlaying = {
                            gameManager.startLevel(uiState.currentLevelNumber)
                        },
                        onNavigate = { dest ->
                            gameManager.navigateTo(dest)
                        }
                    )
                }
            }
        }

        // Safe, non-intrusive Banner Ad placed at the bottom without covering the 3D board or controls
        UnityBannerAdView()
    }
}
