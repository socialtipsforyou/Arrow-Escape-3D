package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.UnityAdsManager
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BrightBlue
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.HeartRed

/**
 * Developer-Only Unity Ads Debug Status Component.
 *
 * Displays the exact requested lifecycle fields:
 * - Initialization: READY / FAILED / INITIALIZING
 * - Test Mode: ON / OFF
 * - Rewarded: LOADED / NOT LOADED
 * - Interstitial: LOADED / NOT LOADED
 * - Banner: LOADED / NOT LOADED
 * - Last Ad Error: [exact error]
 * - Last Ad Event: [exact event]
 */
@Composable
fun UnityAdsDebugStatusCard(
    modifier: Modifier = Modifier,
    onTestRewarded: (() -> Unit)? = null,
    onTestInterstitial: (() -> Unit)? = null,
    onForceReload: (() -> Unit)? = null
) {
    val initStatus by UnityAdsManager.initStatus.collectAsState()
    val isRewardedLoaded by UnityAdsManager.isRewardedLoaded.collectAsState()
    val isInterstitialLoaded by UnityAdsManager.isInterstitialLoaded.collectAsState()
    val isBannerLoaded by UnityAdsManager.isBannerLoaded.collectAsState()
    val lastError by UnityAdsManager.lastAdError.collectAsState()
    val lastEvent by UnityAdsManager.lastAdEvent.collectAsState()
    val networkStatus by UnityAdsManager.networkStatus.collectAsState()
    val recentEvents by UnityAdsManager.recentEvents.collectAsState()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("unity_ads_debug_status_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF0F1B2D)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.BugReport,
                        contentDescription = "Unity Ads Diagnostics",
                        tint = AccentGold,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Unity Ads Debug Status",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (initStatus == "READY") EmeraldSuccess.copy(alpha = 0.2f) else HeartRed.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = if (initStatus == "READY") "READY" else if (initStatus.startsWith("INITIALIZING")) "INIT..." else "FAILED",
                        color = if (initStatus == "READY") EmeraldSuccess else HeartRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Diagnostic Key-Value Pairs
            val displayInitStatus = when {
                initStatus.startsWith("READY") -> "READY"
                initStatus.startsWith("INITIALIZING") -> "INITIALIZING..."
                else -> "FAILED"
            }
            DebugStatusRow(
                label = "Initialization:",
                value = displayInitStatus,
                isPositive = initStatus.startsWith("READY")
            )

            DebugStatusRow(
                label = "Test Mode:",
                value = UnityAdsManager.getTestModeString(),
                isPositive = UnityAdsManager.IS_TEST_MODE
            )

            DebugStatusRow(
                label = "Rewarded:",
                value = if (isRewardedLoaded) "LOADED" else "NOT LOADED",
                isPositive = isRewardedLoaded
            )

            DebugStatusRow(
                label = "Interstitial:",
                value = if (isInterstitialLoaded) "LOADED" else "NOT LOADED",
                isPositive = isInterstitialLoaded
            )

            DebugStatusRow(
                label = "Banner:",
                value = if (isBannerLoaded) "LOADED" else "NOT LOADED",
                isPositive = isBannerLoaded
            )

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.12f))
            Spacer(modifier = Modifier.height(8.dp))

            // Config / Identifiers
            Text(
                text = "Game ID: ${UnityAdsManager.GAME_ID} • Network: $networkStatus",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp
            )
            Text(
                text = "Rewarded: ${UnityAdsManager.PLACEMENT_REWARDED} (Active: ${UnityAdsManager.activeLoadedRewardedPlacement})",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp
            )
            Text(
                text = "Interstitial: ${UnityAdsManager.PLACEMENT_INTERSTITIAL} (Active: ${UnityAdsManager.activeLoadedInterstitialPlacement})",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp
            )
            Text(
                text = "Banner: ${UnityAdsManager.PLACEMENT_BANNER}",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.12f))
            Spacer(modifier = Modifier.height(8.dp))

            // Last Ad Error
            Text(
                text = "Last Ad Error:",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = lastError,
                color = if (lastError == "None") EmeraldSuccess else HeartRed,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
                    .testTag("debug_last_ad_error")
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Last Ad Event
            Text(
                text = "Last Ad Event:",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = lastEvent,
                color = AccentGold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
                    .testTag("debug_last_ad_event")
            )

            // Diagnostic Action Buttons
            if (onTestRewarded != null || onTestInterstitial != null || onForceReload != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (onForceReload != null) {
                        OutlinedButton(
                            onClick = onForceReload,
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Reload", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (onTestRewarded != null) {
                        Button(
                            onClick = onTestRewarded,
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentGold, contentColor = Color(0xFF0F1B2D))
                        ) {
                            Text("Test Rewarded", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (onTestInterstitial != null) {
                        Button(
                            onClick = onTestInterstitial,
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrightBlue, contentColor = Color.White)
                        ) {
                            Text("Test Interstitial", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Recent Event Log (Last 5)
            if (recentEvents.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Recent Ad Log:",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                        .background(Color.Black.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                        .padding(6.dp)
                ) {
                    recentEvents.take(5).forEach { entry ->
                        Text(
                            text = entry,
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 2
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DebugStatusRow(
    label: String,
    value: String,
    isPositive: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            color = if (isPositive) EmeraldSuccess else HeartRed,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace
        )
    }
}

/**
 * Developer-Only Floating Diagnostic Dialog.
 * Can be opened by tapping the discreet debug button in the UI.
 */
@Composable
fun UnityAdsDebugDialog(
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    AlertDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = {
            Button(
                onClick = onDismissRequest,
                colors = ButtonDefaults.buttonColors(containerColor = BrightBlue)
            ) {
                Text("Close", fontWeight = FontWeight.Bold)
            }
        },
        title = {
            Text("Unity Ads Diagnostics", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                UnityAdsDebugStatusCard(
                    onTestRewarded = {
                        if (activity != null) {
                            UnityAdsManager.showRewardedAd(
                                activity = activity,
                                onRewardGranted = {},
                                onAdClosed = {}
                            )
                        }
                    },
                    onTestInterstitial = {
                        if (activity != null) {
                            UnityAdsManager.showInterstitialIfAppropriate(
                                activity = activity,
                                onAdDismissed = {}
                            )
                        }
                    },
                    onForceReload = {
                        UnityAdsManager.preloadRewardedAd()
                        UnityAdsManager.preloadInterstitialAd()
                    }
                )
            }
        }
    )
}

/**
 * Discreet Developer Debug Pill Button.
 * Can be shown on non-production builds for instant access to Unity Ads Diagnostics.
 */
@Composable
fun UnityAdsDebugFloatingPill(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = Color(0xCC0D1B2A),
        border = androidx.compose.foundation.BorderStroke(1.dp, AccentGold.copy(alpha = 0.6f)),
        shadowElevation = 4.dp,
        modifier = modifier.testTag("unity_ads_debug_pill")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.BugReport,
                contentDescription = "Unity Ads Diagnostics",
                tint = AccentGold,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "ADS DEBUG",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
