package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.zIndex
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.FirebaseAuthProfileManager
import com.example.data.FirestoreUserProfile
import com.example.data.RedeemOption
import com.example.data.RedemptionRecord
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BrightBlue
import com.example.ui.theme.DeepArrowNavy
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.HeartRed
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface

/**
 * Compact, mobile-friendly User Account Bar displayed at the top of the single main user + game screen.
 * Keeps User Name, Email, Coins, Completed Levels, Recharge/Redeem future placeholder, Settings, and Logout
 * directly accessible on the same main screen as the Arrow Escape 3D game without cluttering the gameplay board.
 */
@Composable
fun UnifiedUserAccountBar(
    displayName: String,
    email: String,
    coins: Long,
    completedLevels: Long,
    rewardFeedback: String? = null,
    redemptionHistory: List<RedemptionRecord> = emptyList(),
    onSubmitRedemption: ((RedeemOption, String) -> Result<RedemptionRecord>)? = null,
    onWatchRewardedAd: (() -> Unit)? = null,
    onSettingsClicked: () -> Unit,
    onLogoutClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showRedeemPlaceholder by rememberSaveable { mutableStateOf(false) }
    val initialChar = displayName.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "P"

    Surface(
        color = NavyDeep,
        shadowElevation = 6.dp,
        modifier = modifier
            .fillMaxWidth()
            .testTag("unified_user_account_bar")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Profile Avatar + User Name + Email
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("user_profile_card")
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(BrightBlue, ElectricCyan)
                                )
                            )
                            .border(1.5.dp, Color.White.copy(alpha = 0.75f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initialChar,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = displayName.ifBlank { "Player" },
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("user_account_name_text")
                        )
                        Text(
                            text = email,
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("user_account_email_text")
                        )
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Coins & Completed Levels Badges + Redeem Placeholder Toggle + Settings + Logout
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    // Coins Pill
                    Surface(
                        color = NavySurface,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .border(1.dp, AccentGold.copy(alpha = 0.45f), RoundedCornerShape(50))
                            .testTag("user_account_coins_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = "Coins",
                                tint = AccentGold,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "$coins",
                                color = AccentGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.testTag("user_panel_coins_value")
                            )
                        }
                    }

                    // Completed Levels Pill
                    Surface(
                        color = NavySurface,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .border(1.dp, ElectricCyan.copy(alpha = 0.4f), RoundedCornerShape(50))
                            .testTag("user_account_levels_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Completed Levels",
                                tint = ElectricCyan,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "$completedLevels",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.testTag("user_panel_levels_value")
                            )
                        }
                    }

                    // Recharge / Redeem Future Placeholder Toggle Pill
                    Surface(
                        onClick = { showRedeemPlaceholder = !showRedeemPlaceholder },
                        color = if (showRedeemPlaceholder) AccentGold.copy(alpha = 0.24f) else NavySurface,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .border(1.dp, AccentGold.copy(alpha = 0.4f), RoundedCornerShape(50))
                            .testTag("user_panel_redeem_placeholder")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CardGiftcard,
                                contentDescription = "Recharge & Redeem Placeholder",
                                tint = AccentGold,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "Redeem",
                                color = AccentGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (onWatchRewardedAd != null) {
                        Surface(
                            onClick = onWatchRewardedAd,
                            color = NavySurface,
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .border(1.dp, AccentGold.copy(alpha = 0.5f), RoundedCornerShape(50))
                                .testTag("user_panel_watch_ad_pill")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = "Watch Ad +10 Coins",
                                    tint = AccentGold,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "+10 Ad",
                                    color = AccentGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Settings Button
                    IconButton(
                        onClick = onSettingsClicked,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(NavySurface)
                            .testTag("user_panel_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Logout Button
                    IconButton(
                        onClick = onLogoutClicked,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(NavySurface)
                            .testTag("user_panel_logout_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Logout",
                            tint = HeartRed,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            if (!rewardFeedback.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    color = EmeraldSuccess.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.testTag("user_reward_feedback_pill")
                ) {
                    Text(
                        text = "$rewardFeedback • Balance: $coins Coins • Completed Levels: $completedLevels",
                        color = Color(0xFF6EE7B7),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                }
            }

            if (showRedeemPlaceholder) {
                Spacer(modifier = Modifier.height(6.dp))
                RedeemConversionSection(
                    currentCoins = coins,
                    redemptionHistory = redemptionHistory,
                    onSubmitRedemption = onSubmitRedemption,
                    onClose = { showRedeemPlaceholder = false },
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 640.dp)
                        .zIndex(100f)
                        .testTag("user_redeem_placeholder_expanded")
                )
            }
        }
    }
}

/**
 * Full Redeem screen / panel showing the official conversion:
 * 1000 Coins = ₹10 Redeem Value
 * Processing/Service Charge = ₹1 (fixed per request; no extra coins deducted)
 *
 * Exact options:
 * - 1000 Coins → ₹10 → ₹1 charge → User receives ₹9
 * - 2000 Coins → ₹20 → ₹1 charge → User receives ₹19
 * - 5000 Coins → ₹50 → ₹1 charge → User receives ₹49
 * - 10000 Coins → ₹100 → ₹1 charge → User receives ₹99
 * - 35000 Coins → ₹350 → ₹1 charge → User receives ₹349
 */
@Composable
fun RedeemConversionSection(
    currentCoins: Long,
    redemptionHistory: List<RedemptionRecord> = emptyList(),
    onSubmitRedemption: ((RedeemOption, String) -> Result<RedemptionRecord>)? = null,
    onClose: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var selectedOptionOrdinal by rememberSaveable { mutableStateOf(RedeemOption.REDEEM_50.ordinal) }
    val selectedOption = RedeemOption.entries.getOrElse(selectedOptionOrdinal) { RedeemOption.REDEEM_50 }
    var payoutDetails by rememberSaveable { mutableStateOf("") }
    var statusMessage by rememberSaveable { mutableStateOf<String?>(null) }
    var isErrorStatus by rememberSaveable { mutableStateOf(false) }

    Surface(
        color = NavySurface,
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .border(1.dp, AccentGold.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "REDEEM COINS (1000 Coins = ₹10)",
                        color = AccentGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Fixed ₹1 Processing Charge per request • No extra coins deducted",
                        color = Color(0xFFCBD5E1),
                        fontSize = 11.sp
                    )
                }
                if (onClose != null) {
                    Surface(
                        onClick = onClose,
                        color = NavyCard,
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = "Close",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Exact 5 Redemption Options List
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                RedeemOption.entries.forEach { option ->
                    val isSelected = option == selectedOption
                    val canAfford = currentCoins >= option.coinsRequired
                    Surface(
                        onClick = {
                            selectedOptionOrdinal = option.ordinal
                            statusMessage = null
                        },
                        color = if (isSelected) BrightBlue.copy(alpha = 0.24f) else NavyCard,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) ElectricCyan else Color.White.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .testTag("redeem_option_${option.coinsRequired}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "₹${option.redeemValueRupees} Redeem • ${option.coinsFormatted}",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "${option.coinsRequired} Coins → ₹${option.redeemValueRupees} → ₹${option.processingChargeRupees} charge → User receives ₹${option.userReceivesRupees}",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 10.sp
                                )
                            }
                            Surface(
                                color = if (canAfford) EmeraldSuccess.copy(alpha = 0.2f) else AccentGold.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = "Receive ₹${option.userReceivesRupees}",
                                    color = if (canAfford) Color(0xFF6EE7B7) else AccentGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Selected Option Clear Breakdown Card (Redeem Value, Processing Charge, You Receive)
            Surface(
                color = NavyCard,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AccentGold.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                    .testTag("redeem_breakdown_card")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "₹${selectedOption.redeemValueRupees} Redeem",
                            color = AccentGold,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.testTag("redeem_selected_title")
                        )
                        Text(
                            text = selectedOption.coinsFormatted,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("redeem_selected_coins")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Redeem Value:",
                            color = Color(0xFFCBD5E1),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "₹${selectedOption.redeemValueRupees}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("redeem_value_text")
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Processing Charge:",
                            color = Color(0xFFCBD5E1),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "₹${selectedOption.processingChargeRupees}",
                            color = AccentGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("redeem_processing_charge_text")
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "You Receive:",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "₹${selectedOption.userReceivesRupees}",
                            color = EmeraldSuccess,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.testTag("redeem_you_receive_text")
                        )
                    }
                }
            }

            if (onSubmitRedemption != null) {
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = payoutDetails,
                    onValueChange = { payoutDetails = it },
                    placeholder = {
                        Text(
                            text = "UPI ID or Mobile Number (optional)",
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done
                    ),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = NavyCard,
                        unfocusedContainerColor = NavyCard,
                        focusedBorderColor = ElectricCyan,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                        cursorColor = ElectricCyan
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("redeem_payout_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        val result = onSubmitRedemption(selectedOption, payoutDetails)
                        result.onSuccess { record ->
                            isErrorStatus = false
                            statusMessage = "Redeemed ${record.coinsDeducted} Coins • Redeem Value: ₹${record.redeemValueRupees} • Charge: ₹${record.processingChargeRupees} • You Receive: ₹${record.userReceivesRupees}"
                            payoutDetails = ""
                        }.onFailure { err ->
                            isErrorStatus = true
                            statusMessage = err.message ?: "Unable to submit redemption."
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BrightBlue,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("submit_redeem_button")
                ) {
                    Text(
                        text = "Redeem ${selectedOption.coinsFormatted} → You Receive ₹${selectedOption.userReceivesRupees}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            if (!statusMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = statusMessage!!,
                    color = if (isErrorStatus) Color(0xFFFF8A9A) else Color(0xFF6EE7B7),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.testTag("redeem_status_message")
                )
            }

            if (redemptionHistory.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "REDEMPTION HISTORY (${redemptionHistory.size})",
                    color = ElectricCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                redemptionHistory.take(5).forEach { record ->
                    Surface(
                        color = NavyCard,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "₹${record.redeemValueRupees} Redeem (${record.coinsDeducted} Coins)",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Redeem Value: ₹${record.redeemValueRupees} • Processing Charge: ₹${record.processingChargeRupees} • You Receive: ₹${record.userReceivesRupees}",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 10.sp
                                )
                            }
                            Text(
                                text = record.status,
                                color = AccentGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Professional User Home Panel displayed after a normal user logs in.
 * Shows:
 * - Profile picture/icon
 * - User name & email
 * - Current coin balance
 * - Completed levels
 * - Play Game button
 * - Progress section
 * - Recharge/Redeem section (future placeholder)
 * - Settings & Logout
 */
@Composable
fun UserHomePanelScreen(
    displayName: String,
    email: String,
    profile: FirestoreUserProfile?,
    localCurrentLevel: Int,
    localCompletedLevelsCount: Int,
    localBestScore: Int,
    onPlayGameClicked: () -> Unit,
    onSettingsClicked: () -> Unit,
    onLogoutClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coinBalance = profile?.coins ?: 0L
    val completedLevels = maxOf(profile?.completedLevels ?: 0L, localCompletedLevelsCount.toLong())
    val initialChar = displayName.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "P"

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        NavyDeep,
                        Color(0xFF0E1C38),
                        Color(0xFF091224)
                    )
                )
            )
            .testTag("user_home_panel_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Top Brand & Quick Actions Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NavySurface,
                        modifier = Modifier
                            .size(40.dp)
                            .border(1.dp, ElectricCyan.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_app_icon),
                            contentDescription = "Arrow Escape 3D",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ARROW ESCAPE 3D",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Player Home Panel",
                            color = ElectricCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = onSettingsClicked,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(NavySurface)
                            .testTag("user_panel_top_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color.White
                        )
                    }
                    IconButton(
                        onClick = onLogoutClicked,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(NavySurface)
                            .testTag("user_panel_top_logout_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Logout",
                            tint = HeartRed
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 2. User Profile Identity Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .testTag("user_profile_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Profile Picture / Avatar Icon
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(BrightBlue, ElectricCyan)
                                )
                            )
                            .border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initialChar,
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = displayName.ifBlank { "Player" },
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.testTag("user_panel_name")
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Verified Account",
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Text(
                            text = email.ifBlank { "Signed in with Firebase" },
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("user_panel_email")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            color = NavyCard,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = "Joined: ${profile?.createdAtFormatted ?: "Active"}",
                                color = ElectricCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Coin Balance & Completed Levels Cards
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Coin Balance Card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("user_panel_coins_card"),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(AccentGold.copy(alpha = 0.18f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = AccentGold,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "COIN BALANCE",
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "$coinBalance",
                            color = AccentGold,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Firestore Synced Coins",
                            color = Color(0xFF64748B),
                            fontSize = 11.sp
                        )
                    }
                }

                // Completed Levels Card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("user_panel_completed_levels_card"),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(ElectricCyan.copy(alpha = 0.18f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EmojiEvents,
                                    contentDescription = null,
                                    tint = ElectricCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "COMPLETED",
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "$completedLevels",
                            color = Color.White,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Levels Cleared",
                            color = Color(0xFF64748B),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Primary PLAY GAME CTA Button
            Button(
                onClick = onPlayGameClicked,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .height(62.dp)
                    .shadow(10.dp, RoundedCornerShape(50))
                    .testTag("user_panel_play_game_button"),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrightBlue,
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "PLAY GAME (LEVEL $localCurrentLevel)",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 5. Progress Section Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .testTag("user_panel_progress_section"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "GAME PROGRESS",
                                color = ElectricCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            color = NavyCard,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = "Level $localCurrentLevel Active",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val milestoneTarget = ((completedLevels.toInt() / 20) + 1) * 20
                    val milestoneProgress = (completedLevels.toFloat() / milestoneTarget.coerceAtLeast(1))
                        .coerceIn(0.04f, 1f)

                    LinearProgressIndicator(
                        progress = { milestoneProgress },
                        color = ElectricCyan,
                        trackColor = NavyCard,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50))
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Completed: $completedLevels / $milestoneTarget Milestone",
                            color = Color(0xFFCBD5E1),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Best Score: $localBestScore",
                            color = AccentGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 6. Recharge / Redeem Conversion Section (1000 Coins = ₹10, Fixed ₹1 Charge)
            RedeemConversionSection(
                currentCoins = coinBalance,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .testTag("user_panel_redeem_placeholder")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 7. Bottom Settings & Logout Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onSettingsClicked,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("user_panel_settings_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = NavySurface,
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Settings",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                OutlinedButton(
                    onClick = onLogoutClicked,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("user_panel_logout_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = NavySurface,
                        contentColor = HeartRed
                    )
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Logout,
                        contentDescription = null,
                        tint = HeartRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Logout",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

/**
 * Professional Admin Panel exclusively accessible when the authenticated Firebase account
 * is `pawantailor3333@gmail.com`.
 *
 * Displays:
 * - Total users
 * - User list (User name, User email, Coins, Completed levels, Account creation date)
 * - Redemption Requests section as a future placeholder
 */
@Composable
fun AdminPanelScreen(
    adminEmail: String,
    usersList: List<FirestoreUserProfile>,
    redemptionRequests: List<RedemptionRecord> = emptyList(),
    isLoadingUsers: Boolean,
    errorMessage: String?,
    onRefreshUsers: () -> Unit,
    onOpenGamePreview: () -> Unit,
    onLogoutClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Hard security gate: never render Admin Panel content unless the authenticated email is the owner email
    if (!FirebaseAuthProfileManager.isEmailAdmin(adminEmail)) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(NavyDeep),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Unauthorized access blocked.",
                color = HeartRed,
                fontWeight = FontWeight.Bold
            )
        }
        return
    }

    var searchQuery by rememberSaveable { mutableStateOf("") }
    val filteredUsers = if (searchQuery.isBlank()) {
        usersList
    } else {
        val q = searchQuery.trim().lowercase()
        usersList.filter {
            it.displayName.lowercase().contains(q) ||
                it.email.lowercase().contains(q) ||
                it.userId.lowercase().contains(q)
        }
    }

    val totalCoinsAcrossUsers = usersList.sumOf { it.coins }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        NavyDeep,
                        Color(0xFF0D1B36),
                        Color(0xFF070F1F)
                    )
                )
            )
            .testTag("admin_panel_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Admin Top Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(AccentGold.copy(alpha = 0.18f))
                            .border(1.dp, AccentGold.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = AccentGold,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "ADMIN DASHBOARD",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = adminEmail,
                            color = AccentGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = onRefreshUsers,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(NavySurface)
                            .testTag("admin_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Users",
                            tint = ElectricCyan
                        )
                    }
                    IconButton(
                        onClick = onLogoutClicked,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(NavySurface)
                            .testTag("admin_logout_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Logout",
                            tint = HeartRed
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Summary Metrics Cards (Total Users & Total Economy Coins)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("admin_total_users_card"),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Groups,
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "TOTAL USERS",
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${usersList.size}",
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.testTag("admin_total_users_count")
                        )
                        Text(
                            text = "Registered Accounts",
                            color = Color(0xFF64748B),
                            fontSize = 11.sp
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = AccentGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "TOTAL COINS",
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "$totalCoinsAcrossUsers",
                            color = AccentGold,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Across All Users",
                            color = Color(0xFF64748B),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Optional Game Preview Button for Owner/Admin
            OutlinedButton(
                onClick = onOpenGamePreview,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
                    .height(48.dp)
                    .testTag("admin_open_game_button"),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = NavySurface,
                    contentColor = ElectricCyan
                )
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Launch Arrow Escape 3D Game",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Redemption Requests Section (1000 Coins = ₹10 • Fixed ₹1 Charge)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
                    .testTag("admin_redemption_requests_section"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CardGiftcard,
                                contentDescription = null,
                                tint = AccentGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "REDEMPTION REQUESTS (${redemptionRequests.size})",
                                color = AccentGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            color = AccentGold.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = "1000 COINS = ₹10",
                                color = AccentGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "${redemptionRequests.size} Redemption Requests • Fixed ₹1 Processing Charge",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tiers: 1000 Coins → ₹10 (Receive ₹9) • 2000 Coins → ₹20 (Receive ₹19) • 5000 Coins → ₹50 (Receive ₹49) • 10000 Coins → ₹100 (Receive ₹99) • 35000 Coins → ₹350 (Receive ₹349)",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )

                    if (redemptionRequests.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        redemptionRequests.forEach { req ->
                            Surface(
                                color = NavyCard,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${req.displayName} (${req.email})",
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = req.status,
                                            color = AccentGold,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${req.coinsDeducted} Coins → Redeem Value: ₹${req.redeemValueRupees} • Processing Charge: ₹${req.processingChargeRupees} • User Receives: ₹${req.userReceivesRupees}",
                                        color = ElectricCyan,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    if (req.payoutDetails.isNotBlank()) {
                                        Text(
                                            text = "Payout Details: ${req.payoutDetails} • ${req.createdAtFormatted}",
                                            color = Color(0xFF94A3B8),
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Registered Users List Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
                    .testTag("admin_users_list_section"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "REGISTERED USERS (${filteredUsers.size})",
                                color = ElectricCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (isLoadingUsers) {
                            CircularProgressIndicator(
                                color = ElectricCyan,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = {
                            Text("Search by name or email...", color = Color(0xFF64748B), fontSize = 13.sp)
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = Color(0xFF94A3B8)
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Search
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = NavyCard,
                            unfocusedContainerColor = NavyCard,
                            focusedBorderColor = ElectricCyan,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.1f),
                            cursorColor = ElectricCyan
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_user_search_input")
                    )

                    if (!errorMessage.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorMessage,
                            color = Color(0xFFFF8A9A),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (filteredUsers.isEmpty() && !isLoadingUsers) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No matching user profiles found.",
                                color = Color(0xFF94A3B8),
                                fontSize = 14.sp
                            )
                        }
                    } else {
                        filteredUsers.forEachIndexed { index, userProfile ->
                            if (index > 0) {
                                HorizontalDivider(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    color = Color.White.copy(alpha = 0.08f)
                                )
                            }
                            AdminUserRowCard(userProfile = userProfile)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))
        }
    }
}

@Composable
private fun AdminUserRowCard(
    userProfile: FirestoreUserProfile
) {
    val isOwnerAccount = FirebaseAuthProfileManager.isEmailAdmin(userProfile.email)

    Surface(
        color = NavyCard,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(BrightBlue.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = userProfile.displayName.ifBlank { "Player" },
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (isOwnerAccount) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = AccentGold.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(50)
                                ) {
                                    Text(
                                        text = "ADMIN",
                                        color = AccentGold,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = userProfile.email.ifBlank { "No email" },
                            color = Color(0xFF94A3B8),
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Metrics Row: Coins, Completed Levels, Account Creation Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = AccentGold,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${userProfile.coins} Coins",
                        color = AccentGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${userProfile.completedLevels} Levels",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = userProfile.createdAtFormatted,
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
