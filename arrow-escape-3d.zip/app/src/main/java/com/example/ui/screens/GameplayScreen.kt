package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBackIos
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Grid3x3
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.CameraController
import com.example.domain.GameUiState
import com.example.domain.InputManager
import com.example.domain.ScreenDestination
import com.example.model.ArrowBlock
import com.example.model.ConfettiParticle
import com.example.model.DifficultyTier
import com.example.ui.components.Board3DCanvas
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BrightBlue
import com.example.ui.theme.DeepArrowNavy
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.HeartRed
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavySurface

@Composable
fun GameplayScreen(
    uiState: GameUiState,
    cameraController: CameraController,
    inputManager: InputManager,
    onBlockTapped: (Int) -> Unit,
    onUseHint: () -> Unit,
    onUndo: () -> Unit,
    onRestart: () -> Unit,
    onTogglePause: () -> Unit,
    onToggleGridPegs: () -> Unit,
    onRotateCamera: (Float, Float) -> Unit,
    onZoomCamera: (Float) -> Unit,
    onResetCamera: () -> Unit,
    onToggle3DView: () -> Unit,
    onNextLevel: () -> Unit,
    onContinueWithCoins: () -> Unit,
    onRewardedAdExtraLife: () -> Unit,
    onRewardedAdDoubleCoins: () -> Unit,
    onWatchRewardedAdThenNextLevel: (() -> Unit)? = null,
    onWatchRewardedAdForHint: (() -> Unit)? = null,
    onCheckInterstitialBeforeHint: (((proceed: () -> Unit) -> Unit))? = null,
    onSoundToggle: (Boolean) -> Unit,
    onMusicToggle: (Boolean) -> Unit,
    onVibrationToggle: (Boolean) -> Unit,
    onNavigate: (ScreenDestination) -> Unit,
    hasTopAccountBar: Boolean = false,
    modifier: Modifier = Modifier
) {
    var showHintAdOfferDialog by remember { mutableStateOf(false) }
    var showAdsDebugDialog by remember { mutableStateOf(false) }

    val onHintButtonClicked: () -> Unit = {
        if (onWatchRewardedAdForHint != null) {
            val showOffer = {
                showHintAdOfferDialog = true
            }
            if (onCheckInterstitialBeforeHint != null) {
                onCheckInterstitialBeforeHint {
                    showOffer()
                }
            } else {
                showOffer()
            }
        } else {
            onUseHint()
        }
    }

    BackHandler {
        if (uiState.isPaused) {
            onTogglePause()
        } else {
            onNavigate(ScreenDestination.MAIN_MENU)
        }
    }

    val config = uiState.levelConfig
    val difficulty = config?.difficulty ?: DifficultyTier.EASY

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFF6F9FE),
                        Color(0xFFEBF2FC),
                        Color(0xFFE2ECF9)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .then(
                    if (hasTopAccountBar) Modifier else Modifier.windowInsetsPadding(WindowInsets.statusBars)
                )
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Top Header Bar (Back Button, Level Title & Mode Subtitle, Pause/Settings Button)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onNavigate(ScreenDestination.MAIN_MENU) },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("hud_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBackIos,
                        contentDescription = "Back to Menu",
                        tint = BrightBlue
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Level ${uiState.currentLevelNumber}",
                        color = DeepArrowNavy,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.testTag("hud_level_title")
                    )
                    Text(
                        text = "${config?.gameMode?.title ?: "Tap Away Arrows"} • ${config?.shapeName ?: "3D Grid"}",
                        color = Color(0xFF64748B),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    UnityAdsDebugFloatingPill(
                        onClick = { showAdsDebugDialog = true }
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onTogglePause,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("hud_pause_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Pause and Settings",
                            tint = BrightBlue
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 2. Second HUD Row matching Reference Screenshots:
            // [Remaining Arrows Pill]   [3 Hearts]   [Difficulty Pill]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Remaining Arrows Pill
                Surface(
                    color = Color(0xFFE6EEF8),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.testTag("remaining_arrows_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.NearMe,
                            contentDescription = "Remaining Arrows",
                            tint = Color(0xFF334155),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "${uiState.remainingBlockCount}",
                            color = DeepArrowNavy,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp
                        )
                    }
                }

                // Hearts Display
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.testTag("hearts_display")
                ) {
                    for (i in 1..uiState.maxHearts) {
                        val filled = i <= uiState.hearts
                        Icon(
                            imageVector = if (filled) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = if (filled) "Full Heart" else "Empty Heart",
                            tint = if (filled) HeartRed else Color(0xFFCBD5E1),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // Difficulty Pill
                Surface(
                    color = Color(0xFFE6EEF8),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.testTag("difficulty_badge")
                ) {
                    Text(
                        text = difficulty.displayName,
                        color = Color(0xFF334155),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 3. Secondary Info & 3D Camera Controls Bar (Coins, Score, Challenge Timer/Moves, 3D View Reset)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(50),
                        shadowElevation = 2.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = "Coins",
                                tint = AccentGold,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "${uiState.coins}",
                                color = DeepArrowNavy,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    if (uiState.remainingSeconds != null) {
                        Surface(
                            color = if (uiState.remainingSeconds <= 10) HeartRed else DeepArrowNavy,
                            shape = RoundedCornerShape(50)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = "Time Remaining",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "${uiState.remainingSeconds}s",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    if (uiState.remainingMoves != null) {
                        Surface(
                            color = DeepArrowNavy,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = "Moves: ${uiState.remainingMoves}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }

                // 3D View Angle Toggle & Camera Reset Buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (uiState.isIsometric3D) BrightBlue else Color.White,
                        shape = RoundedCornerShape(50),
                        shadowElevation = 2.dp,
                        modifier = Modifier
                            .clickable { onToggle3DView() }
                            .testTag("toggle_3d_view_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ViewInAr,
                                contentDescription = "Toggle 3D Angle",
                                tint = if (uiState.isIsometric3D) Color.White else DeepArrowNavy,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (uiState.isIsometric3D) "3D Tilt" else "Top 3D",
                                color = if (uiState.isIsometric3D) Color.White else DeepArrowNavy,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(50),
                        shadowElevation = 2.dp,
                        modifier = Modifier
                            .clickable { onResetCamera() }
                            .testTag("reset_camera_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CenterFocusStrong,
                                contentDescription = "Reset 3D Camera",
                                tint = BrightBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Reset View",
                                color = DeepArrowNavy,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Optional Status / Feedback Banner (Blocked notification or Hint instruction)
            AnimatedVisibility(
                visible = uiState.statusBannerMessage != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    color = DeepArrowNavy,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .testTag("status_banner")
                ) {
                    Text(
                        text = uiState.statusBannerMessage ?: "",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }

            // 4. Main Interactive 3D Board Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                if (config != null) {
                    Board3DCanvas(
                        blocks = uiState.activeBlocks,
                        gridWidth = config.gridWidth,
                        gridHeight = config.gridHeight,
                        layers = config.layers,
                        showGridPegs = uiState.showGridPegs,
                        activeHintBlockId = uiState.activeHintBlockId,
                        activeHintRay = uiState.activeHintRay,
                        flyingArrows = uiState.flyingArrows,
                        blockedArrowState = uiState.blockedArrowState,
                        particles3D = uiState.particles3D,
                        graphicsQuality = uiState.graphicsQuality,
                        cameraController = cameraController,
                        cameraYaw = uiState.cameraYaw,
                        cameraPitch = uiState.cameraPitch,
                        cameraZoom = uiState.cameraZoom,
                        inputManager = inputManager,
                        onBlockTapped = onBlockTapped,
                        onRotateCamera = onRotateCamera,
                        onZoomCamera = onZoomCamera
                    )
                }

                // Subtle instruction footer at bottom of 3D canvas
                Text(
                    text = if ((config?.layers ?: 1) > 1) {
                        "Tap free arrows • Drag to rotate 3D layers (${config?.layers} Layers)"
                    } else {
                        "Tap arrows with a free path • Drag to orbit 3D view"
                    },
                    color = Color(0xFF64748B),
                    fontSize = 11.sp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 2.dp)
                )
            }

            // 5. Bottom Circular Action Buttons Dock (Hint with badge, Undo, Grid Pegs #, Restart)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 420.dp)
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Hint Button with count badge (matches IMG_0804 & IMG_0807)
                Box(contentAlignment = Alignment.TopEnd) {
                    Surface(
                        onClick = onHintButtonClicked,
                        shape = CircleShape,
                        color = Color.White,
                        shadowElevation = 6.dp,
                        modifier = Modifier
                            .size(62.dp)
                            .testTag("hint_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = "Use Hint",
                                tint = BrightBlue,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }

                    Surface(
                        color = BrightBlue,
                        shape = CircleShape,
                        modifier = Modifier
                            .padding(2.dp)
                            .testTag("hint_count_badge")
                    ) {
                        Text(
                            text = "${uiState.hints}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                    }
                }

                // Undo Button
                Surface(
                    onClick = onUndo,
                    enabled = uiState.canUndo,
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = if (uiState.canUndo) 6.dp else 1.dp,
                    modifier = Modifier
                        .size(56.dp)
                        .testTag("undo_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo Move",
                            tint = if (uiState.canUndo) BrightBlue else Color(0xFFCBD5E1),
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                // Grid Pegs Toggle Button (# icon matching reference screenshots)
                Surface(
                    onClick = onToggleGridPegs,
                    shape = CircleShape,
                    color = if (uiState.showGridPegs) Color.White else Color(0xFFE2E8F0),
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .size(62.dp)
                        .testTag("grid_toggle_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Grid3x3,
                            contentDescription = "Toggle Grid Pegs",
                            tint = BrightBlue,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }

                // Restart Level Button
                Surface(
                    onClick = onRestart,
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .size(56.dp)
                        .testTag("restart_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Restart Level",
                            tint = BrightBlue,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        }

        // 6. Overlays: Level Complete, Game Over, Pause
        if (uiState.isLevelComplete && config != null) {
            LevelCompleteOverlay(
                levelNumber = uiState.currentLevelNumber,
                starsEarned = uiState.starsEarned,
                score = uiState.currentScore,
                coinsEarned = uiState.coinsEarnedThisLevel,
                totalCoins = uiState.coins,
                rewardFeedback = uiState.lastCoinRewardFeedback,
                doubleCoinsClaimed = uiState.doubleCoinsClaimed,
                completedBlocks = config.initialBlocks,
                gridWidth = config.gridWidth,
                gridHeight = config.gridHeight,
                confettiParticles = uiState.confettiParticles,
                onNextLevel = onNextLevel,
                onDoubleCoins = onRewardedAdDoubleCoins,
                onMainMenu = { onNavigate(ScreenDestination.MAIN_MENU) },
                onWatchAdThenNextLevel = onWatchRewardedAdThenNextLevel
            )
        }

        if (uiState.isGameOver) {
            GameOverOverlay(
                reason = uiState.gameOverReason,
                coins = uiState.coins,
                onRetry = onRestart,
                onContinueWithCoins = onContinueWithCoins,
                onRewardedAdExtraLife = onRewardedAdExtraLife,
                onMainMenu = { onNavigate(ScreenDestination.MAIN_MENU) }
            )
        }

        if (uiState.isPaused && !uiState.isLevelComplete && !uiState.isGameOver) {
            PauseOverlay(
                soundEnabled = uiState.soundEnabled,
                musicEnabled = uiState.musicEnabled,
                vibrationEnabled = uiState.vibrationEnabled,
                onResume = onTogglePause,
                onRestart = onRestart,
                onSoundToggle = onSoundToggle,
                onMusicToggle = onMusicToggle,
                onVibrationToggle = onVibrationToggle,
                onMainMenu = { onNavigate(ScreenDestination.MAIN_MENU) }
            )
        }

        if (showHintAdOfferDialog) {
            AlertDialog(
                onDismissRequest = {
                    showHintAdOfferDialog = false
                },
                title = {
                    Text("Need a Hint?", fontWeight = FontWeight.Bold)
                },
                text = {
                    Text("Watch an ad to earn +10 Coins and reveal the next movable arrow!")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showHintAdOfferDialog = false
                            onWatchRewardedAdForHint?.invoke()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentGold,
                            contentColor = DeepArrowNavy
                        ),
                        modifier = Modifier.testTag("hint_watch_ad_button")
                    ) {
                        Icon(Icons.Default.MonetizationOn, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Watch Ad +10 Coins", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = {
                            showHintAdOfferDialog = false
                            onUseHint()
                        },
                        modifier = Modifier.testTag("hint_use_directly_button")
                    ) {
                        Text("Use Hint directly")
                    }
                }
            )
        }
    }
}

/**
 * Polished Level Complete Celebration Screen inspired by IMG_0808.png:
 * Features blue sunburst background, animated confetti, 3 stars, completed board preview card,
 * score & coin rewards, and a prominent NEXT LEVEL button.
 */
@Composable
private fun LevelCompleteOverlay(
    levelNumber: Int,
    starsEarned: Int,
    score: Int,
    coinsEarned: Int,
    totalCoins: Int,
    rewardFeedback: String?,
    doubleCoinsClaimed: Boolean,
    completedBlocks: List<ArrowBlock>,
    gridWidth: Int,
    gridHeight: Int,
    confettiParticles: List<ConfettiParticle>,
    onNextLevel: () -> Unit,
    onDoubleCoins: () -> Unit,
    onMainMenu: () -> Unit,
    onWatchAdThenNextLevel: (() -> Unit)? = null
) {
    var showNextLevelAdOfferDialog by remember { mutableStateOf(false) }

    val handleNextLevelTap = {
        if (!doubleCoinsClaimed && onWatchAdThenNextLevel != null) {
            showNextLevelAdOfferDialog = true
        } else {
            onNextLevel()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF38B6FF),
                        Color(0xFF1E88E5),
                        Color(0xFF0D47A1)
                    )
                )
            )
            .testTag("level_complete_overlay"),
        contentAlignment = Alignment.Center
    ) {
        // Confetti & Sunburst Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height * 0.42f
            val maxR = size.height * 0.85f
            for (i in 0 until 18) {
                val startAngle = i * 20f
                drawArc(
                    color = Color.White.copy(alpha = 0.08f),
                    startAngle = startAngle,
                    sweepAngle = 10f,
                    useCenter = true,
                    topLeft = Offset(cx - maxR, cy - maxR),
                    size = Size(maxR * 2f, maxR * 2f)
                )
            }

            // Draw Falling Confetti
            for (c in confettiParticles) {
                val px = c.x * size.width
                val py = c.y * size.height
                withTransform({
                    rotate(degrees = c.rotation, pivot = Offset(px, py))
                }) {
                    drawRect(
                        color = Color(c.colorHex),
                        topLeft = Offset(px - c.sizeDp, py - c.sizeDp * 0.5f),
                        size = Size(c.sizeDp * 2f, c.sizeDp)
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 460.dp)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "LEVEL COMPLETE!",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Level $levelNumber Cleared!",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Stars Row
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 1..3) {
                    val earned = i <= starsEarned
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = if (earned) AccentGold else Color.White.copy(alpha = 0.3f),
                        modifier = Modifier.size(if (i == 2) 48.dp else 38.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Completed Board Preview Card (like IMG_0808.png)
            Card(
                modifier = Modifier.size(210.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(18.dp)
                ) {
                    val maxDim = maxOf(gridWidth, gridHeight).coerceAtLeast(5)
                    val cellPx = minOf(size.width, size.height) / maxDim
                    val ox = (size.width - (gridWidth - 1) * cellPx) / 2f
                    val oy = (size.height - (gridHeight - 1) * cellPx) / 2f

                    for (block in completedBlocks) {
                        val path = Path()
                        block.cells.forEachIndexed { idx, cell ->
                            val px = ox + cell.x * cellPx
                            val py = oy + cell.y * cellPx
                            if (idx == 0) path.moveTo(px, py) else path.lineTo(px, py)
                        }
                        drawPath(
                            path = path,
                            color = DeepArrowNavy,
                            style = Stroke(
                                width = (cellPx * 0.14f).coerceAtLeast(2f),
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                        val head = block.head
                        val hx = ox + head.x * cellPx
                        val hy = oy + head.y * cellPx
                        drawCircle(
                            color = BrightBlue,
                            radius = (cellPx * 0.11f).coerceAtLeast(2f),
                            center = Offset(hx, hy)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Score & Coin Reward Pills
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = Color.White.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = "Score: $score",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
                Surface(
                    color = AccentGold,
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.testTag("level_complete_coins_reward_pill")
                ) {
                    Text(
                        text = "+$coinsEarned Coins",
                        color = DeepArrowNavy,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "${rewardFeedback ?: "+$coinsEarned Coins"} • Balance: $totalCoins Coins",
                color = Color.White.copy(alpha = 0.95f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("level_complete_balance_summary")
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Primary NEXT LEVEL Button
            Button(
                onClick = handleNextLevelTap,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .shadow(8.dp, RoundedCornerShape(50))
                    .testTag("next_level_button"),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = BrightBlue
                )
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "NEXT LEVEL",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (!doubleCoinsClaimed) {
                FilledTonalButton(
                    onClick = onDoubleCoins,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("watch_ad_10_coins_button"),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color.White.copy(alpha = 0.22f),
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = AccentGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Watch Ad +10 Coins",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = onMainMenu,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("complete_main_menu_button"),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Text(
                    text = "Main Menu",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }

        if (showNextLevelAdOfferDialog) {
            AlertDialog(
                onDismissRequest = {
                    showNextLevelAdOfferDialog = false
                    onNextLevel()
                },
                title = {
                    Text("Next Level Bonus", fontWeight = FontWeight.Bold)
                },
                text = {
                    Text("Watch an ad to earn +10 Coins before moving to the next level?")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showNextLevelAdOfferDialog = false
                            onWatchAdThenNextLevel?.invoke() ?: onNextLevel()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentGold,
                            contentColor = DeepArrowNavy
                        ),
                        modifier = Modifier.testTag("next_level_watch_ad_button")
                    ) {
                        Icon(Icons.Default.MonetizationOn, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Watch Ad +10 Coins", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = {
                            showNextLevelAdOfferDialog = false
                            onNextLevel()
                        },
                        modifier = Modifier.testTag("next_level_continue_button")
                    ) {
                        Text("Continue (No Ad)")
                    }
                }
            )
        }
    }
}

@Composable
private fun GameOverOverlay(
    reason: String,
    coins: Int,
    onRetry: () -> Unit,
    onContinueWithCoins: () -> Unit,
    onRewardedAdExtraLife: () -> Unit,
    onMainMenu: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xD90A1124))
            .testTag("game_over_overlay"),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 420.dp)
                .padding(24.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = NavySurface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.FavoriteBorder,
                    contentDescription = null,
                    tint = HeartRed,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = reason.uppercase(),
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Don't give up! Keep your progress on this board or retry from the start.",
                    color = Color(0xFF94A3B8),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onContinueWithCoins,
                    enabled = coins >= 50,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("continue_coins_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldSuccess,
                        contentColor = Color.White
                    )
                ) {
                    Text(
                        text = "CONTINUE (+3 HEARTS • 50 COINS)",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                FilledTonalButton(
                    onClick = onRewardedAdExtraLife,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("rewarded_ad_life_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = NavyCard,
                        contentColor = ElectricCyan
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = null,
                        tint = HeartRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Watch Ad for +1 Heart",
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onRetry,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("retry_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BrightBlue,
                        contentColor = Color.White
                    )
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "RETRY LEVEL",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onMainMenu,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("gameover_main_menu_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "Main Menu",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun PauseOverlay(
    soundEnabled: Boolean,
    musicEnabled: Boolean,
    vibrationEnabled: Boolean,
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onSoundToggle: (Boolean) -> Unit,
    onMusicToggle: (Boolean) -> Unit,
    onVibrationToggle: (Boolean) -> Unit,
    onMainMenu: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC0A1124))
            .testTag("pause_overlay"),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 400.dp)
                .padding(24.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = NavySurface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "GAME PAUSED",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(16.dp))

                ToggleRow("Sound Effects", soundEnabled, onSoundToggle)
                ToggleRow("Background Music", musicEnabled, onMusicToggle)
                ToggleRow("Haptic Vibration", vibrationEnabled, onVibrationToggle)

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onResume,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("resume_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightBlue)
                ) {
                    Text("RESUME GAME", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                FilledTonalButton(
                    onClick = onRestart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("pause_restart_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = NavyCard,
                        contentColor = Color.White
                    )
                ) {
                    Text("Restart Level", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onMainMenu,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("pause_main_menu_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Main Menu", color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
