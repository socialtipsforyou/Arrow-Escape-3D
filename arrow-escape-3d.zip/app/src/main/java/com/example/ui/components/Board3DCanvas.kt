package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroidSize
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntSize
import com.example.domain.CameraController
import com.example.domain.InputManager
import com.example.model.ArrowBlock
import com.example.model.BlockedArrowState
import com.example.model.Direction3D
import com.example.model.FlyingArrowState
import com.example.model.GraphicsQuality
import com.example.model.GridPos3D
import com.example.model.Particle3D
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BlockPaletteLayer1
import com.example.ui.theme.BlockPaletteLayer2
import com.example.ui.theme.BlockPaletteTop
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.HeartRed
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * Custom 3D perspective/isometric rendering canvas for the Arrow Escape 3D board.
 * Renders the 3D beveled platform, recessed grid pegs, multi-layer 3D extruded arrow blocks,
 * soft shadows, specular highlights, hint path trajectories, collision pulses, and flying arrows.
 */
@Composable
fun Board3DCanvas(
    blocks: List<ArrowBlock>,
    gridWidth: Int,
    gridHeight: Int,
    layers: Int,
    showGridPegs: Boolean,
    activeHintBlockId: Int?,
    activeHintRay: List<GridPos3D>,
    flyingArrows: List<FlyingArrowState>,
    blockedArrowState: BlockedArrowState?,
    particles3D: List<Particle3D>,
    graphicsQuality: GraphicsQuality,
    cameraController: CameraController,
    cameraYaw: Float,
    cameraPitch: Float,
    cameraZoom: Float,
    inputManager: InputManager,
    onBlockTapped: (Int) -> Unit,
    onRotateCamera: (Float, Float) -> Unit,
    onZoomCamera: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val shouldAnimatePulse = activeHintBlockId != null || flyingArrows.isNotEmpty()
    val pulsePhase = if (shouldAnimatePulse) {
        val infiniteTransition = rememberInfiniteTransition(label = "hintPulse")
        val animatedPhase by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1100, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "pulsePhase"
        )
        animatedPhase
    } else {
        0f
    }

    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    val currentBlocks by rememberUpdatedState(blocks)
    val currentGridW by rememberUpdatedState(gridWidth)
    val currentGridH by rememberUpdatedState(gridHeight)
    val currentOnBlockTapped by rememberUpdatedState(onBlockTapped)
    val currentOnRotate by rememberUpdatedState(onRotateCamera)
    val currentOnZoom by rememberUpdatedState(onZoomCamera)

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("board_3d_canvas")
                .onSizeChanged { canvasSize = it }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = true)
                        val startPos = down.position
                        var totalDragDistance = 0f
                        var isMultiTouch = false

                        do {
                            val event = awaitPointerEvent()
                            val pressedCount = event.changes.count { it.pressed }
                            if (pressedCount >= 2) {
                                isMultiTouch = true
                                val zoomChange = event.calculateZoom()
                                if (zoomChange != 1f && zoomChange > 0f) {
                                    currentOnZoom(zoomChange)
                                }
                                event.changes.forEach { it.consume() }
                            } else if (pressedCount == 1) {
                                val pan = event.calculatePan()
                                val dist = hypot(pan.x, pan.y)
                                totalDragDistance += dist
                                if (totalDragDistance > 20f) {
                                    // Smoothly orbit the 3D camera
                                    currentOnRotate(pan.x * 0.22f, -pan.y * 0.18f)
                                    event.changes.forEach { it.consume() }
                                }
                            }
                        } while (event.changes.any { it.pressed })

                        // If finger lifted with minimal movement, treat as a precise 3D block tap
                        if (!isMultiTouch && totalDragDistance <= 20f && canvasSize.width > 0) {
                            val w = canvasSize.width.toFloat()
                            val h = canvasSize.height.toFloat()
                            val maxDim = maxOf(currentGridW, currentGridH, 10)
                            val cellSizePx = (min(w, h) * 0.68f) / maxDim

                            val hitId = inputManager.findTappedBlockId(
                                touchX = startPos.x,
                                touchY = startPos.y,
                                blocks = currentBlocks,
                                gridWidth = currentGridW,
                                gridHeight = currentGridH,
                                canvasWidth = w,
                                canvasHeight = h,
                                cellSizePx = cellSizePx,
                                camera = cameraController
                            )
                            if (hitId != null) {
                                currentOnBlockTapped(hitId)
                            }
                        }
                    }
                }
        ) {
            // Reference cameraYaw / cameraPitch / cameraZoom to trigger redraw on camera state changes
            @Suppress("UNUSED_VARIABLE")
            val camTrigger = cameraYaw + cameraPitch + cameraZoom

            val w = size.width
            val h = size.height
            if (w <= 10f || h <= 10f) return@Canvas

            val centerX = w / 2f
            val centerY = h / 2f
            val maxDim = maxOf(gridWidth, gridHeight, 10)
            val cellSizePx = (min(w, h) * 0.68f) / maxDim
            val halfW = (gridWidth - 1) / 2f
            val halfH = (gridHeight - 1) / 2f

            // 1. Draw the 3D Rounded Platform Base & Beveled Rim
            draw3DPlatformBase(
                camera = cameraController,
                halfW = halfW,
                halfH = halfH,
                centerX = centerX,
                centerY = centerY,
                cellSizePx = cellSizePx,
                graphicsQuality = graphicsQuality
            )

            // 2. Draw Recessed 3D Grid Pegs (dots on each grid coordinate)
            if (showGridPegs) {
                draw3DGridPegs(
                    camera = cameraController,
                    gridWidth = gridWidth,
                    gridHeight = gridHeight,
                    layers = layers,
                    halfW = halfW,
                    halfH = halfH,
                    centerX = centerX,
                    centerY = centerY,
                    cellSizePx = cellSizePx
                )
            }

            // 3. Draw Active Hint Exit Trajectory Ray on the board
            if (activeHintBlockId != null && activeHintRay.isNotEmpty()) {
                val hintedBlock = blocks.find { it.id == activeHintBlockId }
                if (hintedBlock != null) {
                    drawHintExitRay3D(
                        camera = cameraController,
                        block = hintedBlock,
                        rayCells = activeHintRay,
                        halfW = halfW,
                        halfH = halfH,
                        centerX = centerX,
                        centerY = centerY,
                        cellSizePx = cellSizePx,
                        pulsePhase = pulsePhase
                    )
                }
            }

            // 4. Sort active blocks using Painter's Algorithm (back-to-front, bottom-layer to top-layer)
            val sortedBlocks = blocks.sortedWith(
                compareBy<ArrowBlock> { it.layer }.thenBy { block ->
                    val zTop = block.layer * 0.36f + 0.155f
                    var sumDepth = 0f
                    for (c in block.cells) {
                        sumDepth += cameraController.project3D(
                            wx = c.x - halfW,
                            wy = c.y - halfH,
                            wz = zTop,
                            centerX = centerX,
                            centerY = centerY,
                            cellSizePx = cellSizePx
                        ).depth
                    }
                    sumDepth / block.cells.size.coerceAtLeast(1)
                }
            )

            // 5. Render each 3D Arrow Block (Shadow -> 3D Extruded Side Walls -> Top Face -> Bevel -> 3D Arrowhead)
            for (block in sortedBlocks) {
                val isHinted = block.id == activeHintBlockId
                val isBlockedMover = blockedArrowState?.blockId == block.id
                val isBlockerTarget = blockedArrowState?.blockingBlockId == block.id

                val shakeOffsetUnits = if (isBlockedMover && blockedArrowState != null) {
                    val p = blockedArrowState.progress
                    sin(p * PI.toFloat() * 4f) * (1f - p) * 0.28f
                } else {
                    0f
                }

                draw3DArrowBlock(
                    camera = cameraController,
                    block = block,
                    slideDistanceUnits = shakeOffsetUnits,
                    isHinted = isHinted,
                    isBlockedMover = isBlockedMover,
                    isBlockerTarget = isBlockerTarget,
                    pulsePhase = pulsePhase,
                    halfW = halfW,
                    halfH = halfH,
                    centerX = centerX,
                    centerY = centerY,
                    cellSizePx = cellSizePx,
                    graphicsQuality = graphicsQuality,
                    alpha = 1f
                )
            }

            // 6. Render Blocked Collision Ring at the exact 3D collision point
            if (blockedArrowState != null) {
                val c = blockedArrowState.collisionCell
                val zCol = c.z * 0.36f + 0.18f
                val proj = cameraController.project3D(
                    wx = c.x - halfW,
                    wy = c.y - halfH,
                    wz = zCol,
                    centerX = centerX,
                    centerY = centerY,
                    cellSizePx = cellSizePx
                )
                val ringRadius = cellSizePx * cameraController.zoom * (0.25f + blockedArrowState.progress * 0.55f)
                val ringAlpha = (1f - blockedArrowState.progress).coerceIn(0f, 1f)
                drawCircle(
                    color = HeartRed.copy(alpha = ringAlpha * 0.85f),
                    radius = ringRadius,
                    center = Offset(proj.screenX, proj.screenY),
                    style = Stroke(width = 4f * cameraController.zoom)
                )
            }

            // 7. Render Flying Arrows smoothly sliding out of the board
            for (flying in flyingArrows) {
                val eased = flying.progress * (1.2f + flying.progress * 0.8f)
                val slideUnits = eased * (maxDim * 0.85f)
                val alpha = (1f - flying.progress * 0.85f).coerceIn(0.05f, 1f)
                draw3DArrowBlock(
                    camera = cameraController,
                    block = flying.block,
                    slideDistanceUnits = slideUnits,
                    isHinted = true,
                    isBlockedMover = false,
                    isBlockerTarget = false,
                    pulsePhase = pulsePhase,
                    halfW = halfW,
                    halfH = halfH,
                    centerX = centerX,
                    centerY = centerY,
                    cellSizePx = cellSizePx,
                    graphicsQuality = graphicsQuality,
                    alpha = alpha
                )
            }

            // 8. Render 3D Particles
            for (p in particles3D) {
                val proj = cameraController.project3D(
                    wx = p.x - halfW,
                    wy = p.y - halfH,
                    wz = p.z,
                    centerX = centerX,
                    centerY = centerY,
                    cellSizePx = cellSizePx
                )
                val pColor = if (p.isError) {
                    HeartRed.copy(alpha = p.life.coerceIn(0f, 1f))
                } else {
                    ElectricCyan.copy(alpha = p.life.coerceIn(0f, 1f))
                }
                drawCircle(
                    color = pColor,
                    radius = p.size * cameraController.zoom * p.life.coerceAtLeast(0.2f),
                    center = Offset(proj.screenX, proj.screenY)
                )
            }
        }
    }
}

private fun DrawScope.draw3DPlatformBase(
    camera: CameraController,
    halfW: Float,
    halfH: Float,
    centerX: Float,
    centerY: Float,
    cellSizePx: Float,
    graphicsQuality: GraphicsQuality
) {
    val margin = 0.88f
    val minX = -halfW - margin
    val maxX = halfW + margin
    val minY = -halfH - margin
    val maxY = halfH + margin

    val topCorners = listOf(
        camera.project3D(minX, minY, 0f, centerX, centerY, cellSizePx),
        camera.project3D(maxX, minY, 0f, centerX, centerY, cellSizePx),
        camera.project3D(maxX, maxY, 0f, centerX, centerY, cellSizePx),
        camera.project3D(minX, maxY, 0f, centerX, centerY, cellSizePx)
    )

    val bottomCorners = listOf(
        camera.project3D(minX, minY, -0.42f, centerX, centerY, cellSizePx),
        camera.project3D(maxX, minY, -0.42f, centerX, centerY, cellSizePx),
        camera.project3D(maxX, maxY, -0.42f, centerX, centerY, cellSizePx),
        camera.project3D(minX, maxY, -0.42f, centerX, centerY, cellSizePx)
    )

    // Soft ambient shadow beneath the 3D board platform
    if (graphicsQuality != GraphicsQuality.PERFORMANCE) {
        val shadowCorners = listOf(
            camera.project3D(minX + 0.15f, minY + 0.25f, -0.62f, centerX, centerY, cellSizePx),
            camera.project3D(maxX + 0.15f, minY + 0.25f, -0.62f, centerX, centerY, cellSizePx),
            camera.project3D(maxX + 0.15f, maxY + 0.25f, -0.62f, centerX, centerY, cellSizePx),
            camera.project3D(minX + 0.15f, maxY + 0.25f, -0.62f, centerX, centerY, cellSizePx)
        )
        val shadowPath = Path().apply {
            moveTo(shadowCorners[0].screenX, shadowCorners[0].screenY)
            for (i in 1..3) lineTo(shadowCorners[i].screenX, shadowCorners[i].screenY)
            close()
        }
        drawPath(
            path = shadowPath,
            color = Color(0x38050B18)
        )
        drawPath(
            path = shadowPath,
            color = Color(0x28050B18),
            style = Stroke(width = 26f * camera.zoom, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }

    // Draw 3D platform side walls (connecting topCorners to bottomCorners)
    for (i in 0..3) {
        val next = (i + 1) % 4
        val wallPath = Path().apply {
            moveTo(topCorners[i].screenX, topCorners[i].screenY)
            lineTo(topCorners[next].screenX, topCorners[next].screenY)
            lineTo(bottomCorners[next].screenX, bottomCorners[next].screenY)
            lineTo(bottomCorners[i].screenX, bottomCorners[i].screenY)
            close()
        }
        val wallColor = when (i) {
            2 -> Color(0xFFD0DCF0) // Front-facing 3D rim
            1, 3 -> Color(0xFFBCCCE6) // Side-facing 3D rim
            else -> Color(0xFFB0C2DE)
        }
        drawPath(path = wallPath, color = wallColor)
    }

    // Round the bottom rim perimeter
    val bottomPath = Path().apply {
        moveTo(bottomCorners[0].screenX, bottomCorners[0].screenY)
        for (i in 1..3) lineTo(bottomCorners[i].screenX, bottomCorners[i].screenY)
        close()
    }
    drawPath(
        path = bottomPath,
        color = Color(0xFFBCCCE6),
        style = Stroke(width = 20f * camera.zoom, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // Draw the crisp, bright 3D board top deck surface
    val topPath = Path().apply {
        moveTo(topCorners[0].screenX, topCorners[0].screenY)
        for (i in 1..3) lineTo(topCorners[i].screenX, topCorners[i].screenY)
        close()
    }
    drawPath(path = topPath, color = Color(0xFFF8FAFF))
    drawPath(
        path = topPath,
        color = Color(0xFFF8FAFF),
        style = Stroke(width = 20f * camera.zoom, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
    // Subtle inner bevel border on the top surface
    drawPath(
        path = topPath,
        color = Color(0xFFE2EBF8),
        style = Stroke(width = 3f * camera.zoom, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}

private fun DrawScope.draw3DGridPegs(
    camera: CameraController,
    gridWidth: Int,
    gridHeight: Int,
    layers: Int,
    halfW: Float,
    halfH: Float,
    centerX: Float,
    centerY: Float,
    cellSizePx: Float
) {
    val pegRadius = (cellSizePx * camera.zoom * 0.052f).coerceIn(1.4f, 3.2f)
    for (y in 0 until gridHeight) {
        for (x in 0 until gridWidth) {
            val pt = camera.project3D(
                wx = x - halfW,
                wy = y - halfH,
                wz = 0.01f,
                centerX = centerX,
                centerY = centerY,
                cellSizePx = cellSizePx
            )
            // Recessed peg shadow + core
            drawCircle(
                color = Color(0xFFCBD5E1),
                radius = pegRadius,
                center = Offset(pt.screenX, pt.screenY)
            )
            drawCircle(
                color = Color(0xFF94A3B8),
                radius = pegRadius * 0.65f,
                center = Offset(pt.screenX - 0.5f, pt.screenY - 0.5f)
            )
        }
    }

    // If multi-layer 3D mode is active, draw a subtle translucent platform outline for Layer 1
    if (layers > 1) {
        val margin = 1
        val minX = margin - halfW - 0.35f
        val maxX = (gridWidth - 1 - margin) - halfW + 0.35f
        val minY = margin - halfH - 0.35f
        val maxY = (gridHeight - 1 - margin) - halfH + 0.35f
        if (maxX > minX && maxY > minY) {
            val l1Corners = listOf(
                camera.project3D(minX, minY, 0.34f, centerX, centerY, cellSizePx),
                camera.project3D(maxX, minY, 0.34f, centerX, centerY, cellSizePx),
                camera.project3D(maxX, maxY, 0.34f, centerX, centerY, cellSizePx),
                camera.project3D(minX, maxY, 0.34f, centerX, centerY, cellSizePx)
            )
            val l1Path = Path().apply {
                moveTo(l1Corners[0].screenX, l1Corners[0].screenY)
                for (i in 1..3) lineTo(l1Corners[i].screenX, l1Corners[i].screenY)
                close()
            }
            drawPath(
                path = l1Path,
                color = Color(0x140284C7)
            )
            drawPath(
                path = l1Path,
                color = Color(0x400284C7),
                style = Stroke(width = 2f * camera.zoom)
            )
        }
    }
}

private fun DrawScope.drawHintExitRay3D(
    camera: CameraController,
    block: ArrowBlock,
    rayCells: List<GridPos3D>,
    halfW: Float,
    halfH: Float,
    centerX: Float,
    centerY: Float,
    cellSizePx: Float,
    pulsePhase: Float
) {
    val zRay = block.layer * 0.36f + 0.10f
    val allPoints = buildList {
        add(block.head)
        addAll(rayCells)
    }.map { c ->
        camera.project3D(
            wx = c.x - halfW,
            wy = c.y - halfH,
            wz = zRay,
            centerX = centerX,
            centerY = centerY,
            cellSizePx = cellSizePx
        )
    }

    if (allPoints.size < 2) return
    val rayPath = Path().apply {
        moveTo(allPoints.first().screenX, allPoints.first().screenY)
        for (i in 1 until allPoints.size) {
            lineTo(allPoints[i].screenX, allPoints[i].screenY)
        }
    }

    val glowAlpha = 0.25f + 0.25f * sin(pulsePhase * 2f * PI.toFloat())
    drawPath(
        path = rayPath,
        color = Color(0xFF00B4D8).copy(alpha = glowAlpha),
        style = Stroke(
            width = cellSizePx * camera.zoom * 0.16f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    )

    // Animated pulsing dot travelling along the free path
    val headPt = allPoints.first()
    val endPt = allPoints.last()
    val dotX = headPt.screenX + (endPt.screenX - headPt.screenX) * pulsePhase
    val dotY = headPt.screenY + (endPt.screenY - headPt.screenY) * pulsePhase
    drawCircle(
        color = ElectricCyan,
        radius = cellSizePx * camera.zoom * 0.075f,
        center = Offset(dotX, dotY)
    )
}

private fun DrawScope.draw3DArrowBlock(
    camera: CameraController,
    block: ArrowBlock,
    slideDistanceUnits: Float,
    isHinted: Boolean,
    isBlockedMover: Boolean,
    isBlockerTarget: Boolean,
    pulsePhase: Float,
    halfW: Float,
    halfH: Float,
    centerX: Float,
    centerY: Float,
    cellSizePx: Float,
    graphicsQuality: GraphicsQuality,
    alpha: Float
) {
    val dx = block.direction.dx * slideDistanceUnits
    val dy = block.direction.dy * slideDistanceUnits

    val zShadow = (block.layer * 0.36f + 0.015f).coerceAtLeast(0.015f)
    val zBase = block.layer * 0.36f + 0.035f
    val zTop = block.layer * 0.36f + 0.155f

    val shadowPts = block.cells.map { c ->
        camera.project3D(
            wx = c.x - halfW + dx + 0.05f,
            wy = c.y - halfH + dy + 0.08f,
            wz = zShadow,
            centerX = centerX,
            centerY = centerY,
            cellSizePx = cellSizePx
        )
    }

    val basePts = block.cells.map { c ->
        camera.project3D(
            wx = c.x - halfW + dx,
            wy = c.y - halfH + dy,
            wz = zBase,
            centerX = centerX,
            centerY = centerY,
            cellSizePx = cellSizePx
        )
    }

    val topPts = block.cells.map { c ->
        camera.project3D(
            wx = c.x - halfW + dx,
            wy = c.y - halfH + dy,
            wz = zTop,
            centerX = centerX,
            centerY = centerY,
            cellSizePx = cellSizePx
        )
    }

    // Project a point slightly ahead of head in block.direction to orient the 3D arrowhead
    val headCell = block.head
    val tipExtend = 0.21f
    val tipTopPt = camera.project3D(
        wx = headCell.x - halfW + dx + block.direction.dx * tipExtend,
        wy = headCell.y - halfH + dy + block.direction.dy * tipExtend,
        wz = zTop,
        centerX = centerX,
        centerY = centerY,
        cellSizePx = cellSizePx
    )
    val tipBasePt = camera.project3D(
        wx = headCell.x - halfW + dx + block.direction.dx * tipExtend,
        wy = headCell.y - halfH + dy + block.direction.dy * tipExtend,
        wz = zBase,
        centerX = centerX,
        centerY = centerY,
        cellSizePx = cellSizePx
    )

    val mainColor = when {
        isBlockedMover -> HeartRed
        isBlockerTarget -> Color(0xFFFF8A00)
        isHinted -> Color(0xFF0096FF)
        block.layer == 1 -> BlockPaletteLayer1[block.colorIndex % BlockPaletteLayer1.size]
        block.layer >= 2 -> BlockPaletteLayer2[block.colorIndex % BlockPaletteLayer2.size]
        else -> BlockPaletteTop[block.colorIndex % BlockPaletteTop.size]
    }.copy(alpha = alpha)

    val sideWallColor = darkenColor(mainColor, 0.62f).copy(alpha = alpha)
    val bevelHighlightColor = lightenColor(mainColor, 0.32f).copy(alpha = alpha * 0.75f)

    val strokeWidthPx = (cellSizePx * camera.zoom * 0.135f).coerceAtLeast(2.8f)

    // 1. Soft Drop Shadow on the board
    if (graphicsQuality != GraphicsQuality.PERFORMANCE) {
        val shadowPath = buildPolylinePath(shadowPts)
        drawPath(
            path = shadowPath,
            color = Color(0x280A1428).copy(alpha = 0.18f * alpha),
            style = Stroke(
                width = strokeWidthPx * 1.18f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }

    // 2. Hint Halo Aura if this block is highlighted
    if (isHinted) {
        val haloPulse = 1.35f + 0.22f * sin(pulsePhase * 2f * PI.toFloat())
        val topPath = buildPolylinePath(topPts)
        drawPath(
            path = topPath,
            color = ElectricCyan.copy(alpha = 0.42f * alpha),
            style = Stroke(
                width = strokeWidthPx * haloPulse,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }

    // 3. 3D Extruded Side Walls (Base path + vertical joints + intermediate slices for solid 3D extrusion)
    val basePath = buildPolylinePath(basePts)
    drawPath(
        path = basePath,
        color = sideWallColor,
        style = Stroke(
            width = strokeWidthPx * 1.04f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    )
    // Mid-height slice so steep 3D camera angles look completely solid
    val midPath = Path().apply {
        val mx0 = (basePts.first().screenX + topPts.first().screenX) * 0.5f
        val my0 = (basePts.first().screenY + topPts.first().screenY) * 0.5f
        moveTo(mx0, my0)
        for (i in 1 until topPts.size) {
            lineTo(
                (basePts[i].screenX + topPts[i].screenX) * 0.5f,
                (basePts[i].screenY + topPts[i].screenY) * 0.5f
            )
        }
    }
    drawPath(
        path = midPath,
        color = sideWallColor,
        style = Stroke(
            width = strokeWidthPx * 1.02f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    )

    // 4. 3D Top Surface Spine
    val topPath = buildPolylinePath(topPts)
    drawPath(
        path = topPath,
        color = mainColor,
        style = Stroke(
            width = strokeWidthPx,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    )

    // 5. 3D Beveled Inner Specular Ridge
    drawPath(
        path = topPath,
        color = bevelHighlightColor,
        style = Stroke(
            width = strokeWidthPx * 0.32f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    )

    // 6. 3D Sculpted Arrowhead at the head cell
    val headTopPt = topPts.last()
    val headBasePt = basePts.last()
    val angleRad = atan2(
        tipTopPt.screenY - headTopPt.screenY,
        tipTopPt.screenX - headTopPt.screenX
    )
    val arrowSize = strokeWidthPx * 1.12f

    // Draw 3D base extrusion of the arrowhead first
    drawArrowheadTriangle(
        tipX = tipBasePt.screenX,
        tipY = tipBasePt.screenY,
        angleRad = angleRad,
        sizePx = arrowSize * 1.04f,
        color = sideWallColor
    )

    // Draw 3D top face of the arrowhead
    drawArrowheadTriangle(
        tipX = tipTopPt.screenX,
        tipY = tipTopPt.screenY,
        angleRad = angleRad,
        sizePx = arrowSize,
        color = mainColor
    )

    // Draw bright specular highlight triangle inside the arrowhead
    drawArrowheadTriangle(
        tipX = tipTopPt.screenX - cos(angleRad) * (arrowSize * 0.15f),
        tipY = tipTopPt.screenY - sin(angleRad) * (arrowSize * 0.15f),
        angleRad = angleRad,
        sizePx = arrowSize * 0.48f,
        color = bevelHighlightColor
    )

    // If multi-layer block (z > 0), draw a tiny elevation badge dot on the tail so layer height is super clear
    if (block.layer > 0) {
        val tailPt = topPts.first()
        drawCircle(
            color = AccentGold.copy(alpha = alpha),
            radius = strokeWidthPx * 0.22f,
            center = Offset(tailPt.screenX, tailPt.screenY)
        )
    }
}

private fun buildPolylinePath(points: List<CameraController.ProjectedPoint>): Path {
    return Path().apply {
        if (points.isNotEmpty()) {
            moveTo(points.first().screenX, points.first().screenY)
            for (i in 1 until points.size) {
                lineTo(points[i].screenX, points[i].screenY)
            }
        }
    }
}

private fun DrawScope.drawArrowheadTriangle(
    tipX: Float,
    tipY: Float,
    angleRad: Float,
    sizePx: Float,
    color: Color
) {
    val wingSpread = 2.52f // ~144 degrees backward from tip
    val leftX = tipX + cos(angleRad + wingSpread) * sizePx
    val leftY = tipY + sin(angleRad + wingSpread) * sizePx
    val rightX = tipX + cos(angleRad - wingSpread) * sizePx
    val rightY = tipY + sin(angleRad - wingSpread) * sizePx
    val backCenterX = tipX - cos(angleRad) * (sizePx * 0.58f)
    val backCenterY = tipY - sin(angleRad) * (sizePx * 0.58f)

    val path = Path().apply {
        moveTo(tipX, tipY)
        lineTo(leftX, leftY)
        lineTo(backCenterX, backCenterY)
        lineTo(rightX, rightY)
        close()
    }
    drawPath(path = path, color = color)
    drawPath(
        path = path,
        color = color,
        style = Stroke(width = sizePx * 0.22f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}

private fun darkenColor(color: Color, factor: Float): Color {
    return Color(
        red = (color.red * factor).coerceIn(0f, 1f),
        green = (color.green * factor).coerceIn(0f, 1f),
        blue = (color.blue * factor).coerceIn(0f, 1f),
        alpha = color.alpha
    )
}

private fun lightenColor(color: Color, amount: Float): Color {
    return Color(
        red = (color.red + (1f - color.red) * amount).coerceIn(0f, 1f),
        green = (color.green + (1f - color.green) * amount).coerceIn(0f, 1f),
        blue = (color.blue + (1f - color.blue) * amount).coerceIn(0f, 1f),
        alpha = color.alpha
    )
}
