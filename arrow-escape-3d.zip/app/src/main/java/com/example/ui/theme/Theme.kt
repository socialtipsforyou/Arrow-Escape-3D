package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF2979FF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1C2B4F),
    onPrimaryContainer = Color(0xFFD6E4FF),
    secondary = ElectricCyan,
    onSecondary = Color(0xFF002633),
    secondaryContainer = Color(0xFF164E63),
    onSecondaryContainer = Color(0xFFCFFAFE),
    tertiary = AccentGold,
    onTertiary = Color(0xFF332400),
    background = NavyDeep,
    onBackground = Color(0xFFF8FAFC),
    surface = NavySurface,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = NavyCard,
    onSurfaceVariant = Color(0xFFCBD5E1),
    error = HeartRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF1A73E8),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8F0FE),
    onPrimaryContainer = Color(0xFF0F294D),
    secondary = Color(0xFF00B4D8),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F7FA),
    onSecondaryContainer = Color(0xFF003642),
    tertiary = AccentGold,
    onTertiary = Color(0xFF2A1D00),
    background = LightBackground,
    onBackground = Color(0xFF14223D),
    surface = LightSurface,
    onSurface = Color(0xFF14223D),
    surfaceVariant = LightCard,
    onSurfaceVariant = Color(0xFF475569),
    error = HeartRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
