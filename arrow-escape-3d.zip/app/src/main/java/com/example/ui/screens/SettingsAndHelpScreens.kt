package com.example.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.UnityAdsManager
import com.example.domain.GameUiState
import com.example.domain.ScreenDestination
import com.example.model.GraphicsQuality
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BrightBlue
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.HeartRed
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface

@Composable
fun SettingsScreen(
    uiState: GameUiState,
    onSoundToggle: (Boolean) -> Unit,
    onMusicToggle: (Boolean) -> Unit,
    onVibrationToggle: (Boolean) -> Unit,
    onGraphicsQualitySelected: (GraphicsQuality) -> Unit,
    onResetProgressConfirmed: () -> Unit,
    onNavigate: (ScreenDestination) -> Unit,
    accountDisplayName: String? = null,
    accountEmail: String? = null,
    onOpenAccountPanelClicked: (() -> Unit)? = null,
    onSignOutClicked: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onNavigate(ScreenDestination.MAIN_MENU)
    }

    var showResetConfirmDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(NavyDeep, Color(0xFF0F1D3A))))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onNavigate(ScreenDestination.MAIN_MENU) },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "SETTINGS",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Audio & Haptics Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "AUDIO & HAPTICS",
                        color = ElectricCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    SettingSwitchItem(
                        icon = Icons.Default.VolumeUp,
                        title = "Sound Effects",
                        subtitle = "Synthesized arrow whoosh, collision & celebration sounds",
                        checked = uiState.soundEnabled,
                        onCheckedChange = onSoundToggle,
                        tag = "switch_sound"
                    )

                    SettingSwitchItem(
                        icon = Icons.Default.MusicNote,
                        title = "Background Music",
                        subtitle = "Ambient puzzle synth chords during gameplay",
                        checked = uiState.musicEnabled,
                        onCheckedChange = onMusicToggle,
                        tag = "switch_music"
                    )

                    SettingSwitchItem(
                        icon = Icons.Default.Vibration,
                        title = "Haptic Vibration",
                        subtitle = "Tactile feedback on arrow slides and blocked moves",
                        checked = uiState.vibrationEnabled,
                        onCheckedChange = onVibrationToggle,
                        tag = "switch_vibration"
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3D Graphics Quality Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = AccentGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "3D GRAPHICS QUALITY",
                            color = AccentGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    GraphicsQuality.entries.forEach { quality ->
                        FilterChip(
                            selected = uiState.graphicsQuality == quality,
                            onClick = { onGraphicsQualitySelected(quality) },
                            label = {
                                Text(
                                    text = quality.label,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BrightBlue,
                                selectedLabelColor = Color.White,
                                containerColor = NavyCard,
                                labelColor = Color(0xFFCBD5E1)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .testTag("graphics_quality_${quality.name.lowercase()}")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Data & Progress Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "PROGRESS & SAVE DATA",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Unlocked Level: ${uiState.highestUnlockedLevel} • Completed: ${uiState.completedLevels.size} Levels • Seed: #${uiState.gameSeed}",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedButton(
                        onClick = { showResetConfirmDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("reset_progress_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = HeartRed)
                    ) {
                        Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Reset All Progress",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (onSignOutClicked != null && (!accountDisplayName.isNullOrBlank() || !accountEmail.isNullOrBlank())) {
                Spacer(modifier = Modifier.height(16.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "FIREBASE ACCOUNT",
                            color = ElectricCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        if (!accountDisplayName.isNullOrBlank()) {
                            Text(
                                text = accountDisplayName,
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (!accountEmail.isNullOrBlank()) {
                            Text(
                                text = accountEmail,
                                color = Color(0xFF94A3B8),
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        if (onOpenAccountPanelClicked != null) {
                            Button(
                                onClick = onOpenAccountPanelClicked,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("open_account_panel_button"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BrightBlue,
                                    contentColor = Color.White
                                )
                            ) {
                                Text(
                                    text = "Back to Account Home Panel",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                        }
                        OutlinedButton(
                            onClick = onSignOutClicked,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("sign_out_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Text(
                                text = "Sign Out",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Developer-Only Unity Ads Diagnostics Card
            val currentActivity = LocalContext.current as? Activity
            UnityAdsDebugStatusCard(
                onTestRewarded = {
                    if (currentActivity != null) {
                        UnityAdsManager.showRewardedAd(
                            activity = currentActivity,
                            onRewardGranted = {},
                            onAdClosed = {}
                        )
                    }
                },
                onTestInterstitial = {
                    if (currentActivity != null) {
                        UnityAdsManager.showInterstitialIfAppropriate(
                            activity = currentActivity,
                            onAdDismissed = {}
                        )
                    }
                },
                onForceReload = {
                    UnityAdsManager.preloadRewardedAd()
                    UnityAdsManager.preloadInterstitialAd()
                }
            )
        }

        if (showResetConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showResetConfirmDialog = false },
                title = { Text("Reset Progress?", fontWeight = FontWeight.Bold) },
                text = {
                    Text("This will reset your completed levels, stars, coins, and scores back to Level 1. Are you sure?")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showResetConfirmDialog = false
                            onResetProgressConfirmed()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = HeartRed),
                        modifier = Modifier.testTag("confirm_reset_button")
                    ) {
                        Text("Reset Everything", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showResetConfirmDialog = false },
                        modifier = Modifier.testTag("cancel_reset_button")
                    ) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
private fun SettingSwitchItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(NavyCard),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = ElectricCyan)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(tag)
        )
    }
}

@Composable
fun HowToPlayScreen(
    onStartPlaying: () -> Unit,
    onNavigate: (ScreenDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onNavigate(ScreenDestination.MAIN_MENU)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(NavyDeep, Color(0xFF0F1D3A))))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onNavigate(ScreenDestination.MAIN_MENU) },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("howto_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "HOW TO PLAY",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            GuideStepCard(
                stepNumber = "1",
                icon = Icons.Default.NearMe,
                accentColor = ElectricCyan,
                title = "Tap Arrows with a Free Path",
                description = "Each 3D arrow block points in a specific exit direction (Up, Down, Left, or Right). Tap an arrow ONLY when no other block is directly in front of its arrowhead!"
            )

            Spacer(modifier = Modifier.height(12.dp))

            GuideStepCard(
                stepNumber = "2",
                icon = Icons.Default.Favorite,
                accentColor = HeartRed,
                title = "Avoid Blocked Paths",
                description = "If another arrow block is sitting in its path, the arrow will bump and shake, costing 1 Heart. Look ahead and untangle outer arrows first to free the inner ones!"
            )

            Spacer(modifier = Modifier.height(12.dp))

            GuideStepCard(
                stepNumber = "3",
                icon = Icons.Default.ViewInAr,
                accentColor = AccentGold,
                title = "Rotate 3D Multi-Layer Boards",
                description = "Swipe on the board to smoothly orbit the 3D camera, pinch to zoom, or tap '3D Tilt / Top 3D'. On multi-layer 3D boards, clear top-layer blocks before removing blocks directly underneath them."
            )

            Spacer(modifier = Modifier.height(12.dp))

            GuideStepCard(
                stepNumber = "4",
                icon = Icons.Default.Lightbulb,
                accentColor = EmeraldSuccess,
                title = "Use Helpful Hints & Undo",
                description = "Stuck on a complex formation? Tap the Lightbulb Hint button to highlight a guaranteed movable arrow and its glowing exit path!"
            )

            Spacer(modifier = Modifier.height(22.dp))

            Button(
                onClick = onStartPlaying,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .height(58.dp)
                    .testTag("howto_play_now_button"),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrightBlue)
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("START PLAYING NOW", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun GuideStepCard(
    stepNumber: String,
    icon: ImageVector,
    accentColor: Color,
    title: String,
    description: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 600.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface)
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accentColor)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = "STEP $stepNumber • $title",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    color = Color(0xFFCBD5E1),
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            }
        }
    }
}
