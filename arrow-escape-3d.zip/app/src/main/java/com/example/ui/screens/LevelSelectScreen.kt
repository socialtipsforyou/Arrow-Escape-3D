package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LevelProgressEntity
import com.example.domain.GameUiState
import com.example.domain.ScreenDestination
import com.example.model.DifficultyTier
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BrightBlue
import com.example.ui.theme.CoralWarning
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.HeartRed
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.PurpleExpert

@Composable
fun LevelSelectScreen(
    uiState: GameUiState,
    onSelectLevel: (Int) -> Unit,
    onChangePage: (Int) -> Unit,
    onNavigate: (ScreenDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onNavigate(ScreenDestination.MAIN_MENU)
    }

    val levelsPerPage = 50
    val currentPage = uiState.levelSelectPage.coerceAtLeast(0)
    val startLevel = currentPage * levelsPerPage + 1
    val endLevel = startLevel + levelsPerPage - 1
    val levelRange = (startLevel..endLevel).toList()

    var showJumpDialog by remember { mutableStateOf(false) }
    var customLevelInput by remember { mutableStateOf("") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(NavyDeep, Color(0xFF0E1B36))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onNavigate(ScreenDestination.MAIN_MENU) },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("level_select_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "SELECT LEVEL",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Levels $startLevel – $endLevel • Unlimited Procedural",
                        color = ElectricCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                IconButton(
                    onClick = { showJumpDialog = true },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(NavyCard)
                        .testTag("jump_level_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Jump to Level Number",
                        tint = ElectricCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Difficulty Tier Page Chips
            val tierPages = listOf(
                0 to "1–50 (Easy/Normal)",
                1 to "51–100 (Hard)",
                2 to "101–150 (Expert)",
                3 to "151–200 (Expert)",
                4 to "201–250 (Master)",
                9 to "451–500 (Extreme)"
            )

            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tierPages.size) { idx ->
                    val (pageIndex, label) = tierPages[idx]
                    FilterChip(
                        selected = currentPage == pageIndex,
                        onClick = { onChangePage(pageIndex) },
                        label = {
                            Text(
                                text = label,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BrightBlue,
                            selectedLabelColor = Color.White,
                            containerColor = NavyCard,
                            labelColor = Color(0xFFCBD5E1)
                        ),
                        modifier = Modifier.testTag("tier_page_chip_$pageIndex")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Paginated Level Grid (50 levels per page)
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 72.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .testTag("level_select_grid"),
                contentPadding = PaddingValues(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(levelRange, key = { it }) { levelNum ->
                    val progress = uiState.completedLevels[levelNum]
                    val isUnlocked = levelNum <= uiState.highestUnlockedLevel || progress?.completed == true
                    val isCurrent = levelNum == uiState.currentLevelNumber
                    LevelGridCell(
                        levelNumber = levelNum,
                        isUnlocked = isUnlocked,
                        isCurrent = isCurrent,
                        progress = progress,
                        onClick = {
                            // Allow playing unlocked levels, or previewing higher tier levels directly
                            onSelectLevel(levelNum)
                        }
                    )
                }
            }

            // Pagination Bar for Unlimited Levels
            Surface(
                color = NavySurface,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .padding(top = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { onChangePage((currentPage - 1).coerceAtLeast(0)) },
                        enabled = currentPage > 0,
                        modifier = Modifier.testTag("prev_page_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Previous 50 Levels",
                            tint = if (currentPage > 0) Color.White else Color(0xFF475569)
                        )
                    }

                    Text(
                        text = "Page ${currentPage + 1} • Levels $startLevel–$endLevel",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    IconButton(
                        onClick = { onChangePage(currentPage + 1) },
                        modifier = Modifier.testTag("next_page_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Next 50 Levels",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        if (showJumpDialog) {
            AlertDialog(
                onDismissRequest = { showJumpDialog = false },
                title = { Text("Jump to Any Level #", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            "Enter any level number (1 to 999,999) to generate and play its deterministic 3D puzzle:",
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = customLevelInput,
                            onValueChange = { input ->
                                customLevelInput = input.filter { it.isDigit() }.take(6)
                            },
                            label = { Text("Level Number") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = androidx.compose.ui.text.input.ImeAction.Done
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("jump_level_input")
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val target = customLevelInput.toIntOrNull()?.coerceAtLeast(1) ?: 1
                            showJumpDialog = false
                            onSelectLevel(target)
                        },
                        modifier = Modifier.testTag("jump_level_confirm_button")
                    ) {
                        Text("Play Level")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showJumpDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
private fun LevelGridCell(
    levelNumber: Int,
    isUnlocked: Boolean,
    isCurrent: Boolean,
    progress: LevelProgressEntity?,
    onClick: () -> Unit
) {
    val tier = DifficultyTier.forLevel(levelNumber)
    val tierColor = when (tier) {
        DifficultyTier.EASY -> EmeraldSuccess
        DifficultyTier.NORMAL -> BrightBlue
        DifficultyTier.HARD -> AccentGold
        DifficultyTier.EXPERT -> PurpleExpert
        DifficultyTier.MASTER -> HeartRed
    }

    val containerColor = when {
        isCurrent -> BrightBlue
        progress?.completed == true -> Color(0xFF1A365D)
        isUnlocked -> NavyCard
        else -> Color(0xFF131D33)
    }

    Card(
        modifier = Modifier
            .aspectRatio(0.92f)
            .clip(RoundedCornerShape(16.dp))
            .then(
                if (isCurrent) {
                    Modifier.border(2.dp, ElectricCyan, RoundedCornerShape(16.dp))
                } else {
                    Modifier
                }
            )
            .clickable(onClick = onClick)
            .testTag("level_cell_$levelNumber"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Row: Tier badge + Completed / Lock Icon
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(tierColor)
                )
                if (progress?.completed == true) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Completed",
                        tint = EmeraldSuccess,
                        modifier = Modifier.size(14.dp)
                    )
                } else if (!isUnlocked) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked",
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(13.dp)
                    )
                } else {
                    Spacer(modifier = Modifier.size(13.dp))
                }
            }

            // Center Level Number
            Text(
                text = "$levelNumber",
                color = if (isUnlocked || isCurrent) Color.White else Color(0xFF94A3B8),
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold
            )

            // Bottom Stars or Difficulty Label
            if ((progress?.stars ?: 0) > 0) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (s in 1..3) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (s <= (progress?.stars ?: 0)) AccentGold else Color(0xFF475569),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            } else {
                Text(
                    text = tier.displayName,
                    color = tierColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
