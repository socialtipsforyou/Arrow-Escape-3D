package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary dark & light puzzle palette inspired by modern 3D casual puzzle games
val NavyDeep = Color(0xFF0A1124)
val NavySurface = Color(0xFF131E38)
val NavyCard = Color(0xFF1C2B4F)
val NavyElevated = Color(0xFF253864)

val LightBackground = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFEAF0F8)

val ElectricCyan = Color(0xFF00E5FF)
val RoyalBlue = Color(0xFF1E88E5)
val BrightBlue = Color(0xFF2979FF)
val DeepArrowNavy = Color(0xFF14223D)
val MidArrowBlue = Color(0xFF1F3A68)
val AccentGold = Color(0xFFFFB800)
val HeartRed = Color(0xFFFF3B5C)
val EmeraldSuccess = Color(0xFF10B981)
val CoralWarning = Color(0xFFFF6B4A)
val PurpleExpert = Color(0xFF8B5CF6)

val BlockPaletteTop = listOf(
    Color(0xFF182C4E), // Classic Deep Navy
    Color(0xFF1E3F66), // Cobalt Slate
    Color(0xFF164E63), // Deep Teal
    Color(0xFF283593), // Indigo
    Color(0xFF0F3D5E), // Ocean Blue
    Color(0xFF312E81)  // Royal Violet
)

val BlockPaletteLayer1 = listOf(
    Color(0xFF0284C7), // Elevated Layer 1 Sky Blue
    Color(0xFF0D9488), // Elevated Layer 1 Teal
    Color(0xFF4F46E5)  // Elevated Layer 1 Indigo
)

val BlockPaletteLayer2 = listOf(
    Color(0xFFF59E0B), // Top Layer 2 Amber Gold
    Color(0xFFEC4899), // Top Layer 2 Rose
    Color(0xFF06B6D4)  // Top Layer 2 Cyan
)
