package com.example.domain

import com.example.model.ArrowBlock
import com.example.model.GridPos3D
import com.example.model.MoveRecord
import com.example.model.PathCheckResult

/**
 * BoardManager manages the 3D puzzle board occupancy, collision/path checking,
 * upper-layer lock rules, block removal, undo stack, and solvability verification.
 */
class BoardManager {
    private var gridWidth: Int = 8
    private var gridHeight: Int = 8
    private var layers: Int = 1

    private val activeBlocks = LinkedHashMap<Int, ArrowBlock>()
    private val cellOccupancy = HashMap<GridPos3D, Int>() // GridPos3D -> blockId
    private val undoStack = ArrayDeque<MoveRecord>()

    fun loadBoard(
        width: Int,
        height: Int,
        layerCount: Int,
        blocks: List<ArrowBlock>
    ) {
        gridWidth = width
        gridHeight = height
        layers = layerCount
        activeBlocks.clear()
        cellOccupancy.clear()
        undoStack.clear()

        for (block in blocks) {
            activeBlocks[block.id] = block
            for (cell in block.cells) {
                cellOccupancy[cell] = block.id
            }
        }
    }

    fun getRemainingBlocks(): List<ArrowBlock> = activeBlocks.values.toList()

    fun getRemainingCount(): Int = activeBlocks.size

    fun getBlock(blockId: Int): ArrowBlock? = activeBlocks[blockId]

    fun canUndo(): Boolean = undoStack.isNotEmpty()

    /**
     * Checks whether the given [block] can move freely out of the 3D board in its [block.direction].
     *
     * Rules:
     * 1. Upper-layer lock (for multi-layer 3D boards): If any block occupies directly above
     *    any cell of [block] at (cell.x, cell.y, z + 1), the block is locked from above.
     * 2. Forward exit path: Trace from [block.head] in [block.direction] step-by-step until
     *    exiting [0 until gridWidth, 0 until gridHeight] on the same layer [block.layer].
     *    Also check if any body segment moving along the path would hit another block.
     *    Since an arrow slides along its own spine and exits forward from its head,
     *    its path is clear if and only if every cell along the ray from (head + direction)
     *    to the board edge is either empty or part of [block] itself.
     */
    fun checkBlockPath(blockId: Int): PathCheckResult {
        val block = activeBlocks[blockId] ?: return PathCheckResult.Clear

        // 1. Check if a block on an upper 3D layer is resting directly on top of this block
        if (layers > 1 && block.layer < layers - 1) {
            for (cell in block.cells) {
                for (upperZ in (cell.z + 1) until layers) {
                    val abovePos = GridPos3D(cell.x, cell.y, upperZ)
                    val blockerId = cellOccupancy[abovePos]
                    if (blockerId != null && blockerId != block.id) {
                        return PathCheckResult.BlockedByUpperLayer(
                            blockingBlockId = blockerId,
                            collisionCell = abovePos
                        )
                    }
                }
            }
        }

        // 2. Trace ray from head in block.direction until outside the board bounds
        var cursor = block.head.step(block.direction)
        var freeSteps = 0
        while (isInsideLayerBounds(cursor)) {
            val occupantId = cellOccupancy[cursor]
            if (occupantId != null && occupantId != block.id) {
                return PathCheckResult.BlockedByPath(
                    blockingBlockId = occupantId,
                    collisionCell = cursor,
                    freeStepsBeforeCollision = freeSteps
                )
            }
            freeSteps++
            cursor = cursor.step(block.direction)
        }

        return PathCheckResult.Clear
    }

    /**
     * Returns all currently movable (unblocked) blocks on the board.
     */
    fun getMovableBlocks(): List<ArrowBlock> {
        return activeBlocks.values.filter { checkBlockPath(it.id) is PathCheckResult.Clear }
    }

    /**
     * Removes a block from the board after verifying or initiating a valid move.
     */
    fun removeBlock(blockId: Int, scoreDelta: Int): ArrowBlock? {
        val block = activeBlocks.remove(blockId) ?: return null
        for (cell in block.cells) {
            if (cellOccupancy[cell] == blockId) {
                cellOccupancy.remove(cell)
            }
        }
        undoStack.addLast(MoveRecord(removedBlock = block, scoreDelta = scoreDelta))
        return block
    }

    /**
     * Restores the most recently removed block to the board.
     */
    fun undoLastMove(): MoveRecord? {
        if (undoStack.isEmpty()) return null
        val record = undoStack.removeLast()
        val block = record.removedBlock
        activeBlocks[block.id] = block
        for (cell in block.cells) {
            cellOccupancy[cell] = block.id
        }
        return record
    }

    fun isBoardCleared(): Boolean = activeBlocks.isEmpty()

    fun isInsideLayerBounds(pos: GridPos3D): Boolean {
        return pos.x in 0 until gridWidth &&
            pos.y in 0 until gridHeight &&
            pos.z in 0 until layers
    }

    /**
     * Computes the list of 3D grid cells along the exit ray from [block.head] to the board edge.
     * Used for rendering the glowing hint path trajectory.
     */
    fun getExitRayCells(block: ArrowBlock): List<GridPos3D> {
        val ray = mutableListOf<GridPos3D>()
        var cursor = block.head.step(block.direction)
        while (isInsideLayerBounds(cursor)) {
            ray.add(cursor)
            cursor = cursor.step(block.direction)
        }
        // Add one final cell just outside the board to show the exit arrow leaving the grid
        ray.add(cursor)
        return ray
    }

    companion object {
        /**
         * Pure static verification that a generated board configuration is 100% solvable
         * from start to finish by greedily peeling movable blocks.
         * Returns a valid solution sequence of block IDs if solvable, or null if deadlocked.
         */
        fun findSolutionOrder(
            width: Int,
            height: Int,
            layers: Int,
            blocks: List<ArrowBlock>
        ): List<Int>? {
            val simulator = BoardManager()
            simulator.loadBoard(width, height, layers, blocks)
            val solution = ArrayList<Int>(blocks.size)

            while (!simulator.isBoardCleared()) {
                val movable = simulator.getMovableBlocks()
                if (movable.isEmpty()) {
                    return null // Deadlock detected
                }
                // Pick the first movable block (or all in a wave)
                val next = movable.first()
                simulator.removeBlock(next.id, 0)
                solution.add(next.id)
            }
            return solution
        }
    }
}
