package com.example.domain

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.LevelProgressEntity
import com.example.data.PlayerStateEntity
import com.example.data.ProgressManager
import com.example.data.SaveManager
import com.example.model.ArrowBlock
import com.example.model.BlockedArrowState
import com.example.model.ConfettiParticle
import com.example.model.DifficultyTier
import com.example.model.FlyingArrowState
import com.example.model.GameMode
import com.example.model.GraphicsQuality
import com.example.model.GridPos3D
import com.example.model.LevelConfig
import com.example.model.Particle3D
import com.example.model.PathCheckResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class ScreenDestination {
    MAIN_MENU,
    PLAYING,
    LEVEL_SELECT,
    HOW_TO_PLAY,
    SETTINGS
}

data class GameUiState(
    val screen: ScreenDestination = ScreenDestination.MAIN_MENU,
    val currentLevelNumber: Int = 1,
    val highestUnlockedLevel: Int = 1,
    val levelConfig: LevelConfig? = null,
    val activeBlocks: List<ArrowBlock> = emptyList(),
    val initialBlockCount: Int = 0,
    val remainingBlockCount: Int = 0,
    val hearts: Int = 3,
    val maxHearts: Int = 3,
    val coins: Int = 100,
    val hints: Int = 3,
    val currentScore: Int = 0,
    val bestTotalScore: Int = 0,
    val comboCount: Int = 0,
    val canUndo: Boolean = false,
    val isPaused: Boolean = false,
    val isLevelComplete: Boolean = false,
    val isGameOver: Boolean = false,
    val gameOverReason: String = "Out of Hearts!",
    val starsEarned: Int = 3,
    val coinsEarnedThisLevel: Int = 0,
    val doubleCoinsClaimed: Boolean = false,
    val activeHintBlockId: Int? = null,
    val activeHintRay: List<GridPos3D> = emptyList(),
    val flyingArrows: List<FlyingArrowState> = emptyList(),
    val blockedArrowState: BlockedArrowState? = null,
    val particles3D: List<Particle3D> = emptyList(),
    val confettiParticles: List<ConfettiParticle> = emptyList(),
    val showGridPegs: Boolean = true,
    val cameraYaw: Float = -14f,
    val cameraPitch: Float = 26f,
    val cameraZoom: Float = 1.26f,
    val isIsometric3D: Boolean = true,
    val remainingSeconds: Int? = null,
    val remainingMoves: Int? = null,
    val soundEnabled: Boolean = true,
    val musicEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val graphicsQuality: GraphicsQuality = GraphicsQuality.HIGH,
    val gameSeed: Long = 2026L,
    val completedLevels: Map<Int, LevelProgressEntity> = emptyMap(),
    val levelSelectPage: Int = 0,
    val statusBannerMessage: String? = null,
    val lastCoinRewardFeedback: String? = null
)

const val LEVEL_COMPLETION_COIN_REWARD = 20

/**
 * GameManager (implemented as a lifecycle-aware ViewModel) coordinates all game systems:
 * LevelManager, BoardManager, LivesManager, HintManager, CameraController, InputManager,
 * AudioManager, SaveManager, ProgressManager, and RewardedAdHooks.
 */
class GameManager(
    private val saveManager: SaveManager,
    private val progressManager: ProgressManager,
    val audioManager: AudioManager,
    val levelManager: LevelManager = LevelManager(),
    val boardManager: BoardManager = BoardManager(),
    val livesManager: LivesManager = LivesManager(),
    val hintManager: HintManager = HintManager(),
    val cameraController: CameraController = CameraController(),
    val inputManager: InputManager = InputManager(),
    val rewardedAdHooks: RewardedAdHooks = SafeRewardedAdManager()
) : ViewModel() {

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var animationLoopJob: Job? = null
    private var timerJob: Job? = null

    private var authenticatedUid: String? = null
    private var authenticatedCoins: Int? = null
    private val authenticatedRewardedLevels = mutableSetOf<Int>()
    private var isManualLevelSelection: Boolean = false
    private var lastSyncedUid: String? = null
    private var lastSyncedCoins: Long? = null
    private var lastSyncedRewardedLevels: Set<Int>? = null
    var onAuthenticatedLevelCompleted: ((levelNumber: Int) -> Int)? = null
    var onSafeGameplayMomentForInterstitial: (() -> Unit)? = null

    init {
        // Observe persisted player state and completed levels from Room
        viewModelScope.launch {
            val initialPlayer = saveManager.getOrCreatePlayerState()
            applyPlayerStateToManagers(initialPlayer)

            launch {
                saveManager.playerStateFlow.collect { state ->
                    if (state != null) {
                        applyPlayerStateToManagers(state)
                    }
                }
            }

            launch {
                saveManager.levelProgressFlow.collect { progressList ->
                    val map = progressList.associateBy { it.levelNumber }
                    _uiState.update { current ->
                        if (authenticatedUid != null) {
                            val authMap = authenticatedRewardedLevels.associateWith { lvl ->
                                map[lvl]?.copy(completed = true) ?: LevelProgressEntity(
                                    levelNumber = lvl,
                                    completed = true,
                                    stars = 3,
                                    bestScore = 300
                                )
                            }
                            current.copy(completedLevels = authMap)
                        } else {
                            current.copy(completedLevels = map)
                        }
                    }
                }
            }
        }
    }

    private fun applyPlayerStateToManagers(state: PlayerStateEntity) {
        audioManager.soundEnabled = state.soundEnabled
        audioManager.musicEnabled = state.musicEnabled
        audioManager.vibrationEnabled = state.vibrationEnabled
        val quality = GraphicsQuality.entries.getOrElse(state.graphicsQualityOrdinal) {
            GraphicsQuality.HIGH
        }
        _uiState.update { current ->
            val nextAuthLevel = ((authenticatedRewardedLevels.maxOrNull() ?: 0) + 1).coerceAtLeast(1)
            current.copy(
                currentLevelNumber = if (current.levelConfig == null) {
                    if (authenticatedUid != null) nextAuthLevel else state.currentLevel
                } else {
                    current.currentLevelNumber
                },
                highestUnlockedLevel = if (authenticatedUid != null) {
                    maxOf(nextAuthLevel, current.highestUnlockedLevel)
                } else {
                    state.highestUnlockedLevel.coerceAtLeast(1)
                },
                coins = authenticatedCoins ?: state.coins,
                hints = state.hints,
                bestTotalScore = state.bestTotalScore,
                soundEnabled = state.soundEnabled,
                musicEnabled = state.musicEnabled,
                vibrationEnabled = state.vibrationEnabled,
                graphicsQuality = quality,
                gameSeed = state.gameSeed
            )
        }
    }

    fun clearAuthenticatedSession() {
        authenticatedUid = null
        authenticatedCoins = null
        authenticatedRewardedLevels.clear()
        isManualLevelSelection = false
    }

    fun bindAuthenticatedProfile(
        uid: String,
        coins: Long,
        completedLevelsCount: Long = 0L,
        rewardedLevelIds: Set<Int>
    ) {
        val isNewUserSwitch = authenticatedUid != uid
        if (isNewUserSwitch) {
            isManualLevelSelection = false
        }
        authenticatedUid = uid
        authenticatedCoins = coins.toInt()

        val inferredRewarded = if (completedLevelsCount > 0L) {
            (1..completedLevelsCount.toInt().coerceAtMost(10_000)).toSet()
        } else {
            emptySet()
        }
        val effectiveRewardedLevels = rewardedLevelIds + inferredRewarded

        authenticatedRewardedLevels.clear()
        authenticatedRewardedLevels.addAll(effectiveRewardedLevels)

        val highestRewarded = maxOf(
            completedLevelsCount.toInt(),
            effectiveRewardedLevels.maxOrNull() ?: 0
        )
        val nextPlayableLevel = (highestRewarded + 1).coerceAtLeast(1)
        val currentState = _uiState.value
        val shouldStartNextPlayableLevel = isNewUserSwitch ||
            currentState.levelConfig == null ||
            (!isManualLevelSelection &&
                !currentState.isLevelComplete &&
                currentState.currentLevelNumber < nextPlayableLevel &&
                currentState.currentScore == 0)

        _uiState.update { current ->
            val authCompletedMap = effectiveRewardedLevels.associateWith { lvl ->
                val existing = current.completedLevels[lvl]
                LevelProgressEntity(
                    levelNumber = lvl,
                    completed = true,
                    stars = existing?.stars?.takeIf { it > 0 } ?: 3,
                    bestScore = existing?.bestScore?.takeIf { it > 0 } ?: 300
                )
            }
            val updatedUnlocked = if (isNewUserSwitch) {
                nextPlayableLevel
            } else {
                maxOf(current.highestUnlockedLevel, nextPlayableLevel)
            }
            current.copy(
                coins = coins.toInt(),
                completedLevels = authCompletedMap,
                highestUnlockedLevel = updatedUnlocked,
                currentLevelNumber = if (shouldStartNextPlayableLevel) {
                    nextPlayableLevel
                } else {
                    current.currentLevelNumber
                },
                lastCoinRewardFeedback = if (isNewUserSwitch) null else current.lastCoinRewardFeedback
            )
        }

        viewModelScope.launch {
            progressManager.syncFromAuthenticatedProfile(
                rewardedLevels = effectiveRewardedLevels,
                authoritativeCoins = coins.toInt()
            )
        }

        if (shouldStartNextPlayableLevel) {
            startLevel(nextPlayableLevel)
        }
    }

    fun selectLevelFromMap(levelNumber: Int) {
        isManualLevelSelection = true
        startLevel(levelNumber)
    }

    fun navigateTo(destination: ScreenDestination) {
        audioManager.playButtonClick()
        if (destination == ScreenDestination.MAIN_MENU && authenticatedUid != null) {
            isManualLevelSelection = false
            val nextAuthLevel = ((authenticatedRewardedLevels.maxOrNull() ?: 0) + 1).coerceAtLeast(1)
            _uiState.update {
                it.copy(
                    screen = destination,
                    currentLevelNumber = maxOf(it.currentLevelNumber, nextAuthLevel),
                    highestUnlockedLevel = maxOf(it.highestUnlockedLevel, nextAuthLevel),
                    isPaused = true,
                    statusBannerMessage = null
                )
            }
            return
        }
        if (destination == ScreenDestination.PLAYING && _uiState.value.levelConfig == null) {
            startLevel(_uiState.value.currentLevelNumber)
            return
        }
        _uiState.update {
            it.copy(
                screen = destination,
                isPaused = if (destination != ScreenDestination.PLAYING) true else it.isPaused,
                statusBannerMessage = null
            )
        }
    }

    fun startLevel(levelNumber: Int, forcedMode: GameMode? = null) {
        val safeLevel = levelNumber.coerceAtLeast(1)
        val seed = _uiState.value.gameSeed
        val config = levelManager.getLevel(safeLevel, seed, forcedMode)

        boardManager.loadBoard(
            width = config.gridWidth,
            height = config.gridHeight,
            layerCount = config.layers,
            blocks = config.initialBlocks
        )
        livesManager.startLevel(config.maxHearts)
        hintManager.clearActiveHint()
        cameraController.resetForMode(isMultiLayer3D = config.layers > 1 || config.gameMode == GameMode.ROTATING_3D_BOARD)

        _uiState.update {
            it.copy(
                screen = ScreenDestination.PLAYING,
                currentLevelNumber = safeLevel,
                levelConfig = config,
                activeBlocks = boardManager.getRemainingBlocks(),
                initialBlockCount = config.initialBlocks.size,
                remainingBlockCount = boardManager.getRemainingCount(),
                hearts = livesManager.currentHearts,
                maxHearts = livesManager.maxHeartsForLevel,
                currentScore = 0,
                comboCount = 0,
                canUndo = false,
                isPaused = false,
                isLevelComplete = false,
                isGameOver = false,
                starsEarned = 3,
                coinsEarnedThisLevel = 0,
                doubleCoinsClaimed = false,
                activeHintBlockId = null,
                activeHintRay = emptyList(),
                flyingArrows = emptyList(),
                blockedArrowState = null,
                particles3D = emptyList(),
                confettiParticles = emptyList(),
                cameraYaw = cameraController.yawDegrees,
                cameraPitch = cameraController.pitchDegrees,
                cameraZoom = cameraController.zoom,
                isIsometric3D = cameraController.isIsometric3DView,
                remainingSeconds = config.timeLimitSeconds,
                remainingMoves = config.moveLimit,
                statusBannerMessage = null
            )
        }

        startLevelTimerIfNeeded(config.timeLimitSeconds)
        ensureAnimationLoopRunning()
    }

    fun restartCurrentLevel() {
        audioManager.playButtonClick()
        val currentConfig = _uiState.value.levelConfig
        if (currentConfig != null) {
            startLevel(currentConfig.levelNumber, currentConfig.gameMode)
        } else {
            startLevel(_uiState.value.currentLevelNumber)
        }
    }

    fun startNextLevel() {
        audioManager.playButtonClick()
        val nextLevel = (_uiState.value.currentLevelNumber + 1).coerceAtLeast(1)
        if (nextLevel >= _uiState.value.highestUnlockedLevel) {
            isManualLevelSelection = false
        }
        startLevel(nextLevel)
    }

    /**
     * Handles tapping a specific 3D arrow block by ID.
     */
    fun onBlockTapped(blockId: Int) {
        val state = _uiState.value
        if (state.isPaused || state.isLevelComplete || state.isGameOver) return

        val block = boardManager.getBlock(blockId) ?: return
        val pathResult = boardManager.checkBlockPath(blockId)

        when (pathResult) {
            is PathCheckResult.Clear -> {
                handleValidArrowMove(block)
            }
            is PathCheckResult.BlockedByPath -> {
                handleBlockedArrowMove(
                    block = block,
                    blockingBlockId = pathResult.blockingBlockId,
                    collisionCell = pathResult.collisionCell,
                    reasonMessage = "Path is blocked! Clear the blocking arrow first."
                )
            }
            is PathCheckResult.BlockedByUpperLayer -> {
                handleBlockedArrowMove(
                    block = block,
                    blockingBlockId = pathResult.blockingBlockId,
                    collisionCell = pathResult.collisionCell,
                    reasonMessage = "Locked by an upper 3D layer block! Rotate view & clear top blocks first."
                )
            }
        }
    }

    private fun handleValidArrowMove(block: ArrowBlock) {
        val state = _uiState.value
        val difficulty = state.levelConfig?.difficulty ?: DifficultyTier.EASY
        val newCombo = state.comboCount + 1
        val moveScore = (block.cells.size * 15 + newCombo * 5) * (difficulty.scoreMultiplier / 10)

        boardManager.removeBlock(block.id, moveScore)
        audioManager.playArrowSlideOut(newCombo)

        if (hintManager.activeHintBlockId == block.id) {
            hintManager.clearActiveHint()
        }

        val now = System.currentTimeMillis()
        val flying = FlyingArrowState(
            block = block,
            progress = 0f,
            startTimeMs = now
        )

        val spawnedParticles = spawnParticlesForBlock(block, isError = false)
        val remaining = boardManager.getRemainingBlocks()
        val updatedMoves = state.remainingMoves?.let { (it - 1).coerceAtLeast(0) }

        val boardCleared = remaining.isEmpty()
        val outOfMoves = !boardCleared && updatedMoves != null && updatedMoves <= 0

        _uiState.update { current ->
            current.copy(
                activeBlocks = remaining,
                remainingBlockCount = remaining.size,
                currentScore = current.currentScore + moveScore,
                comboCount = newCombo,
                canUndo = boardManager.canUndo(),
                activeHintBlockId = hintManager.activeHintBlockId,
                activeHintRay = hintManager.activeHintRay,
                flyingArrows = (current.flyingArrows + flying).takeLast(12),
                blockedArrowState = null,
                particles3D = (current.particles3D + spawnedParticles).takeLast(80),
                remainingMoves = updatedMoves,
                statusBannerMessage = null
            )
        }

        ensureAnimationLoopRunning()

        if (boardCleared) {
            onLevelCleared()
        } else if (outOfMoves) {
            triggerGameOver("Out of Moves!")
        }
    }

    private fun handleBlockedArrowMove(
        block: ArrowBlock,
        blockingBlockId: Int,
        collisionCell: GridPos3D,
        reasonMessage: String
    ) {
        audioManager.playBlockedAction()
        val outOfHearts = livesManager.consumeHeart()
        val now = System.currentTimeMillis()

        val blockedAnim = BlockedArrowState(
            blockId = block.id,
            blockingBlockId = blockingBlockId,
            collisionCell = collisionCell,
            progress = 0f,
            startTimeMs = now
        )

        val errorParticles = spawnParticlesAtCell(collisionCell, colorIndex = block.colorIndex, isError = true)

        _uiState.update { current ->
            current.copy(
                hearts = livesManager.currentHearts,
                comboCount = 0,
                blockedArrowState = blockedAnim,
                particles3D = (current.particles3D + errorParticles).takeLast(80),
                statusBannerMessage = reasonMessage
            )
        }

        ensureAnimationLoopRunning()

        if (outOfHearts) {
            triggerGameOver("Out of Hearts!")
        }
    }

    private fun onLevelCleared() {
        timerJob?.cancel()
        audioManager.playLevelComplete()

        val state = _uiState.value
        val config = state.levelConfig ?: return
        val heartsRatio = state.hearts.toFloat() / state.maxHearts.coerceAtLeast(1)
        val stars = when {
            state.hearts >= state.maxHearts -> 3
            heartsRatio >= 0.5f -> 2
            else -> 1
        }

        val alreadyRewarded = if (authenticatedUid != null) {
            authenticatedRewardedLevels.contains(config.levelNumber)
        } else {
            state.completedLevels[config.levelNumber]?.completed == true
        }

        val totalCoinsEarned = if (alreadyRewarded) {
            onAuthenticatedLevelCompleted?.invoke(config.levelNumber)
            0
        } else {
            authenticatedRewardedLevels.add(config.levelNumber)
            val earned = onAuthenticatedLevelCompleted?.invoke(config.levelNumber) ?: LEVEL_COMPLETION_COIN_REWARD
            if (authenticatedUid != null && earned > 0) {
                authenticatedCoins = (authenticatedCoins ?: state.coins) + earned
            }
            earned
        }
        val finalScore = state.currentScore + stars * 150 + state.hearts * 50

        val confetti = List(48) { idx ->
            val palette = listOf(0xFF00E5FF, 0xFFFFB800, 0xFF10B981, 0xFFFF3B5C, 0xFF2979FF, 0xFFA855F7)
            ConfettiParticle(
                x = Random.nextFloat(),
                y = Random.nextFloat() * -0.4f,
                vx = (Random.nextFloat() - 0.5f) * 0.012f,
                vy = 0.008f + Random.nextFloat() * 0.014f,
                rotation = Random.nextFloat() * 360f,
                vRot = (Random.nextFloat() - 0.5f) * 14f,
                colorHex = palette[idx % palette.size],
                sizeDp = 6f + Random.nextFloat() * 6f
            )
        }

        val updatedCompletedEntry = LevelProgressEntity(
            levelNumber = config.levelNumber,
            completed = true,
            stars = maxOf(state.completedLevels[config.levelNumber]?.stars ?: 0, stars),
            bestScore = maxOf(state.completedLevels[config.levelNumber]?.bestScore ?: 0, finalScore)
        )

        _uiState.update {
            val updatedMap = it.completedLevels.toMutableMap().apply {
                put(config.levelNumber, updatedCompletedEntry)
            }
            it.copy(
                isLevelComplete = true,
                starsEarned = stars,
                currentScore = finalScore,
                coins = it.coins + totalCoinsEarned,
                coinsEarnedThisLevel = totalCoinsEarned,
                completedLevels = updatedMap,
                highestUnlockedLevel = maxOf(it.highestUnlockedLevel, config.levelNumber + 1),
                confettiParticles = confetti,
                statusBannerMessage = null,
                lastCoinRewardFeedback = if (totalCoinsEarned > 0) "+$totalCoinsEarned Coins" else null
            )
        }

        viewModelScope.launch {
            progressManager.recordLevelCompleted(
                levelNumber = config.levelNumber,
                starsEarned = stars,
                scoreEarned = finalScore,
                coinsEarned = totalCoinsEarned
            )
        }

        ensureAnimationLoopRunning()
    }

    private fun triggerGameOver(reason: String) {
        timerJob?.cancel()
        audioManager.playGameOver()
        _uiState.update {
            it.copy(
                isGameOver = true,
                gameOverReason = reason
            )
        }
    }

    /**
     * Activates a Hint to highlight a currently movable 3D arrow block and its exit trajectory.
     */
    fun useHint() {
        val state = _uiState.value
        if (state.isPaused || state.isLevelComplete || state.isGameOver) return

        // If a hint is already active on screen, just pulse it again without charging twice
        if (state.activeHintBlockId != null && boardManager.getBlock(state.activeHintBlockId) != null) {
            audioManager.playHintSparkle()
            return
        }

        if (state.hints <= 0) {
            // Allow buying a hint with 30 coins if player has enough coins
            if (state.coins >= 30) {
                _uiState.update { it.copy(coins = (it.coins - 30).coerceAtLeast(0)) }
                triggerHintOnBoard()
                viewModelScope.launch {
                    saveManager.updatePlayerState { p ->
                        p.copy(coins = (p.coins - 30).coerceAtLeast(0))
                    }
                }
            } else {
                _uiState.update {
                    it.copy(statusBannerMessage = "No hints remaining! Complete levels to earn more Coins.")
                }
            }
            return
        }

        _uiState.update { it.copy(hints = (it.hints - 1).coerceAtLeast(0)) }
        triggerHintOnBoard()
        viewModelScope.launch {
            saveManager.updatePlayerState { p ->
                p.copy(hints = (p.hints - 1).coerceAtLeast(0))
            }
        }
    }

    private fun triggerHintOnBoard() {
        val hinted = hintManager.triggerHint(boardManager)
        if (hinted != null) {
            audioManager.playHintSparkle()
            _uiState.update {
                it.copy(
                    activeHintBlockId = hintManager.activeHintBlockId,
                    activeHintRay = hintManager.activeHintRay,
                    statusBannerMessage = "Hint: Tap the glowing ${hinted.direction.label} arrow!"
                )
            }
        }
    }

    /**
     * Undoes the most recent valid arrow removal.
     */
    fun undoLastMove() {
        val state = _uiState.value
        if (state.isPaused || state.isLevelComplete || state.isGameOver) return
        val record = boardManager.undoLastMove() ?: return
        audioManager.playButtonClick()
        hintManager.clearActiveHint()

        _uiState.update { current ->
            current.copy(
                activeBlocks = boardManager.getRemainingBlocks(),
                remainingBlockCount = boardManager.getRemainingCount(),
                currentScore = (current.currentScore - record.scoreDelta).coerceAtLeast(0),
                comboCount = 0,
                canUndo = boardManager.canUndo(),
                activeHintBlockId = null,
                activeHintRay = emptyList(),
                statusBannerMessage = "Move undone"
            )
        }
    }

    fun togglePause() {
        audioManager.playButtonClick()
        _uiState.update { it.copy(isPaused = !it.isPaused) }
    }

    fun toggleGridPegs() {
        audioManager.playButtonClick()
        _uiState.update { it.copy(showGridPegs = !it.showGridPegs) }
    }

    fun rotateCamera(deltaYaw: Float, deltaPitch: Float) {
        cameraController.rotate(deltaYaw, deltaPitch)
        _uiState.update {
            it.copy(
                cameraYaw = cameraController.yawDegrees,
                cameraPitch = cameraController.pitchDegrees
            )
        }
    }

    fun zoomCamera(zoomFactor: Float) {
        cameraController.zoomBy(zoomFactor)
        _uiState.update {
            it.copy(cameraZoom = cameraController.zoom)
        }
    }

    fun resetCamera() {
        audioManager.playButtonClick()
        val config = _uiState.value.levelConfig
        cameraController.resetForMode(
            isMultiLayer3D = (config?.layers ?: 1) > 1 || config?.gameMode == GameMode.ROTATING_3D_BOARD
        )
        _uiState.update {
            it.copy(
                cameraYaw = cameraController.yawDegrees,
                cameraPitch = cameraController.pitchDegrees,
                cameraZoom = cameraController.zoom,
                isIsometric3D = cameraController.isIsometric3DView
            )
        }
    }

    fun toggleCamera3DPreset() {
        audioManager.playButtonClick()
        cameraController.toggleCameraPreset()
        _uiState.update {
            it.copy(
                cameraYaw = cameraController.yawDegrees,
                cameraPitch = cameraController.pitchDegrees,
                isIsometric3D = cameraController.isIsometric3DView
            )
        }
    }

    /**
     * Continues from Game Over by spending 50 coins to restore hearts (or using the rewarded ad hook).
     */
    fun continueWithCoins() {
        val state = _uiState.value
        if (state.coins < 50) {
            _uiState.update { it.copy(statusBannerMessage = "Need 50 Coins to continue!") }
            return
        }
        audioManager.playHintSparkle()
        viewModelScope.launch {
            saveManager.updatePlayerState { p ->
                p.copy(coins = (p.coins - 50).coerceAtLeast(0))
            }
            livesManager.refillAll()
            val extraTime = if (_uiState.value.remainingSeconds != null) 30 else null
            val extraMoves = if (_uiState.value.remainingMoves != null) 5 else null
            _uiState.update {
                it.copy(
                    hearts = livesManager.currentHearts,
                    isGameOver = false,
                    remainingSeconds = extraTime ?: it.remainingSeconds,
                    remainingMoves = extraMoves ?: it.remainingMoves,
                    statusBannerMessage = "Hearts restored! Keep going!"
                )
            }
            if (extraTime != null) {
                startLevelTimerIfNeeded(extraTime)
            }
        }
    }

    fun requestRewardedAdForExtraLife() {
        rewardedAdHooks.showRewardedAdForExtraLife(
            onRewardEarned = {
                livesManager.restoreHearts(1)
                _uiState.update {
                    it.copy(
                        hearts = livesManager.currentHearts,
                        isGameOver = false,
                        statusBannerMessage = "+1 Heart restored!"
                    )
                }
            },
            onAdUnavailable = { msg ->
                _uiState.update { it.copy(statusBannerMessage = msg) }
            }
        )
    }

    fun requestRewardedAdForExtraHint() {
        rewardedAdHooks.showRewardedAdForExtraHint(
            onRewardEarned = {
                viewModelScope.launch {
                    saveManager.updatePlayerState { p -> p.copy(hints = p.hints + 1) }
                }
            },
            onAdUnavailable = { msg ->
                _uiState.update { it.copy(statusBannerMessage = msg) }
            }
        )
    }

    fun requestRewardedAdForDoubleCoins() {
        if (_uiState.value.doubleCoinsClaimed) return
        rewardedAdHooks.showRewardedAdForDoubleCoins(
            onRewardEarned = {
                val bonus = _uiState.value.coinsEarnedThisLevel
                viewModelScope.launch {
                    saveManager.updatePlayerState { p -> p.copy(coins = p.coins + bonus) }
                    _uiState.update {
                        it.copy(
                            coinsEarnedThisLevel = it.coinsEarnedThisLevel * 2,
                            doubleCoinsClaimed = true
                        )
                    }
                }
            },
            onAdUnavailable = { msg ->
                _uiState.update { it.copy(statusBannerMessage = msg) }
            }
        )
    }

    fun awardDirectCoins(amount: Int, feedback: String = "+$amount Coins") {
        viewModelScope.launch {
            saveManager.updatePlayerState { p -> p.copy(coins = p.coins + amount) }
            _uiState.update {
                it.copy(
                    coins = it.coins + amount,
                    lastCoinRewardFeedback = feedback
                )
            }
        }
    }

    fun markRewardedAdClaimedThisLevel() {
        _uiState.update { it.copy(doubleCoinsClaimed = true) }
    }

    fun restoreHeartFromAd() {
        livesManager.restoreHearts(1)
        _uiState.update {
            it.copy(
                hearts = livesManager.currentHearts,
                isGameOver = false,
                statusBannerMessage = "+1 Heart restored!"
            )
        }
    }

    fun showBannerMessage(msg: String) {
        _uiState.update { it.copy(statusBannerMessage = msg) }
    }

    fun setSoundEnabled(enabled: Boolean) {
        viewModelScope.launch {
            saveManager.updatePlayerState { it.copy(soundEnabled = enabled) }
        }
    }

    fun setMusicEnabled(enabled: Boolean) {
        viewModelScope.launch {
            saveManager.updatePlayerState { it.copy(musicEnabled = enabled) }
            audioManager.updateBackgroundMusic(enabled)
        }
    }

    fun setVibrationEnabled(enabled: Boolean) {
        viewModelScope.launch {
            saveManager.updatePlayerState { it.copy(vibrationEnabled = enabled) }
        }
    }

    fun setGraphicsQuality(quality: GraphicsQuality) {
        viewModelScope.launch {
            saveManager.updatePlayerState { it.copy(graphicsQualityOrdinal = quality.ordinal) }
        }
    }

    fun setLevelSelectPage(page: Int) {
        audioManager.playButtonClick()
        _uiState.update { it.copy(levelSelectPage = page.coerceAtLeast(0)) }
    }

    fun resetAllProgress() {
        audioManager.playButtonClick()
        viewModelScope.launch {
            if (authenticatedUid != null) {
                isManualLevelSelection = false
                val nextAuthLevel = ((authenticatedRewardedLevels.maxOrNull() ?: 0) + 1).coerceAtLeast(1)
                startLevel(nextAuthLevel)
                return@launch
            }
            saveManager.resetAllProgress()
            levelManager.clearCache()
            startLevel(1)
            _uiState.update { it.copy(screen = ScreenDestination.MAIN_MENU) }
        }
    }

    private fun startLevelTimerIfNeeded(seconds: Int?) {
        timerJob?.cancel()
        if (seconds == null) return
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                val s = _uiState.value
                if (s.screen == ScreenDestination.PLAYING && !s.isPaused && !s.isLevelComplete && !s.isGameOver) {
                    val rem = (s.remainingSeconds ?: 0) - 1
                    if (rem <= 0) {
                        _uiState.update { it.copy(remainingSeconds = 0) }
                        triggerGameOver("Time's Up!")
                        break
                    } else {
                        _uiState.update { it.copy(remainingSeconds = rem) }
                    }
                }
            }
        }
    }

    private fun ensureAnimationLoopRunning() {
        if (animationLoopJob?.isActive == true) return
        animationLoopJob = viewModelScope.launch {
            val frameMs = 16L
            var confettiFrames = 0
            while (isActive) {
                val now = System.currentTimeMillis()
                val s = _uiState.value

                val updatedFlying = s.flyingArrows.mapNotNull { fa ->
                    val elapsed = (now - fa.startTimeMs).coerceAtLeast(0L)
                    val prog = (elapsed / 340f).coerceIn(0f, 1f)
                    if (prog >= 1f) null else fa.copy(progress = prog)
                }

                val updatedBlocked = s.blockedArrowState?.let { ba ->
                    val elapsed = (now - ba.startTimeMs).coerceAtLeast(0L)
                    val prog = (elapsed / 380f).coerceIn(0f, 1f)
                    if (prog >= 1f) null else ba.copy(progress = prog)
                }

                val updatedParticles = if (s.graphicsQuality == GraphicsQuality.PERFORMANCE) {
                    emptyList()
                } else {
                    s.particles3D.mapNotNull { p ->
                        val nextLife = p.life - 0.05f
                        if (nextLife <= 0f) null
                        else p.copy(
                            x = p.x + p.vx,
                            y = p.y + p.vy,
                            z = p.z + p.vz,
                            life = nextLife
                        )
                    }
                }

                val shouldRunConfetti = s.isLevelComplete && confettiFrames < 160
                if (s.isLevelComplete) confettiFrames++

                val updatedConfetti = if (shouldRunConfetti) {
                    s.confettiParticles.map { c ->
                        val ny = c.y + c.vy
                        val nx = c.x + c.vx
                        c.copy(
                            x = if (nx < 0f) nx + 1f else if (nx > 1f) nx - 1f else nx,
                            y = if (ny > 1.15f) -0.1f else ny,
                            rotation = (c.rotation + c.vRot) % 360f
                        )
                    }
                } else {
                    emptyList()
                }

                _uiState.update {
                    it.copy(
                        flyingArrows = updatedFlying,
                        blockedArrowState = updatedBlocked,
                        particles3D = updatedParticles,
                        confettiParticles = updatedConfetti
                    )
                }

                if (updatedFlying.isEmpty() &&
                    updatedBlocked == null &&
                    updatedParticles.isEmpty() &&
                    !shouldRunConfetti
                ) {
                    if (!_uiState.value.isLevelComplete && !_uiState.value.isGameOver && !_uiState.value.isPaused) {
                        onSafeGameplayMomentForInterstitial?.invoke()
                    }
                    break
                }
                delay(frameMs)
            }
        }
    }

    private fun spawnParticlesForBlock(block: ArrowBlock, isError: Boolean): List<Particle3D> {
        if (_uiState.value.graphicsQuality == GraphicsQuality.PERFORMANCE) return emptyList()
        val list = ArrayList<Particle3D>()
        for (cell in block.cells) {
            repeat(2) {
                list.add(
                    Particle3D(
                        x = cell.x + (Random.nextFloat() - 0.5f) * 0.3f,
                        y = cell.y + (Random.nextFloat() - 0.5f) * 0.3f,
                        z = cell.z * 0.55f + 0.25f,
                        vx = block.direction.dx * 0.14f + (Random.nextFloat() - 0.5f) * 0.08f,
                        vy = block.direction.dy * 0.14f + (Random.nextFloat() - 0.5f) * 0.08f,
                        vz = 0.03f + Random.nextFloat() * 0.05f,
                        colorIndex = block.colorIndex,
                        isError = isError,
                        life = 1f,
                        size = 5f + Random.nextFloat() * 5f
                    )
                )
            }
        }
        return list
    }

    private fun spawnParticlesAtCell(
        cell: GridPos3D,
        colorIndex: Int,
        isError: Boolean
    ): List<Particle3D> {
        if (_uiState.value.graphicsQuality == GraphicsQuality.PERFORMANCE) return emptyList()
        return List(8) {
            Particle3D(
                x = cell.x.toFloat(),
                y = cell.y.toFloat(),
                z = cell.z * 0.55f + 0.35f,
                vx = (Random.nextFloat() - 0.5f) * 0.16f,
                vy = (Random.nextFloat() - 0.5f) * 0.16f,
                vz = 0.04f + Random.nextFloat() * 0.06f,
                colorIndex = colorIndex,
                isError = isError,
                life = 1f,
                size = 6f + Random.nextFloat() * 4f
            )
        }
    }

    companion object {
        fun provideFactory(context: Context): ViewModelProvider.Factory {
            return object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = AppDatabase.getInstance(context)
                    val dao = db.gameDao()
                    val saveManager = SaveManager(dao)
                    val progressManager = ProgressManager(dao, saveManager)
                    val audioManager = AudioManager(context.applicationContext)
                    return GameManager(
                        saveManager = saveManager,
                        progressManager = progressManager,
                        audioManager = audioManager
                    ) as T
                }
            }
        }
    }
}
