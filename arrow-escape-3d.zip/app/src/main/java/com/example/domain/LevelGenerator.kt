package com.example.domain

import com.example.model.ArrowBlock
import com.example.model.DifficultyTier
import com.example.model.Direction3D
import com.example.model.GameMode
import com.example.model.GridPos3D
import com.example.model.LevelConfig
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Procedural Solvable Level Generator capable of generating an unlimited number
 * of unique, guaranteed-solvable 3D arrow puzzle levels using a deterministic seed.
 *
 * Guarantees that no two arrows ever touch, overlap, cross/intersect, or visually clip
 * into each other (including their protruding 3D arrowheads).
 */
class LevelGenerator {

    private enum class BoardShape(val displayName: String) {
        CLASSIC_GRID("Classic Grid"),
        HEART("Heart Formation"),
        DIAMOND("Diamond Core"),
        CROSS_CITADEL("3D Cross Citadel"),
        LEAF("Leaf Cluster"),
        SHIELD("Royal Shield"),
        RING_FORTRESS("Ring Fortress"),
        SPIRAL_ARENA("Spiral Arena")
    }

    private data class Segment2D(
        val x1: Float,
        val y1: Float,
        val x2: Float,
        val y2: Float
    )

    /**
     * Generates a guaranteed-solvable [LevelConfig] for any [levelNumber] >= 1.
     * Uses deterministic seed = levelNumber * 1_000_003L + gameSeed.
     * Optionally allows overriding the [forcedMode] when the player picks a specific mode from the menu.
     */
    fun generateLevel(
        levelNumber: Int,
        gameSeed: Long = 2026L,
        forcedMode: GameMode? = null
    ): LevelConfig {
        val safeLevel = levelNumber.coerceAtLeast(1)
        val difficulty = DifficultyTier.forLevel(safeLevel)
        val gameMode = forcedMode ?: selectModeForLevel(safeLevel)

        for (attempt in 0 until 24) {
            val seed = safeLevel.toLong() * 1_000_003L + gameSeed * 31L + attempt * 997L
            val rng = Random(seed)
            val generated = tryConstructLevel(safeLevel, seed, difficulty, gameMode, rng)
            if (generated != null && validateLevelArrowsNoTouchOrCross(generated.initialBlocks)) {
                return generated
            }
        }

        // Guaranteed fallback solvable level if all attempts hit a rare constraint
        return buildFallbackSolvableLevel(safeLevel, gameSeed, difficulty, gameMode)
    }

    private fun selectModeForLevel(levelNumber: Int): GameMode {
        return when {
            levelNumber <= 3 -> GameMode.TAP_AWAY_ARROWS
            levelNumber % 10 == 0 -> GameMode.SPECIAL_CHALLENGE
            levelNumber % 7 == 0 -> GameMode.ROTATING_3D_BOARD
            levelNumber % 5 == 0 -> GameMode.CLEAR_THE_BOARD
            levelNumber % 3 == 0 -> GameMode.FIND_FREE_PATH
            else -> GameMode.TAP_AWAY_ARROWS
        }
    }

    private fun tryConstructLevel(
        levelNumber: Int,
        seed: Long,
        difficulty: DifficultyTier,
        gameMode: GameMode,
        rng: Random
    ): LevelConfig? {
        // Determine dimensions, target block count, and max block length.
        // All blocks are placed on a single board plane (layers = 1) so upper-layer blocks
        // never visually cross over or overlap lower-layer blocks in 3D perspective.
        val (gridW, gridH) = when {
            levelNumber <= 2 -> 6 to 6
            levelNumber <= 6 -> 7 to 7
            levelNumber <= 15 -> 8 to 8
            levelNumber <= 35 -> 9 to 9
            levelNumber <= 70 -> 10 to 10
            levelNumber <= 140 -> 11 to 11
            else -> 12 to 12
        }.let { (baseW, baseH) ->
            when (gameMode) {
                GameMode.FIND_FREE_PATH -> (baseW + 1).coerceAtMost(12) to (baseH + 1).coerceAtMost(12)
                GameMode.ROTATING_3D_BOARD -> baseW.coerceIn(7, 10) to baseH.coerceIn(7, 10)
                else -> baseW to baseH
            }
        }

        val layers = 1
        val shape = selectShape(levelNumber, gameMode, rng)

        val targetBlocksPerLayer = when {
            levelNumber == 1 -> 6
            levelNumber == 2 -> 8
            levelNumber <= 5 -> 10
            levelNumber <= 12 -> 13
            levelNumber <= 20 -> 16
            levelNumber <= 50 -> 20 + (levelNumber - 20) / 4
            levelNumber <= 100 -> 28 + (levelNumber - 50) / 4
            levelNumber <= 200 -> 38 + (levelNumber - 100) / 6
            else -> 52
        }

        val maxBodyLength = when {
            levelNumber <= 3 -> 3
            levelNumber <= 15 -> 4
            gameMode == GameMode.FIND_FREE_PATH -> 5
            difficulty == DifficultyTier.EASY -> 4
            difficulty == DifficultyTier.NORMAL -> 5
            else -> 5
        }

        val minBodyLength = when {
            levelNumber <= 2 -> 2
            gameMode == GameMode.FIND_FREE_PATH -> 3
            else -> 2
        }

        val occupied = HashSet<GridPos3D>()
        // Cells immediately 1 step in front of each placed arrow's head (head.step(direction)).
        // Keeping these cells free guarantees the protruding 3D arrowhead tip never touches or clips
        // into another arrow, and no two arrowheads ever point into the same cell.
        val reservedFrontCells = HashSet<GridPos3D>()
        val placedHeads = HashSet<GridPos3D>()

        // Track cells that lie on the exit rays (2+ steps ahead of head) of already-placed blocks
        // so newer blocks can intentionally cross them to create interlocking puzzle dependencies.
        val exitRayCells = HashSet<GridPos3D>()
        val constructedReverse = ArrayList<ArrowBlock>()
        var nextBlockId = 1

        val z = 0
        val allowedCells = buildShapeMask(shape, gridW, gridH, z, layers)
        val layerQuota = targetBlocksPerLayer

        var placedInLayer = 0
        var consecutiveMisses = 0

        while (placedInLayer < layerQuota && consecutiveMisses < 50) {
            // Gather candidate empty head cells that respect arrowhead spacing
            val availableHeads = allowedCells.filter { cell ->
                cell !in occupied &&
                    cell !in reservedFrontCells &&
                    placedHeads.none { existingHead -> existingHead.manhattanDistance(cell) <= 1 }
            }.shuffled(rng)

            if (availableHeads.isEmpty()) break

            var bestBlock: ArrowBlock? = null
            var bestScore = Int.MIN_VALUE

            val sampleHeads = availableHeads.take(40)
            for (headCell in sampleHeads) {
                val directions = Direction3D.entries.shuffled(rng)
                for (dir in directions) {
                    val frontCell = headCell.step(dir)
                    // Ensure the cell immediately in front of the arrowhead is completely clear
                    if (frontCell in occupied || frontCell in reservedFrontCells) continue

                    // Check if exit ray from headCell in dir is completely free of occupied cells
                    if (!isExitRayFree(headCell, dir, gridW, gridH, occupied)) continue

                    // Grow a connected tail body backwards/orthogonally from headCell
                    val desiredLen = rng.nextInt(minBodyLength, maxBodyLength + 1)
                    val bodyCells = growArrowBody(
                        headCell = headCell,
                        exitDir = dir,
                        desiredLength = desiredLen,
                        allowedCells = allowedCells,
                        occupied = occupied,
                        reservedFrontCells = reservedFrontCells,
                        exitRayCells = exitRayCells,
                        rng = rng
                    )

                    if (bodyCells.size < minBodyLength.coerceAtLeast(2)) continue

                    val colorIdx = (nextBlockId + dir.ordinal) % 6
                    val candidateBlock = ArrowBlock(
                        id = nextBlockId,
                        cells = bodyCells,
                        direction = dir,
                        colorIndex = colorIdx
                    )

                    if (!canPlaceBlockWithProperSpacing(candidateBlock, constructedReverse)) {
                        continue
                    }

                    // Score this candidate:
                    // +15 for each cell of bodyCells that crosses an earlier block's exit ray (creates blocking!)
                    // +6 for each bend/turn in the arrow path (makes visually interesting shapes)
                    // +3 for length
                    var score = bodyCells.size * 3
                    for (c in bodyCells) {
                        if (c in exitRayCells) score += 15
                    }
                    score += countBends(bodyCells) * 6

                    if (score > bestScore) {
                        bestScore = score
                        bestBlock = candidateBlock
                    }
                }
            }

            if (bestBlock != null) {
                constructedReverse.add(bestBlock)
                nextBlockId++
                placedInLayer++
                consecutiveMisses = 0

                for (cell in bestBlock.cells) {
                    occupied.add(cell)
                }
                placedHeads.add(bestBlock.head)

                val immediateFront = bestBlock.head.step(bestBlock.direction)
                reservedFrontCells.add(immediateFront)

                // Record this block's exit ray starting 2 steps ahead of the head so subsequent
                // blocks block its path while leaving a clear gap in front of the 3D arrowhead.
                var rayCursor = immediateFront.step(bestBlock.direction)
                while (rayCursor.x in 0 until gridW && rayCursor.y in 0 until gridH) {
                    exitRayCells.add(rayCursor)
                    rayCursor = rayCursor.step(bestBlock.direction)
                }
            } else {
                consecutiveMisses++
            }
        }

        if (constructedReverse.size < 4) return null

        val finalBlocks = constructedReverse.toList()
        if (!validateLevelArrowsNoTouchOrCross(finalBlocks)) {
            return null
        }

        val verifiedSolution = BoardManager.findSolutionOrder(gridW, gridH, layers, finalBlocks)
            ?: return null

        // Configure Special Challenge rules if applicable
        val timeLimitSeconds = if (gameMode == GameMode.SPECIAL_CHALLENGE) {
            (finalBlocks.size * 4 + 25).coerceIn(35, 180)
        } else {
            null
        }

        val moveLimit = if (gameMode == GameMode.SPECIAL_CHALLENGE && levelNumber % 2 == 0) {
            finalBlocks.size + 2
        } else {
            null
        }

        val maxHearts = if (gameMode == GameMode.SPECIAL_CHALLENGE && levelNumber >= 30) 2 else 3

        return LevelConfig(
            levelNumber = levelNumber,
            seed = seed,
            difficulty = difficulty,
            gameMode = gameMode,
            shapeName = shape.displayName,
            gridWidth = gridW,
            gridHeight = gridH,
            layers = layers,
            initialBlocks = finalBlocks,
            solutionOrder = verifiedSolution,
            timeLimitSeconds = timeLimitSeconds,
            moveLimit = moveLimit,
            maxHearts = maxHearts
        )
    }

    /**
     * Validates that a candidate [block] has proper clearance from all [existingBlocks]
     * and does not touch, overlap, clip, or cross any existing arrow.
     */
    private fun canPlaceBlockWithProperSpacing(
        block: ArrowBlock,
        existingBlocks: List<ArrowBlock>
    ): Boolean {
        if (!isSingleBlockGeometryValid(block)) return false

        val blockFront = block.head.step(block.direction)
        val blockSegments = buildBlockSegmentsWithArrowhead(block)

        for (other in existingBlocks) {
            // 1. Disjoint grid cells on (x, y)
            for (c1 in block.cells) {
                for (c2 in other.cells) {
                    if (c1.x == c2.x && c1.y == c2.y) return false
                }
            }

            // 2. Arrowhead front clearance cell must not overlap any cell of the other arrow
            val otherFront = other.head.step(other.direction)
            if (other.cells.any { it.x == blockFront.x && it.y == blockFront.y }) return false
            if (block.cells.any { it.x == otherFront.x && it.y == otherFront.y }) return false

            // 3. Two arrowheads must never point into the same empty cell or sit in adjacent cells
            if (blockFront.x == otherFront.x && blockFront.y == otherFront.y) return false
            if (abs(block.head.x - other.head.x) + abs(block.head.y - other.head.y) <= 1) return false

            // 4. Continuous 2D segment-to-segment distance check (including protruding arrowheads)
            val otherSegments = buildBlockSegmentsWithArrowhead(other)
            for (segA in blockSegments) {
                for (segB in otherSegments) {
                    if (segmentsIntersectOrCross(segA, segB)) return false
                    val dist = segmentToSegmentDistance(segA, segB)
                    if (dist < 0.85f) return false
                }
            }
        }
        return true
    }

    /**
     * Validates an entire level's arrow list before accepting a generated level.
     * Rejects any layout where any two arrows touch, overlap, clip into each other, or cross.
     */
    fun validateLevelArrowsNoTouchOrCross(blocks: List<ArrowBlock>): Boolean {
        if (blocks.size < 4) return false

        for (i in blocks.indices) {
            val blockA = blocks[i]
            if (!isSingleBlockGeometryValid(blockA)) return false
        }

        for (i in blocks.indices) {
            for (j in i + 1 until blocks.size) {
                if (!canPlaceBlockWithProperSpacing(blocks[i], listOf(blocks[j]))) {
                    return false
                }
            }
        }
        return true
    }

    private fun isSingleBlockGeometryValid(block: ArrowBlock): Boolean {
        val cells = block.cells
        if (cells.size < 2) return false

        // All cells must be on the base layer z == 0
        if (cells.any { it.z != 0 }) return false

        // Consecutive cells must be orthogonally adjacent (unit step)
        for (i in 0 until cells.size - 1) {
            val a = cells[i]
            val b = cells[i + 1]
            if (abs(a.x - b.x) + abs(a.y - b.y) != 1) return false
        }

        // Non-consecutive cells must not overlap or touch orthogonally (prevents tight 2x2 self-clipping U-turns)
        for (i in cells.indices) {
            for (j in i + 1 until cells.size) {
                val dist = abs(cells[i].x - cells[j].x) + abs(cells[i].y - cells[j].y)
                if (dist == 0) return false
                if (j - i > 1 && dist <= 1) return false
            }
        }

        // The neck cell (second to last) must be directly opposite the exit direction from head
        // so the 3D arrowhead never points backward or sideways across its own shaft.
        val head = block.head
        val neck = cells[cells.size - 2]
        val expectedNeck = head.step(block.direction.opposite())
        if (neck.x != expectedNeck.x || neck.y != expectedNeck.y) return false

        // Forward ray from head must not intersect any of the block's own cells
        val front = head.step(block.direction)
        if (cells.any { it.x == front.x && it.y == front.y }) return false

        return true
    }

    private fun buildBlockSegmentsWithArrowhead(block: ArrowBlock): List<Segment2D> {
        val segments = ArrayList<Segment2D>(block.cells.size)
        for (i in 0 until block.cells.size - 1) {
            val a = block.cells[i]
            val b = block.cells[i + 1]
            segments.add(
                Segment2D(
                    x1 = a.x.toFloat(),
                    y1 = a.y.toFloat(),
                    x2 = b.x.toFloat(),
                    y2 = b.y.toFloat()
                )
            )
        }
        // Include the protruding 3D arrowhead extension beyond the head cell
        val head = block.head
        val tipExtend = 0.45f
        segments.add(
            Segment2D(
                x1 = head.x.toFloat(),
                y1 = head.y.toFloat(),
                x2 = head.x + block.direction.dx * tipExtend,
                y2 = head.y + block.direction.dy * tipExtend
            )
        )
        return segments
    }

    private fun segmentsIntersectOrCross(a: Segment2D, b: Segment2D): Boolean {
        val minAx = min(a.x1, a.x2)
        val maxAx = max(a.x1, a.x2)
        val minAy = min(a.y1, a.y2)
        val maxAy = max(a.y1, a.y2)

        val minBx = min(b.x1, b.x2)
        val maxBx = max(b.x1, b.x2)
        val minBy = min(b.y1, b.y2)
        val maxBy = max(b.y1, b.y2)

        if (maxAx < minBx || maxBx < minAx || maxAy < minBy || maxBy < minAy) {
            return false
        }

        val d1 = crossProduct(b.x1, b.y1, b.x2, b.y2, a.x1, a.y1)
        val d2 = crossProduct(b.x1, b.y1, b.x2, b.y2, a.x2, a.y2)
        val d3 = crossProduct(a.x1, a.y1, a.x2, a.y2, b.x1, b.y1)
        val d4 = crossProduct(a.x1, a.y1, a.x2, a.y2, b.x2, b.y2)

        if (((d1 > 0f && d2 < 0f) || (d1 < 0f && d2 > 0f)) &&
            ((d3 > 0f && d4 < 0f) || (d3 < 0f && d4 > 0f))
        ) {
            return true
        }

        val eps = 1e-4f
        if (abs(d1) <= eps && onSegment(b.x1, b.y1, b.x2, b.y2, a.x1, a.y1)) return true
        if (abs(d2) <= eps && onSegment(b.x1, b.y1, b.x2, b.y2, a.x2, a.y2)) return true
        if (abs(d3) <= eps && onSegment(a.x1, a.y1, a.x2, a.y2, b.x1, b.y1)) return true
        if (abs(d4) <= eps && onSegment(a.x1, a.y1, a.x2, a.y2, b.x2, b.y2)) return true

        return false
    }

    private fun crossProduct(
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float,
        cx: Float,
        cy: Float
    ): Float {
        return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
    }

    private fun onSegment(
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float,
        px: Float,
        py: Float
    ): Boolean {
        val eps = 1e-4f
        return px >= min(ax, bx) - eps &&
            px <= max(ax, bx) + eps &&
            py >= min(ay, by) - eps &&
            py <= max(ay, by) + eps
    }

    private fun segmentToSegmentDistance(a: Segment2D, b: Segment2D): Float {
        if (segmentsIntersectOrCross(a, b)) return 0f
        val d1 = pointToSegmentDistance(a.x1, a.y1, b.x1, b.y1, b.x2, b.y2)
        val d2 = pointToSegmentDistance(a.x2, a.y2, b.x1, b.y1, b.x2, b.y2)
        val d3 = pointToSegmentDistance(b.x1, b.y1, a.x1, a.y1, a.x2, a.y2)
        val d4 = pointToSegmentDistance(b.x2, b.y2, a.x1, a.y1, a.x2, a.y2)
        return min(min(d1, d2), min(d3, d4))
    }

    private fun pointToSegmentDistance(
        px: Float,
        py: Float,
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float
    ): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        val lenSq = dx * dx + dy * dy
        if (lenSq <= 1e-6f) {
            return hypot(px - x1, py - y1)
        }
        val t = (((px - x1) * dx + (py - y1) * dy) / lenSq).coerceIn(0f, 1f)
        val projX = x1 + t * dx
        val projY = y1 + t * dy
        return hypot(px - projX, py - projY)
    }

    private fun selectShape(levelNumber: Int, gameMode: GameMode, rng: Random): BoardShape {
        if (levelNumber <= 3) return BoardShape.CLASSIC_GRID
        if (gameMode == GameMode.FIND_FREE_PATH) {
            val shaped = listOf(
                BoardShape.HEART,
                BoardShape.DIAMOND,
                BoardShape.LEAF,
                BoardShape.SHIELD,
                BoardShape.RING_FORTRESS
            )
            return shaped[levelNumber % shaped.size]
        }
        if (gameMode == GameMode.ROTATING_3D_BOARD) {
            return if (levelNumber % 2 == 0) BoardShape.CROSS_CITADEL else BoardShape.DIAMOND
        }
        val allShapes = BoardShape.entries
        return allShapes[(levelNumber + rng.nextInt(allShapes.size)) % allShapes.size]
    }

    private fun buildShapeMask(
        shape: BoardShape,
        width: Int,
        height: Int,
        z: Int,
        totalLayers: Int
    ): Set<GridPos3D> {
        val mask = LinkedHashSet<GridPos3D>()
        val cx = (width - 1) / 2.0
        val cy = (height - 1) / 2.0
        val rx = (width / 2.0).coerceAtLeast(1.0)
        val ry = (height / 2.0).coerceAtLeast(1.0)

        for (y in 0 until height) {
            for (x in 0 until width) {
                if (z > 0 && totalLayers > 1) {
                    val margin = z.coerceAtMost(width / 4)
                    if (x < margin || x >= width - margin || y < margin || y >= height - margin) {
                        continue
                    }
                }

                val nx = (x - cx) / rx
                val ny = (y - cy) / ry

                val inside = when (shape) {
                    BoardShape.CLASSIC_GRID, BoardShape.SPIRAL_ARENA -> true
                    BoardShape.HEART -> {
                        val hy = -ny * 1.15 + 0.15
                        val hx = nx * 1.15
                        val term = hx * hx + hy * hy - 1.0
                        (term * term * term - hx * hx * hy * hy * hy) <= 0.18
                    }
                    BoardShape.DIAMOND -> {
                        abs(nx) + abs(ny) <= 1.28
                    }
                    BoardShape.CROSS_CITADEL -> {
                        abs(nx) <= 0.55 || abs(ny) <= 0.55
                    }
                    BoardShape.LEAF -> {
                        val dist1 = sqrt((nx + 0.35) * (nx + 0.35) + (ny + 0.35) * (ny + 0.35))
                        val dist2 = sqrt((nx - 0.35) * (nx - 0.35) + (ny - 0.35) * (ny - 0.35))
                        dist1 <= 1.25 && dist2 <= 1.25
                    }
                    BoardShape.SHIELD -> {
                        ny <= 0.85 && (abs(nx) <= 0.9 - (ny + 0.5).coerceAtLeast(0.0) * 0.35)
                    }
                    BoardShape.RING_FORTRESS -> {
                        val r = sqrt(nx * nx + ny * ny)
                        r <= 1.15 && (width < 8 || r >= 0.25)
                    }
                }

                if (inside) {
                    mask.add(GridPos3D(x, y, z))
                }
            }
        }

        if (mask.size < 20) {
            for (y in 0 until height) {
                for (x in 0 until width) {
                    mask.add(GridPos3D(x, y, z))
                }
            }
        }
        return mask
    }

    private fun isExitRayFree(
        head: GridPos3D,
        dir: Direction3D,
        gridW: Int,
        gridH: Int,
        occupied: Set<GridPos3D>
    ): Boolean {
        var cursor = head.step(dir)
        while (cursor.x in 0 until gridW && cursor.y in 0 until gridH) {
            if (cursor in occupied) return false
            cursor = cursor.step(dir)
        }
        return true
    }

    /**
     * Grows the body of an arrow backwards from [headCell], returning cells ordered from
     * tail (first) to head (last).
     * Never places a body cell onto the forward exit ray of [headCell], into [reservedFrontCells],
     * or orthogonally adjacent to an earlier non-consecutive cell of the same arrow.
     */
    private fun growArrowBody(
        headCell: GridPos3D,
        exitDir: Direction3D,
        desiredLength: Int,
        allowedCells: Set<GridPos3D>,
        occupied: Set<GridPos3D>,
        reservedFrontCells: Set<GridPos3D>,
        exitRayCells: Set<GridPos3D>,
        rng: Random
    ): List<GridPos3D> {
        // Compute cells strictly on headCell's forward exit ray so the body never blocks its own head
        val ownForwardRay = HashSet<GridPos3D>()
        var forward = headCell.step(exitDir)
        while (forward.x in 0..24 && forward.y in 0..24) {
            ownForwardRay.add(forward)
            forward = forward.step(exitDir)
        }

        val reversedCells = ArrayList<GridPos3D>(desiredLength)
        reversedCells.add(headCell)

        // First step backwards from headCell must be opposite to exitDir so the neck
        // aligns cleanly with the arrowhead direction.
        val neckCell = headCell.step(exitDir.opposite())
        if (desiredLength >= 2 &&
            neckCell in allowedCells &&
            neckCell !in occupied &&
            neckCell !in reservedFrontCells &&
            neckCell !in ownForwardRay
        ) {
            reversedCells.add(neckCell)
        } else {
            return emptyList()
        }

        var current = neckCell
        var lastStepDir = exitDir.opposite()

        while (reversedCells.size < desiredLength) {
            val candidates = Direction3D.entries
                .map { dir -> dir to current.step(dir) }
                .filter { (_, nextPos) ->
                    nextPos in allowedCells &&
                        nextPos !in occupied &&
                        nextPos !in reservedFrontCells &&
                        nextPos !in ownForwardRay &&
                        nextPos !in reversedCells &&
                        reversedCells.dropLast(1).none { earlier ->
                            earlier.manhattanDistance(nextPos) <= 1
                        }
                }

            if (candidates.isEmpty()) break

            val chosen = candidates.maxByOrNull { (dir, nextPos) ->
                var weight = rng.nextInt(10)
                if (nextPos in exitRayCells) weight += 12
                if (dir != lastStepDir) weight += 5
                weight
            }!!

            lastStepDir = chosen.first
            current = chosen.second
            reversedCells.add(current)
        }

        // Reverse so index 0 is tail and last index is headCell
        return reversedCells.asReversed()
    }

    private fun countBends(cells: List<GridPos3D>): Int {
        if (cells.size < 3) return 0
        var bends = 0
        for (i in 1 until cells.size - 1) {
            val dx1 = cells[i].x - cells[i - 1].x
            val dy1 = cells[i].y - cells[i - 1].y
            val dx2 = cells[i + 1].x - cells[i].x
            val dy2 = cells[i + 1].y - cells[i].y
            if (dx1 != dx2 || dy1 != dy2) {
                bends++
            }
        }
        return bends
    }

    private fun buildFallbackSolvableLevel(
        levelNumber: Int,
        gameSeed: Long,
        difficulty: DifficultyTier,
        gameMode: GameMode
    ): LevelConfig {
        val blocks = listOf(
            ArrowBlock(
                id = 1,
                cells = listOf(GridPos3D(1, 2, 0), GridPos3D(1, 1, 0)),
                direction = Direction3D.UP,
                colorIndex = 0
            ),
            ArrowBlock(
                id = 2,
                cells = listOf(GridPos3D(1, 5, 0), GridPos3D(1, 4, 0)),
                direction = Direction3D.UP,
                colorIndex = 1
            ),
            ArrowBlock(
                id = 3,
                cells = listOf(GridPos3D(4, 1, 0), GridPos3D(3, 1, 0)),
                direction = Direction3D.LEFT,
                colorIndex = 2
            ),
            ArrowBlock(
                id = 4,
                cells = listOf(GridPos3D(4, 4, 0), GridPos3D(4, 3, 0)),
                direction = Direction3D.UP,
                colorIndex = 3
            ),
            ArrowBlock(
                id = 5,
                cells = listOf(GridPos3D(2, 5, 0), GridPos3D(3, 5, 0), GridPos3D(4, 5, 0)),
                direction = Direction3D.RIGHT,
                colorIndex = 4
            )
        )
        return LevelConfig(
            levelNumber = levelNumber,
            seed = levelNumber + gameSeed,
            difficulty = difficulty,
            gameMode = gameMode,
            shapeName = "Classic Grid",
            gridWidth = 7,
            gridHeight = 7,
            layers = 1,
            initialBlocks = blocks,
            solutionOrder = listOf(1, 2, 3, 4, 5),
            maxHearts = 3
        )
    }
}

/**
 * LevelManager caches and provides unlimited procedural levels and manages level transitions.
 */
class LevelManager(
    private val generator: LevelGenerator = LevelGenerator()
) {
    private val cache = HashMap<String, LevelConfig>()

    fun getLevel(
        levelNumber: Int,
        gameSeed: Long,
        forcedMode: GameMode? = null
    ): LevelConfig {
        val key = "${levelNumber}_${gameSeed}_${forcedMode?.name ?: "AUTO"}"
        return cache.getOrPut(key) {
            generator.generateLevel(levelNumber, gameSeed, forcedMode)
        }
    }

    fun clearCache() {
        cache.clear()
    }
}
