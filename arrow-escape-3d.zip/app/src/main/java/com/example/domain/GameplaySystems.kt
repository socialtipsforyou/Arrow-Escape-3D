package com.example.domain

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.ui.geometry.Offset
import com.example.model.ArrowBlock
import com.example.model.GridPos3D
import com.example.model.PathCheckResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * LivesManager manages player hearts, heart consumption on blocked actions,
 * and heart restoration.
 */
class LivesManager(
    val defaultMaxHearts: Int = 3
) {
    var currentHearts: Int = defaultMaxHearts
        private set

    var maxHeartsForLevel: Int = defaultMaxHearts
        private set

    fun startLevel(maxHearts: Int) {
        maxHeartsForLevel = maxHearts.coerceAtLeast(1)
        currentHearts = maxHeartsForLevel
    }

    fun consumeHeart(): Boolean {
        if (currentHearts > 0) {
            currentHearts--
        }
        return currentHearts <= 0
    }

    fun restoreHearts(amount: Int = 1) {
        currentHearts = (currentHearts + amount).coerceAtMost(maxHeartsForLevel)
    }

    fun refillAll() {
        currentHearts = maxHeartsForLevel
    }
}

/**
 * HintManager identifies a currently movable arrow block and manages hint inventory.
 */
class HintManager {
    var activeHintBlockId: Int? = null
        private set

    var activeHintRay: List<GridPos3D> = emptyList()
        private set

    fun clearActiveHint() {
        activeHintBlockId = null
        activeHintRay = emptyList()
    }

    /**
     * Finds the best movable block on the board (preferring longer or upper-layer blocks
     * that unlock other blocks) and sets it as the active highlighted hint.
     */
    fun triggerHint(boardManager: BoardManager): ArrowBlock? {
        val movable = boardManager.getMovableBlocks()
        if (movable.isEmpty()) return null

        // Prefer upper layer blocks first, then longer blocks
        val chosen = movable.maxWithOrNull(
            compareBy<ArrowBlock> { it.layer }.thenBy { it.cells.size }
        ) ?: movable.first()

        activeHintBlockId = chosen.id
        activeHintRay = boardManager.getExitRayCells(chosen)
        return chosen
    }
}

/**
 * CameraController manages the 3D perspective/isometric camera angles (yaw, pitch, zoom, pan)
 * and projects 3D board coordinates (x, y, z) into 2D screen coordinates with depth.
 */
class CameraController {
    var yawDegrees: Float = -16f
        private set
    var pitchDegrees: Float = 28f
        private set
    var zoom: Float = 1.26f
        private set
    var panOffset: Offset = Offset.Zero
        private set
    var isIsometric3DView: Boolean = true
        private set

    fun resetForMode(isMultiLayer3D: Boolean) {
        if (isMultiLayer3D) {
            yawDegrees = -24f
            pitchDegrees = 34f
            zoom = 1.26f
            isIsometric3DView = true
        } else {
            yawDegrees = -12f
            pitchDegrees = 24f
            zoom = 1.26f
            isIsometric3DView = true
        }
        panOffset = Offset.Zero
    }

    fun toggleCameraPreset() {
        isIsometric3DView = !isIsometric3DView
        if (isIsometric3DView) {
            yawDegrees = -18f
            pitchDegrees = 30f
        } else {
            // Near top-down precision view with subtle 3D bevel depth
            yawDegrees = 0f
            pitchDegrees = 10f
        }
        panOffset = Offset.Zero
    }

    fun rotate(deltaYaw: Float, deltaPitch: Float) {
        yawDegrees = (yawDegrees + deltaYaw).coerceIn(-65f, 65f)
        pitchDegrees = (pitchDegrees + deltaPitch).coerceIn(8f, 58f)
    }

    fun zoomBy(factor: Float) {
        zoom = (zoom * factor).coerceIn(0.72f, 1.85f)
    }

    fun panBy(delta: Offset) {
        panOffset = Offset(
            x = (panOffset.x + delta.x).coerceIn(-220f, 220f),
            y = (panOffset.y + delta.y).coerceIn(-220f, 220f)
        )
    }

    /**
     * Projects a 3D world point (wx, wy, wz) relative to board center into 2D screen space
     * + depth value (larger depth = closer to camera).
     */
    data class ProjectedPoint(
        val screenX: Float,
        val screenY: Float,
        val depth: Float
    )

    fun project3D(
        wx: Float,
        wy: Float,
        wz: Float,
        centerX: Float,
        centerY: Float,
        cellSizePx: Float
    ): ProjectedPoint {
        val yawRad = yawDegrees * (PI.toFloat() / 180f)
        val pitchRad = pitchDegrees * (PI.toFloat() / 180f)

        val cosYaw = cos(yawRad)
        val sinYaw = sin(yawRad)
        val cosPitch = cos(pitchRad)
        val sinPitch = sin(pitchRad)

        // Rotate in XY plane by yaw
        val rx = wx * cosYaw - wy * sinYaw
        val ry = wx * sinYaw + wy * cosYaw

        // Tilt by pitch and elevate by wz (where wz > 0 lifts upward toward top of screen)
        val screenX = centerX + panOffset.x + rx * cellSizePx * zoom
        val screenY = centerY + panOffset.y + (ry * cosPitch - wz * sinPitch * 1.35f) * cellSizePx * zoom
        val depth = ry * sinPitch + wz * cosPitch

        return ProjectedPoint(screenX, screenY, depth)
    }
}

/**
 * InputManager performs accurate 3D hit-testing against projected 3D arrow blocks,
 * selecting the front-most (highest depth / top layer) block under the user's tap.
 */
class InputManager {

    /**
     * Finds the top-most [ArrowBlock] hit by a tap at (touchX, touchY).
     * Returns the block ID or null if the tap missed all blocks.
     */
    fun findTappedBlockId(
        touchX: Float,
        touchY: Float,
        blocks: List<ArrowBlock>,
        gridWidth: Int,
        gridHeight: Int,
        canvasWidth: Float,
        canvasHeight: Float,
        cellSizePx: Float,
        camera: CameraController
    ): Int? {
        val boardCenterX = canvasWidth / 2f
        val boardCenterY = canvasHeight / 2f
        val halfW = (gridWidth - 1) / 2f
        val halfH = (gridHeight - 1) / 2f

        val hitThreshold = (cellSizePx * camera.zoom * 0.48f).coerceAtLeast(20f)

        var bestBlockId: Int? = null
        var bestDepth = Float.NEGATIVE_INFINITY
        var bestDistance = Float.MAX_VALUE

        for (block in blocks) {
            val zTop = block.layer * 0.36f + 0.155f
            val projectedCells = block.cells.map { cell ->
                camera.project3D(
                    wx = cell.x - halfW,
                    wy = cell.y - halfH,
                    wz = zTop,
                    centerX = boardCenterX,
                    centerY = boardCenterY,
                    cellSizePx = cellSizePx
                )
            }

            // Check distance to each segment of the 3D arrow's top surface
            var minDistForBlock = Float.MAX_VALUE
            var avgDepth = 0f
            for (pt in projectedCells) {
                avgDepth += pt.depth
                val d = hypot(touchX - pt.screenX, touchY - pt.screenY)
                if (d < minDistForBlock) minDistForBlock = d
            }
            avgDepth /= projectedCells.size.coerceAtLeast(1)

            for (i in 0 until projectedCells.size - 1) {
                val p1 = projectedCells[i]
                val p2 = projectedCells[i + 1]
                val segDist = distanceToSegment(
                    px = touchX,
                    py = touchY,
                    x1 = p1.screenX,
                    y1 = p1.screenY,
                    x2 = p2.screenX,
                    y2 = p2.screenY
                )
                if (segDist < minDistForBlock) minDistForBlock = segDist
            }

            if (minDistForBlock <= hitThreshold) {
                // Prioritize blocks on higher 3D layers / closer depth, or closer tap distance on same layer
                val effectiveScoreDepth = block.layer * 10f + avgDepth
                if (bestBlockId == null ||
                    minDistForBlock < bestDistance - 8f ||
                    (minDistForBlock <= bestDistance + 8f && effectiveScoreDepth > bestDepth)
                ) {
                    bestBlockId = block.id
                    bestDepth = effectiveScoreDepth
                    bestDistance = minDistForBlock
                }
            }
        }

        return bestBlockId
    }

    private fun distanceToSegment(
        px: Float,
        py: Float,
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float
    ): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        val lenSq = dx * dx + dy * dy
        if (lenSq <= 0.0001f) return hypot(px - x1, py - y1)
        val t = (((px - x1) * dx + (py - y1) * dy) / lenSq).coerceIn(0f, 1f)
        val projX = x1 + t * dx
        val projY = y1 + t * dy
        return hypot(px - projX, py - projY)
    }
}

/**
 * AudioManager provides synthesized audio effects and haptic vibration feedback.
 * Gracefully degrades if audio hardware is unavailable (e.g. muted device or JVM tests).
 */
class AudioManager(private val context: Context?) {
    var soundEnabled: Boolean = true
    var musicEnabled: Boolean = true
    var vibrationEnabled: Boolean = true

    private val audioScope = CoroutineScope(Dispatchers.Default)
    private var bgmJob: Job? = null

    fun playButtonClick() {
        if (!soundEnabled) return
        playSynthTone(startFreq = 620f, endFreq = 820f, durationMs = 75, volume = 0.78f)
    }

    fun playArrowSlideOut(comboIndex: Int = 0) {
        if (vibrationEnabled) triggerHaptic(18L)
        if (!soundEnabled) return
        val pitchBoost = (comboIndex.coerceAtMost(8)) * 45f
        playSynthTone(
            startFreq = 440f + pitchBoost,
            endFreq = 920f + pitchBoost,
            durationMs = 175,
            volume = 0.88f
        )
    }

    fun playBlockedAction() {
        if (vibrationEnabled) triggerHaptic(65L)
        if (!soundEnabled) return
        playSynthTone(startFreq = 240f, endFreq = 130f, durationMs = 200, volume = 0.92f)
    }

    fun playHintSparkle() {
        if (vibrationEnabled) triggerHaptic(25L)
        if (!soundEnabled) return
        playSynthTone(startFreq = 660f, endFreq = 1180f, durationMs = 210, volume = 0.85f)
    }

    fun playLevelComplete() {
        if (vibrationEnabled) triggerHaptic(80L)
        if (!soundEnabled) return
        audioScope.launch {
            val notes = listOf(523.25f, 659.25f, 783.99f, 1046.50f)
            for (freq in notes) {
                playSynthToneSync(freq, freq * 1.02f, 150, 0.88f)
                delay(90)
            }
        }
    }

    fun playGameOver() {
        if (vibrationEnabled) triggerHaptic(110L)
        if (!soundEnabled) return
        audioScope.launch {
            val notes = listOf(392.0f, 349.23f, 311.13f, 261.63f)
            for (freq in notes) {
                playSynthToneSync(freq, freq * 0.98f, 170, 0.88f)
                delay(110)
            }
        }
    }

    fun updateBackgroundMusic(shouldPlay: Boolean) {
        if (!shouldPlay || !musicEnabled) {
            bgmJob?.cancel()
            bgmJob = null
            return
        }
        if (bgmJob?.isActive == true) return
        bgmJob = audioScope.launch {
            val ambientChord = listOf(261.63f, 329.63f, 392.00f, 493.88f)
            var idx = 0
            while (isActive && musicEnabled) {
                val freq = ambientChord[idx % ambientChord.size]
                playSynthToneSync(freq, freq, 260, 0.22f)
                idx++
                delay(1800)
            }
        }
    }

    private fun playSynthTone(
        startFreq: Float,
        endFreq: Float,
        durationMs: Int,
        volume: Float
    ) {
        if (context == null) return
        audioScope.launch {
            playSynthToneSync(startFreq, endFreq, durationMs, volume)
        }
    }

    private suspend fun playSynthToneSync(
        startFreq: Float,
        endFreq: Float,
        durationMs: Int,
        volume: Float
    ) {
        if (context == null) return
        try {
            val sampleRate = 44100
            val toneSamples = (sampleRate * (durationMs / 1000f)).toInt().coerceAtLeast(512)
            val minBufBytes = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(4096)
            val minSamples = (minBufBytes / 2).coerceAtLeast(toneSamples + 1024)
            val samples = ShortArray(minSamples)
            var phase = 0.0

            for (i in 0 until toneSamples) {
                val progress = i.toFloat() / toneSamples
                val freq = startFreq + (endFreq - startFreq) * progress
                // Smooth attack and decay envelope
                val envelope = if (progress < 0.08f) {
                    progress / 0.08f
                } else {
                    1f - ((progress - 0.08f) / 0.92f)
                }
                phase += 2.0 * PI * freq / sampleRate
                // Combine fundamental + warm harmonic overtone for clear audibility on mobile speakers
                val wave = 0.76 * sin(phase) + 0.24 * sin(phase * 2.0)
                val sampleVal = (wave * volume * envelope * Short.MAX_VALUE).toInt()
                samples[i] = sampleVal.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }

            val bufferSizeBytes = maxOf(samples.size * 2, minBufBytes)
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSizeBytes)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(samples, 0, samples.size)
            track.setVolume(AudioTrack.getMaxVolume())
            track.play()
            delay(durationMs.toLong() + 140L)
            runCatching { track.stop() }
            track.release()
        } catch (_: Throwable) {
            // Gracefully ignore if AudioTrack is unavailable
        }
    }

    private fun triggerHaptic(durationMs: Long) {
        val ctx = context ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                v?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (_: Throwable) {
            // Ignore in test environments or devices without vibrator
        }
    }
}

/**
 * Cleanly separated Rewarded Ad Hooks interface.
 * Does NOT fake watching an ad when an ad SDK is not configured; instead reports ad availability
 * transparently so the game can offer fair coin-based alternatives or future AdMob integration.
 */
interface RewardedAdHooks {
    fun isRewardedAdAvailable(): Boolean
    fun showRewardedAdForExtraLife(onRewardEarned: () -> Unit, onAdUnavailable: (String) -> Unit)
    fun showRewardedAdForExtraHint(onRewardEarned: () -> Unit, onAdUnavailable: (String) -> Unit)
    fun showRewardedAdForDoubleCoins(onRewardEarned: () -> Unit, onAdUnavailable: (String) -> Unit)
}

class SafeRewardedAdManager : RewardedAdHooks {
    override fun isRewardedAdAvailable(): Boolean = false

    override fun showRewardedAdForExtraLife(
        onRewardEarned: () -> Unit,
        onAdUnavailable: (String) -> Unit
    ) {
        onAdUnavailable("Rewarded ads are not configured in this build. Use Coins to restore hearts!")
    }

    override fun showRewardedAdForExtraHint(
        onRewardEarned: () -> Unit,
        onAdUnavailable: (String) -> Unit
    ) {
        onAdUnavailable("Rewarded ads are not configured in this build. You can get +1 Hint for 30 Coins!")
    }

    override fun showRewardedAdForDoubleCoins(
        onRewardEarned: () -> Unit,
        onAdUnavailable: (String) -> Unit
    ) {
        onAdUnavailable("Rewarded ads are not configured in this build.")
    }
}
