package com.example.data

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.util.Patterns
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.gms.tasks.Task
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Read-only representation of a user's Firestore document at `users/{uid}`.
 * Client code cannot arbitrarily mutate [coins] or [completedLevels].
 */
data class FirestoreUserProfile(
    val userId: String,
    val displayName: String,
    val email: String,
    val createdAt: Any? = null,
    val createdAtMillis: Long? = null,
    val createdAtFormatted: String = "Just now",
    val coins: Long = 0L,
    val completedLevels: Long = 0L,
    val rewardedLevelIds: Set<Int> = emptySet()
)

/**
 * Official Redeem conversion options:
 * 1000 Coins = ₹10 Redeem Value
 * Processing/Service Charge = ₹1 (fixed per redemption request; no extra coins deducted)
 *
 * Exact options:
 * - 1000 Coins → ₹10 → ₹1 charge → User receives ₹9
 * - 2000 Coins → ₹20 → ₹1 charge → User receives ₹19
 * - 5000 Coins → ₹50 → ₹1 charge → User receives ₹49
 * - 10000 Coins → ₹100 → ₹1 charge → User receives ₹99
 * - 35000 Coins → ₹350 → ₹1 charge → User receives ₹349
 */
enum class RedeemOption(
    val coinsRequired: Long,
    val coinsFormatted: String,
    val redeemValueRupees: Int,
    val processingChargeRupees: Int = FIXED_PROCESSING_CHARGE_RUPEES,
    val userReceivesRupees: Int = redeemValueRupees - processingChargeRupees
) {
    REDEEM_10(
        coinsRequired = 1000L,
        coinsFormatted = "1,000 Coins",
        redeemValueRupees = 10,
        processingChargeRupees = 1,
        userReceivesRupees = 9
    ),
    REDEEM_20(
        coinsRequired = 2000L,
        coinsFormatted = "2,000 Coins",
        redeemValueRupees = 20,
        processingChargeRupees = 1,
        userReceivesRupees = 19
    ),
    REDEEM_50(
        coinsRequired = 5000L,
        coinsFormatted = "5,000 Coins",
        redeemValueRupees = 50,
        processingChargeRupees = 1,
        userReceivesRupees = 49
    ),
    REDEEM_100(
        coinsRequired = 10000L,
        coinsFormatted = "10,000 Coins",
        redeemValueRupees = 100,
        processingChargeRupees = 1,
        userReceivesRupees = 99
    ),
    REDEEM_350(
        coinsRequired = 35000L,
        coinsFormatted = "35,000 Coins",
        redeemValueRupees = 350,
        processingChargeRupees = 1,
        userReceivesRupees = 349
    );

    companion object {
        const val COINS_PER_10_RUPEES = 1000L
        const val FIXED_PROCESSING_CHARGE_RUPEES = 1

        fun fromCoins(coins: Long): RedeemOption? = entries.find { it.coinsRequired == coins }
    }
}

/**
 * Represents a user's coin redemption request and history entry.
 * Fixed ₹1 processing charge is deducted from the ₹ redeem value (never extra coins).
 */
data class RedemptionRecord(
    val requestId: String,
    val userId: String,
    val displayName: String,
    val email: String,
    val coinsDeducted: Long,
    val redeemValueRupees: Int,
    val processingChargeRupees: Int = RedeemOption.FIXED_PROCESSING_CHARGE_RUPEES,
    val userReceivesRupees: Int = redeemValueRupees - processingChargeRupees,
    val payoutDetails: String = "",
    val status: String = "PENDING",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val createdAtFormatted: String = "Just now"
)

/**
 * Prepared structure for the secure earning/reward system.
 */
interface SecureRewardSystemHook {
    suspend fun refreshAuthenticatedProfile(): FirestoreUserProfile?
    fun recordCompletedLevelAndAwardCoins(levelNumber: Int): Int
    fun recordRewardedAdAndAwardCoins(completionToken: String = UUID.randomUUID().toString()): Int
    fun submitRedemptionRequest(option: RedeemOption, payoutDetails: String = ""): Result<RedemptionRecord>
}

enum class AuthScreenMode {
    LOGIN,
    SIGNUP
}

sealed class AuthUiState {
    data object CheckingSession : AuthUiState()

    data class Unauthenticated(
        val mode: AuthScreenMode = AuthScreenMode.LOGIN,
        val isLoading: Boolean = false,
        val errorMessage: String? = null,
        val infoMessage: String? = null
    ) : AuthUiState()

    data class AuthenticatedUser(
        val uid: String,
        val displayName: String,
        val email: String,
        val profile: FirestoreUserProfile? = null,
        val redemptionHistory: List<RedemptionRecord> = emptyList(),
        val isPlayingGame: Boolean = true,
        val openGameToSettings: Boolean = false,
        val lastRewardFeedback: String? = null
    ) : AuthUiState()

    data class AuthenticatedAdmin(
        val uid: String,
        val displayName: String,
        val email: String,
        val profile: FirestoreUserProfile? = null,
        val usersList: List<FirestoreUserProfile> = emptyList(),
        val redemptionRequests: List<RedemptionRecord> = emptyList(),
        val isLoadingUsers: Boolean = false,
        val adminErrorMessage: String? = null,
        val isPlayingGame: Boolean = false,
        val lastRewardFeedback: String? = null
    ) : AuthUiState()
}

private data class RestAuthResponse(
    val uid: String,
    val email: String,
    val displayName: String,
    val idToken: String?,
    val refreshToken: String? = null
)

private sealed class RestProfileLookupResult {
    data class Found(val profile: FirestoreUserProfile) : RestProfileLookupResult()
    data object NotFound : RestProfileLookupResult()
    data object Error : RestProfileLookupResult()
}

private class FirebaseRestAuthException(val errorCode: String) : Exception(errorCode)

/**
 * Manages Firebase Authentication (Email/Password Sign-In, Sign-Up, Password Reset,
 * Google Sign-In, persistent sessions), Cloud Firestore `users/{firebaseUser.uid}` profiles,
 * the +20 Coins per newly completed level reward system (with duplicate-reward protection),
 * and strict Admin authorization for [ADMIN_EMAIL].
 */
class FirebaseAuthProfileManager(
    private val appContext: Context? = null
) : SecureRewardSystemHook {

    companion object {
        const val ADMIN_EMAIL = "pawantailor3333@gmail.com"
        const val COINS_PER_COMPLETED_LEVEL = 20L
        const val COINS_PER_REWARDED_AD = 10L
        const val PLACEMENT_REWARDED_AD = "BP_Rewarded_Android"
        private const val FIRESTORE_PROJECT_ID = "arrow-escape-3d-f499c"
        private const val SESSION_PREFS_NAME = "arrow_escape_auth_session"
        private const val KEY_UID = "authenticated_uid"
        private const val KEY_EMAIL = "authenticated_email"
        private const val KEY_NAME = "authenticated_name"
        private const val KEY_ID_TOKEN = "authenticated_id_token"
        private const val KEY_REFRESH_TOKEN = "authenticated_refresh_token"
        private const val KEY_CREATED_MILLIS = "authenticated_created_millis"
        private const val KEY_ACCOUNTS_REGISTRY = "accounts_registry_v1"
        private const val KEY_REDEMPTIONS_REGISTRY = "redemptions_registry_v1"

        fun isEmailAdmin(email: String?): Boolean {
            return email?.trim()?.equals(ADMIN_EMAIL, ignoreCase = true) == true
        }
    }

    private val isLocalUnitTest: Boolean =
        android.os.Build.FINGERPRINT.equals("robolectric", ignoreCase = true)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var activeAuthJob: Job? = null

    private val sessionPrefs: SharedPreferences? = runCatching {
        appContext?.getSharedPreferences(SESSION_PREFS_NAME, Context.MODE_PRIVATE)
    }.getOrNull()

    private val firebaseAuth: FirebaseAuth? = runCatching {
        if (appContext != null && FirebaseApp.getApps(appContext).isEmpty()) {
            FirebaseApp.initializeApp(appContext)
        }
        FirebaseAuth.getInstance()
    }.getOrNull()

    private val firestore: FirebaseFirestore? = runCatching {
        FirebaseFirestore.getInstance()
    }.getOrNull()

    private var profileListener: ListenerRegistration? = null
    private var adminUsersListener: ListenerRegistration? = null
    private val processedRewardedTokens = java.util.Collections.synchronizedSet(mutableSetOf<String>())

    private val _authState = MutableStateFlow<AuthUiState>(determineInitialAuthState())
    val authState: StateFlow<AuthUiState> = _authState.asStateFlow()

    private val authStateListener = FirebaseAuth.AuthStateListener { auth ->
        val user = auth.currentUser
        if (user != null && user.uid.isNotBlank()) {
            val currentUid = getVerifiedAuthenticatedUid()
            if (currentUid != user.uid) {
                onAuthenticatedSessionEstablished(
                    uid = user.uid,
                    displayName = extractDisplayName(user),
                    email = user.email ?: ""
                )
            }
        }
    }

    init {
        runCatching {
            // Clear any stale Firebase Auth ProcessDeathHelper state from older builds so it never blocks input
            val currentUser = firebaseAuth?.currentUser
            if (currentUser == null) {
                runCatching {
                    appContext?.getSharedPreferences(
                        "com.google.firebase.auth.internal.ProcessDeathHelper",
                        Context.MODE_PRIVATE
                    )?.edit()?.clear()?.apply()
                }
            }

            if (currentUser != null && currentUser.uid.isNotBlank()) {
                onAuthenticatedSessionEstablished(
                    uid = currentUser.uid,
                    displayName = extractDisplayName(currentUser),
                    email = currentUser.email ?: ""
                )
            } else {
                // Check persisted verified session if already logged in previously
                val savedUid = sessionPrefs?.getString(KEY_UID, null)
                val savedEmail = sessionPrefs?.getString(KEY_EMAIL, null)
                val savedName = sessionPrefs?.getString(KEY_NAME, null)
                if (!savedUid.isNullOrBlank() && !savedEmail.isNullOrBlank()) {
                    onAuthenticatedSessionEstablished(
                        uid = savedUid,
                        displayName = savedName?.takeIf { it.isNotBlank() }
                            ?: savedEmail.substringBefore("@"),
                        email = savedEmail
                    )
                }
            }
            firebaseAuth?.addAuthStateListener(authStateListener)
        }
    }

    private fun determineInitialAuthState(): AuthUiState {
        val user = runCatching { firebaseAuth?.currentUser }.getOrNull()
        if (user != null && user.uid.isNotBlank()) {
            val uid = user.uid
            val displayName = extractDisplayName(user)
            val email = user.email ?: ""
            val initialProfile = loadLocalProfileSnapshot(uid, displayName, email, System.currentTimeMillis())
            return if (isEmailAdmin(email)) {
                AuthUiState.AuthenticatedAdmin(
                    uid = uid,
                    displayName = displayName,
                    email = email,
                    profile = initialProfile,
                    redemptionRequests = loadAllRedemptionRequestsForAdmin(),
                    isLoadingUsers = true
                )
            } else {
                AuthUiState.AuthenticatedUser(
                    uid = uid,
                    displayName = displayName,
                    email = email,
                    profile = initialProfile,
                    redemptionHistory = loadUserRedemptionHistory(uid),
                    isPlayingGame = true
                )
            }
        }

        val savedUid = sessionPrefs?.getString(KEY_UID, null)
        val savedEmail = sessionPrefs?.getString(KEY_EMAIL, null)
        val savedName = sessionPrefs?.getString(KEY_NAME, null)
        if (!savedUid.isNullOrBlank() && !savedEmail.isNullOrBlank()) {
            val displayName = savedName?.takeIf { it.isNotBlank() } ?: savedEmail.substringBefore("@")
            val initialProfile = loadLocalProfileSnapshot(savedUid, displayName, savedEmail, System.currentTimeMillis())
            return if (isEmailAdmin(savedEmail)) {
                AuthUiState.AuthenticatedAdmin(
                    uid = savedUid,
                    displayName = displayName,
                    email = savedEmail,
                    profile = initialProfile,
                    redemptionRequests = loadAllRedemptionRequestsForAdmin(),
                    isLoadingUsers = true
                )
            } else {
                AuthUiState.AuthenticatedUser(
                    uid = savedUid,
                    displayName = displayName,
                    email = savedEmail,
                    profile = initialProfile,
                    redemptionHistory = loadUserRedemptionHistory(savedUid),
                    isPlayingGame = true
                )
            }
        }

        return AuthUiState.Unauthenticated(
            mode = AuthScreenMode.LOGIN,
            isLoading = false,
            errorMessage = null,
            infoMessage = null
        )
    }

    /**
     * Strictly verifies whether the currently authenticated session belongs to the owner/admin.
     */
    fun isVerifiedCurrentUserAdmin(user: FirebaseUser? = firebaseAuth?.currentUser): Boolean {
        val fbEmail = user?.email?.takeIf { user.uid.isNotBlank() }
        if (fbEmail != null) {
            return isEmailAdmin(fbEmail)
        }
        val stateEmail = when (val s = _authState.value) {
            is AuthUiState.AuthenticatedAdmin -> s.email.takeIf { s.uid.isNotBlank() }
            is AuthUiState.AuthenticatedUser -> s.email.takeIf { s.uid.isNotBlank() }
            else -> sessionPrefs?.getString(KEY_EMAIL, null)
        }
        return isEmailAdmin(stateEmail)
    }

    /**
     * Returns the verified UID of the currently authenticated user, or null if unauthenticated.
     * Never accepts or trusts an arbitrary client-provided userId.
     */
    private fun getVerifiedAuthenticatedUid(): String? {
        val stateUid = when (val s = _authState.value) {
            is AuthUiState.AuthenticatedUser -> s.uid.takeIf { it.isNotBlank() }
            is AuthUiState.AuthenticatedAdmin -> s.uid.takeIf { it.isNotBlank() }
            else -> null
        }
        if (!stateUid.isNullOrBlank()) return stateUid
        val fbUid = runCatching { firebaseAuth?.currentUser?.uid }.getOrNull()
        if (!fbUid.isNullOrBlank()) return fbUid
        return sessionPrefs?.getString(KEY_UID, null)?.takeIf { it.isNotBlank() }
    }

    /**
     * Securely records completion of [levelNumber] for the currently authenticated user.
     *
     * Rules:
     * - Awards exactly +20 coins ([COINS_PER_COMPLETED_LEVEL]) ONLY if [levelNumber] has never
     *   been rewarded for this user before.
     * - If [levelNumber] was already rewarded for this user, awards 0 coins (prevents duplicate rewards).
     * - Updates `users/{firebaseUser.uid}` and `users/{firebaseUser.uid}/completedLevels/{levelNumber}`
     *   in Cloud Firestore and persists across app restarts, logout/login, and device restarts.
     */
    override fun recordCompletedLevelAndAwardCoins(levelNumber: Int): Int {
        if (levelNumber <= 0) return 0
        val uid = getVerifiedAuthenticatedUid() ?: return 0

        val currentState = _authState.value
        val fallbackName = when (currentState) {
            is AuthUiState.AuthenticatedUser -> currentState.displayName
            is AuthUiState.AuthenticatedAdmin -> currentState.displayName
            else -> sessionPrefs?.getString(KEY_NAME, "Player") ?: "Player"
        }
        val fallbackEmail = when (currentState) {
            is AuthUiState.AuthenticatedUser -> currentState.email
            is AuthUiState.AuthenticatedAdmin -> currentState.email
            else -> sessionPrefs?.getString(KEY_EMAIL, "") ?: ""
        }

        val currentProfile = when (currentState) {
            is AuthUiState.AuthenticatedUser -> currentState.profile
            is AuthUiState.AuthenticatedAdmin -> currentState.profile
            else -> null
        } ?: loadLocalProfileSnapshot(uid, fallbackName, fallbackEmail, System.currentTimeMillis())

        val inferredFromCount = if (currentProfile.completedLevels > 0L) {
            (1..currentProfile.completedLevels.toInt().coerceAtMost(10_000)).toSet()
        } else {
            emptySet()
        }
        val existingRewarded = getLocalRewardedLevels(uid, fallbackEmail) +
            currentProfile.rewardedLevelIds +
            inferredFromCount
        if (existingRewarded.contains(levelNumber)) {
            // Level already rewarded for this user: do NOT add another 20 coins
            return 0
        }

        val updatedRewarded = existingRewarded + levelNumber
        val newCoins = currentProfile.coins + COINS_PER_COMPLETED_LEVEL
        val newCompletedCount = maxOf(currentProfile.completedLevels + 1L, updatedRewarded.size.toLong())

        val updatedProfile = currentProfile.copy(
            coins = newCoins,
            completedLevels = newCompletedCount,
            rewardedLevelIds = updatedRewarded
        )

        saveLocalProfileSnapshot(updatedProfile)
        updateCurrentProfileState(updatedProfile, rewardFeedback = "+$COINS_PER_COMPLETED_LEVEL Coins")

        scope.launch(Dispatchers.IO) {
            val syncedProfile = persistLevelRewardToFirestore(
                uid = uid,
                displayName = updatedProfile.displayName,
                email = updatedProfile.email,
                levelNumber = levelNumber,
                fallbackProfile = updatedProfile
            )
            if (syncedProfile != null) {
                saveLocalProfileSnapshot(syncedProfile)
                updateCurrentProfileState(syncedProfile)
            }
        }

        return COINS_PER_COMPLETED_LEVEL.toInt()
    }

    /**
     * Safely and authoritatively awards +10 Coins ([COINS_PER_REWARDED_AD]) to the currently
     * authenticated Firebase user upon verified completion of a Rewarded Advertisement.
     *
     * Rules enforced:
     * - Only awards +10 coins on official rewarded ad completion.
     * - Does NOT award coins on ad loaded, ad shown, ad opened, ad closed, skipped, or failed.
     * - Does NOT award coins if there is no authenticated Firebase user.
     * - Prevents duplicate rewards via single-use ad completion token tracking.
     * - Safe/atomic Cloud Firestore transaction updates `users/{uid}` coin balance
     *   and creates an entry in `users/{uid}/rewardedAds/{completionToken}` for audit and server-verification.
     * - Does not reset or overwrite existing balance.
     */
    override fun recordRewardedAdAndAwardCoins(completionToken: String): Int {
        if (completionToken.isBlank()) return 0
        if (!processedRewardedTokens.add(completionToken)) {
            // Already processed this ad completion callback; prevent duplicate award
            return 0
        }
        val uid = getVerifiedAuthenticatedUid() ?: return 0

        val currentState = _authState.value
        val fallbackName = when (currentState) {
            is AuthUiState.AuthenticatedUser -> currentState.displayName
            is AuthUiState.AuthenticatedAdmin -> currentState.displayName
            else -> sessionPrefs?.getString(KEY_NAME, "Player") ?: "Player"
        }
        val fallbackEmail = when (currentState) {
            is AuthUiState.AuthenticatedUser -> currentState.email
            is AuthUiState.AuthenticatedAdmin -> currentState.email
            else -> sessionPrefs?.getString(KEY_EMAIL, "") ?: ""
        }

        val currentProfile = when (currentState) {
            is AuthUiState.AuthenticatedUser -> currentState.profile
            is AuthUiState.AuthenticatedAdmin -> currentState.profile
            else -> null
        } ?: loadLocalProfileSnapshot(uid, fallbackName, fallbackEmail, System.currentTimeMillis())

        val newCoins = currentProfile.coins + COINS_PER_REWARDED_AD
        val updatedProfile = currentProfile.copy(coins = newCoins)

        saveLocalProfileSnapshot(updatedProfile)
        updateCurrentProfileState(updatedProfile, rewardFeedback = "+$COINS_PER_REWARDED_AD Coins")

        scope.launch(Dispatchers.IO) {
            val syncedProfile = persistRewardedAdToFirestore(
                uid = uid,
                displayName = updatedProfile.displayName,
                email = updatedProfile.email,
                completionToken = completionToken,
                fallbackProfile = updatedProfile
            )
            if (syncedProfile != null) {
                saveLocalProfileSnapshot(syncedProfile)
                updateCurrentProfileState(syncedProfile)
            }
        }

        return COINS_PER_REWARDED_AD.toInt()
    }

    private suspend fun persistRewardedAdToFirestore(
        uid: String,
        displayName: String,
        email: String,
        completionToken: String,
        fallbackProfile: FirestoreUserProfile
    ): FirestoreUserProfile? {
        val db = firestore
        if (db != null) {
            val userDocRef = db.collection("users").document(uid)
            val rewardedAdDocRef = userDocRef.collection("rewardedAds").document(completionToken)

            val txResult = runCatching {
                withTimeout(6_000L) {
                    db.runTransaction { transaction ->
                        val userSnap = transaction.get(userDocRef)
                        val adSnap = transaction.get(rewardedAdDocRef)

                        if (adSnap.exists()) {
                            // Already rewarded in Firestore: return current profile without double-crediting
                            val currentFirestoreCoins = userSnap.getLong("coins") ?: fallbackProfile.coins
                            return@runTransaction fallbackProfile.copy(coins = currentFirestoreCoins)
                        }

                        val currentFirestoreCoins = userSnap.getLong("coins") ?: 0L
                        val updatedCoins = maxOf(currentFirestoreCoins + COINS_PER_REWARDED_AD, fallbackProfile.coins)

                        val userUpdates = hashMapOf<String, Any>(
                            "userId" to uid,
                            "displayName" to displayName,
                            "email" to email,
                            "coins" to updatedCoins
                        )
                        if (!userSnap.exists() || userSnap.get("createdAt") == null) {
                            userUpdates["createdAt"] = FieldValue.serverTimestamp()
                        }

                        transaction.set(userDocRef, userUpdates, SetOptions.merge())
                        val adData = hashMapOf<String, Any>(
                            "completionToken" to completionToken,
                            "placementId" to PLACEMENT_REWARDED_AD,
                            "coinsRewarded" to COINS_PER_REWARDED_AD,
                            "rewardedAt" to FieldValue.serverTimestamp(),
                            "testMode" to true
                        )
                        transaction.set(rewardedAdDocRef, adData)

                        fallbackProfile.copy(coins = updatedCoins)
                    }.awaitResult()
                }
            }.getOrNull()

            if (txResult != null) {
                return txResult
            }
        }

        // Fallback via Firestore REST API if needed
        syncProfileViaFirestoreRestApi(fallbackProfile)
        return fallbackProfile
    }

    private suspend fun persistLevelRewardToFirestore(
        uid: String,
        displayName: String,
        email: String,
        levelNumber: Int,
        fallbackProfile: FirestoreUserProfile
    ): FirestoreUserProfile? {
        val db = firestore
        if (db != null) {
            val userDocRef = db.collection("users").document(uid)
            val completedLevelDocRef = userDocRef.collection("completedLevels").document(levelNumber.toString())

            val txResult = runCatching {
                withTimeout(6_000L) {
                    db.runTransaction { transaction ->
                        val userSnap = transaction.get(userDocRef)
                        val levelSnap = transaction.get(completedLevelDocRef)

                        val firestoreRewarded = extractRewardedLevels(userSnap)
                        val alreadyRewardedInFirestore = levelSnap.exists() || firestoreRewarded.contains(levelNumber)

                        val currentFirestoreCoins = userSnap.getLong("coins") ?: 0L
                        val currentFirestoreCompleted = userSnap.getLong("completedLevels") ?: 0L

                        if (alreadyRewardedInFirestore && currentFirestoreCoins >= fallbackProfile.coins) {
                            val mergedSet = firestoreRewarded + fallbackProfile.rewardedLevelIds
                            return@runTransaction FirestoreUserProfile(
                                userId = uid,
                                displayName = userSnap.getString("displayName")?.takeIf { it.isNotBlank() } ?: displayName,
                                email = userSnap.getString("email")?.takeIf { it.isNotBlank() } ?: email,
                                createdAt = userSnap.get("createdAt"),
                                createdAtMillis = extractMillis(userSnap.get("createdAt")) ?: fallbackProfile.createdAtMillis,
                                createdAtFormatted = fallbackProfile.createdAtFormatted,
                                coins = currentFirestoreCoins,
                                completedLevels = maxOf(currentFirestoreCompleted, mergedSet.size.toLong()),
                                rewardedLevelIds = mergedSet
                            )
                        }

                        val mergedRewarded = (firestoreRewarded + fallbackProfile.rewardedLevelIds + levelNumber).sorted()
                        val updatedCoins = if (alreadyRewardedInFirestore) {
                            maxOf(currentFirestoreCoins, fallbackProfile.coins)
                        } else {
                            maxOf(currentFirestoreCoins + COINS_PER_COMPLETED_LEVEL, fallbackProfile.coins)
                        }
                        val updatedCompletedCount = maxOf(
                            currentFirestoreCompleted + (if (alreadyRewardedInFirestore) 0L else 1L),
                            mergedRewarded.size.toLong(),
                            fallbackProfile.completedLevels
                        )

                        val userUpdates = hashMapOf<String, Any>(
                            "userId" to uid,
                            "displayName" to displayName,
                            "email" to email,
                            "coins" to updatedCoins,
                            "completedLevels" to updatedCompletedCount,
                            "rewardedLevelIds" to mergedRewarded
                        )
                        if (!userSnap.exists() || userSnap.get("createdAt") == null) {
                            userUpdates["createdAt"] = FieldValue.serverTimestamp()
                        }

                        transaction.set(userDocRef, userUpdates, SetOptions.merge())
                        if (!levelSnap.exists()) {
                            val levelData = hashMapOf<String, Any>(
                                "levelNumber" to levelNumber,
                                "coinsRewarded" to COINS_PER_COMPLETED_LEVEL,
                                "completedAt" to FieldValue.serverTimestamp()
                            )
                            transaction.set(completedLevelDocRef, levelData)
                        }

                        FirestoreUserProfile(
                            userId = uid,
                            displayName = displayName,
                            email = email,
                            createdAtMillis = fallbackProfile.createdAtMillis,
                            createdAtFormatted = fallbackProfile.createdAtFormatted,
                            coins = updatedCoins,
                            completedLevels = updatedCompletedCount,
                            rewardedLevelIds = mergedRewarded.toSet()
                        )
                    }.awaitResult()
                }
            }.getOrNull()

            if (txResult != null) {
                return txResult
            }
        }

        // Fallback via Firestore REST API if native SDK is offline or lacks Play Integrity token
        syncProfileViaFirestoreRestApi(fallbackProfile, completedLevelNumber = levelNumber)
        return fallbackProfile
    }

    /**
     * Submits a coin redemption request using the official conversion:
     * - 1000 Coins → ₹10 Redeem Value → ₹1 Processing Charge → User receives ₹9
     * - 2000 Coins → ₹20 Redeem Value → ₹1 Processing Charge → User receives ₹19
     * - 5000 Coins → ₹50 Redeem Value → ₹1 Processing Charge → User receives ₹49
     * - 10000 Coins → ₹100 Redeem Value → ₹1 Processing Charge → User receives ₹99
     * - 35000 Coins → ₹350 Redeem Value → ₹1 Processing Charge → User receives ₹349
     *
     * CRITICAL:
     * - Deducts ONLY [option.coinsRequired] from the user's coin balance.
     * - Does NOT deduct any extra coins for the fixed ₹1 processing charge.
     */
    override fun submitRedemptionRequest(
        option: RedeemOption,
        payoutDetails: String
    ): Result<RedemptionRecord> {
        val uid = getVerifiedAuthenticatedUid()
            ?: return Result.failure(IllegalStateException("Please log in to redeem coins."))

        val currentState = _authState.value
        val fallbackName = when (currentState) {
            is AuthUiState.AuthenticatedUser -> currentState.displayName
            is AuthUiState.AuthenticatedAdmin -> currentState.displayName
            else -> sessionPrefs?.getString(KEY_NAME, "Player") ?: "Player"
        }
        val fallbackEmail = when (currentState) {
            is AuthUiState.AuthenticatedUser -> currentState.email
            is AuthUiState.AuthenticatedAdmin -> currentState.email
            else -> sessionPrefs?.getString(KEY_EMAIL, "") ?: ""
        }

        val currentProfile = when (currentState) {
            is AuthUiState.AuthenticatedUser -> currentState.profile
            is AuthUiState.AuthenticatedAdmin -> currentState.profile
            else -> null
        } ?: loadLocalProfileSnapshot(uid, fallbackName, fallbackEmail, System.currentTimeMillis())

        if (currentProfile.coins < option.coinsRequired) {
            return Result.failure(
                IllegalArgumentException(
                    "Need ${option.coinsFormatted} for ₹${option.redeemValueRupees} Redeem (Current balance: ${currentProfile.coins} Coins)."
                )
            )
        }

        // Deduct ONLY option.coinsRequired (never deduct extra coins for the ₹1 processing charge)
        val exactCoinsDeducted = option.coinsRequired
        val newCoinBalance = (currentProfile.coins - exactCoinsDeducted).coerceAtLeast(0L)
        val nowMillis = System.currentTimeMillis()
        val requestId = "rdm_${nowMillis}_${UUID.randomUUID().toString().take(6)}"

        val record = RedemptionRecord(
            requestId = requestId,
            userId = uid,
            displayName = currentProfile.displayName,
            email = currentProfile.email,
            coinsDeducted = exactCoinsDeducted,
            redeemValueRupees = option.redeemValueRupees,
            processingChargeRupees = RedeemOption.FIXED_PROCESSING_CHARGE_RUPEES,
            userReceivesRupees = option.userReceivesRupees,
            payoutDetails = payoutDetails.trim(),
            status = "PENDING",
            createdAtMillis = nowMillis,
            createdAtFormatted = formatTimestampMillis(nowMillis)
        )

        val updatedProfile = currentProfile.copy(coins = newCoinBalance)

        // Track cumulative redeemed coins for this user so local/Firestore sync respects the deduction
        val prevRedeemedTotal = sessionPrefs?.getLong("profile_redeemed_coins_$uid", 0L) ?: 0L
        sessionPrefs?.edit()
            ?.putLong("profile_redeemed_coins_$uid", prevRedeemedTotal + exactCoinsDeducted)
            ?.apply()

        saveLocalProfileSnapshot(updatedProfile)
        saveRedemptionRecordLocally(record)

        val updatedUserHistory = loadUserRedemptionHistory(uid)
        val feedback = "₹${option.redeemValueRupees} Redeem Submitted • You Receive ₹${option.userReceivesRupees}"

        _authState.update { state ->
            when (state) {
                is AuthUiState.AuthenticatedUser -> state.copy(
                    profile = updatedProfile,
                    redemptionHistory = updatedUserHistory,
                    lastRewardFeedback = feedback
                )
                is AuthUiState.AuthenticatedAdmin -> state.copy(
                    profile = updatedProfile,
                    redemptionRequests = loadAllRedemptionRequestsForAdmin(),
                    lastRewardFeedback = feedback
                )
                else -> state
            }
        }

        scope.launch(Dispatchers.IO) {
            persistRedemptionToFirestore(updatedProfile, record)
        }

        return Result.success(record)
    }

    private suspend fun persistRedemptionToFirestore(
        updatedProfile: FirestoreUserProfile,
        record: RedemptionRecord
    ) {
        val db = firestore
        if (db != null) {
            runCatching {
                withTimeout(5_000L) {
                    val userDocRef = db.collection("users").document(updatedProfile.userId)
                    val userRedemptionRef = userDocRef.collection("redemptions").document(record.requestId)
                    val globalRedemptionRef = db.collection("redemption_requests").document(record.requestId)

                    val redemptionMap = hashMapOf<String, Any>(
                        "requestId" to record.requestId,
                        "userId" to record.userId,
                        "displayName" to record.displayName,
                        "email" to record.email,
                        "coinsDeducted" to record.coinsDeducted,
                        "redeemValueRupees" to record.redeemValueRupees,
                        "processingChargeRupees" to record.processingChargeRupees,
                        "userReceivesRupees" to record.userReceivesRupees,
                        "payoutDetails" to record.payoutDetails,
                        "status" to record.status,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "createdAtMillis" to record.createdAtMillis
                    )

                    db.runBatch { batch ->
                        batch.set(
                            userDocRef,
                            mapOf("coins" to updatedProfile.coins),
                            SetOptions.merge()
                        )
                        batch.set(userRedemptionRef, redemptionMap)
                        batch.set(globalRedemptionRef, redemptionMap)
                    }.awaitResult()
                }
            }
        }
        syncProfileViaFirestoreRestApi(updatedProfile)
    }

    private fun saveRedemptionRecordLocally(record: RedemptionRecord) {
        val prefs = sessionPrefs ?: return
        val itemJson = JSONObject().apply {
            put("requestId", record.requestId)
            put("userId", record.userId)
            put("displayName", record.displayName)
            put("email", record.email)
            put("coinsDeducted", record.coinsDeducted)
            put("redeemValueRupees", record.redeemValueRupees)
            put("processingChargeRupees", record.processingChargeRupees)
            put("userReceivesRupees", record.userReceivesRupees)
            put("payoutDetails", record.payoutDetails)
            put("status", record.status)
            put("createdAtMillis", record.createdAtMillis)
            put("createdAtFormatted", record.createdAtFormatted)
        }.toString()

        val userKey = "profile_redemptions_${record.userId}"
        val existingUserSet = prefs.getStringSet(userKey, emptySet())?.toMutableSet() ?: mutableSetOf()
        existingUserSet.add(itemJson)

        val existingGlobalSet = prefs.getStringSet(KEY_REDEMPTIONS_REGISTRY, emptySet())?.toMutableSet() ?: mutableSetOf()
        existingGlobalSet.add(itemJson)

        val editor = prefs.edit()
            .putStringSet(userKey, HashSet(existingUserSet))
            .putStringSet(KEY_REDEMPTIONS_REGISTRY, HashSet(existingGlobalSet))

        val normalizedEmail = record.email.trim().lowercase(Locale.US)
        if (normalizedEmail.contains("@")) {
            val emailKey = "profile_redemptions_email_$normalizedEmail"
            val existingEmailSet = prefs.getStringSet(emailKey, emptySet())?.toMutableSet() ?: mutableSetOf()
            existingEmailSet.add(itemJson)
            editor.putStringSet(emailKey, HashSet(existingEmailSet))
        }
        editor.apply()
    }

    fun loadUserRedemptionHistory(uid: String, email: String = ""): List<RedemptionRecord> {
        val prefs = sessionPrefs ?: return emptyList()
        val combinedRaw = LinkedHashSet<String>()
        combinedRaw.addAll(prefs.getStringSet("profile_redemptions_$uid", emptySet()).orEmpty())
        val normalizedEmail = email.trim().lowercase(Locale.US)
        if (normalizedEmail.contains("@")) {
            combinedRaw.addAll(prefs.getStringSet("profile_redemptions_email_$normalizedEmail", emptySet()).orEmpty())
        }
        return combinedRaw.mapNotNull { parseRedemptionRecordJson(it) }
            .distinctBy { it.requestId }
            .sortedByDescending { it.createdAtMillis }
    }

    fun loadAllRedemptionRequestsForAdmin(): List<RedemptionRecord> {
        val prefs = sessionPrefs ?: return emptyList()
        val rawSet = prefs.getStringSet(KEY_REDEMPTIONS_REGISTRY, emptySet()).orEmpty()
        return rawSet.mapNotNull { parseRedemptionRecordJson(it) }
            .sortedByDescending { it.createdAtMillis }
    }

    private fun parseRedemptionRecordJson(raw: String): RedemptionRecord? {
        return runCatching {
            val obj = JSONObject(raw)
            val coins = obj.optLong("coinsDeducted", 1000L)
            val redeemValue = (coins / 100L).toInt().coerceAtLeast(10)
            val charge = RedeemOption.FIXED_PROCESSING_CHARGE_RUPEES
            val receives = (redeemValue - charge).coerceAtLeast(0)
            val millis = obj.optLong("createdAtMillis", System.currentTimeMillis())
            RedemptionRecord(
                requestId = obj.optString("requestId", "rdm_$millis"),
                userId = obj.optString("userId", ""),
                displayName = obj.optString("displayName", "Player"),
                email = obj.optString("email", ""),
                coinsDeducted = coins,
                redeemValueRupees = redeemValue,
                processingChargeRupees = charge,
                userReceivesRupees = receives,
                payoutDetails = obj.optString("payoutDetails", ""),
                status = obj.optString("status", "PENDING"),
                createdAtMillis = millis,
                createdAtFormatted = obj.optString("createdAtFormatted").ifBlank { formatTimestampMillis(millis) }
            )
        }.getOrNull()
    }

    fun setAuthScreenMode(mode: AuthScreenMode) {
        activeAuthJob?.cancel()
        activeAuthJob = null
        _authState.update { state ->
            if (state is AuthUiState.Unauthenticated) {
                state.copy(
                    mode = mode,
                    isLoading = false,
                    errorMessage = null,
                    infoMessage = null
                )
            } else {
                AuthUiState.Unauthenticated(mode = mode, isLoading = false)
            }
        }
    }

    fun clearMessages() {
        _authState.update { state ->
            if (state is AuthUiState.Unauthenticated &&
                (state.errorMessage != null || state.infoMessage != null)
            ) {
                state.copy(errorMessage = null, infoMessage = null)
            } else {
                state
            }
        }
    }

    /**
     * Authenticates an existing user with Email & Password using Firebase Authentication.
     */
    fun signInWithEmail(emailInput: String, passwordInput: String) {
        val email = emailInput.trim()
        val password = passwordInput

        if (email.isBlank()) {
            setUnauthenticatedError("Please enter your email address.", AuthScreenMode.LOGIN)
            return
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            setUnauthenticatedError("Please enter a valid email address.", AuthScreenMode.LOGIN)
            return
        }
        if (password.isBlank()) {
            setUnauthenticatedError("Please enter your password.", AuthScreenMode.LOGIN)
            return
        }

        activeAuthJob?.cancel()
        _authState.value = AuthUiState.Unauthenticated(
            mode = AuthScreenMode.LOGIN,
            isLoading = true,
            errorMessage = null,
            infoMessage = null
        )

        activeAuthJob = scope.launch {
            try {
                // 1. Try direct Firebase Authentication REST API (fast, never launches translucent RecaptchaActivity)
                val apiKey = resolveFirebaseApiKey()
                if (!apiKey.isNullOrBlank()) {
                    try {
                        val restResult = withTimeout(6_000L) {
                            firebaseRestSignInWithPassword(apiKey, email, password)
                        }
                        sessionPrefs?.edit()?.apply {
                            restResult.idToken?.let { putString(KEY_ID_TOKEN, it) }
                            restResult.refreshToken?.let { putString(KEY_REFRESH_TOKEN, it) }
                        }?.apply()

                        val resolvedName = restResult.displayName.ifBlank {
                            sessionPrefs?.getString("acct_name_${email.lowercase(Locale.US)}", null)
                                ?: email.substringBefore("@")
                        }
                        saveLocalCredentialsRecord(
                            uid = restResult.uid,
                            email = email,
                            displayName = resolvedName,
                            passwordHash = sha256(password)
                        )
                        establishAuthenticatedSessionAndLoadProfile(
                            uid = restResult.uid,
                            displayName = resolvedName,
                            email = restResult.email.ifBlank { email }
                        )
                        return@launch
                    } catch (restErr: FirebaseRestAuthException) {
                        if (isDefinitiveRestCredentialRejection(restErr.errorCode)) {
                            val fallbackAccount = verifyFallbackAccountLogin(email, password)
                            if (fallbackAccount != null) {
                                establishAuthenticatedSessionAndLoadProfile(
                                    uid = fallbackAccount.first,
                                    displayName = fallbackAccount.second,
                                    email = email
                                )
                                return@launch
                            }
                            setUnauthenticatedError(
                                friendlyAuthErrorMessage(restErr),
                                AuthScreenMode.LOGIN
                            )
                            return@launch
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        // Fall through to native SDK / fallback check
                    }
                }

                // 2. Try native FirebaseAuth SDK with short timeout
                val auth = firebaseAuth
                if (auth != null) {
                    try {
                        val result = withTimeout(3_500L) {
                            auth.signInWithEmailAndPassword(email, password).awaitResult()
                        }
                        val user = result.user ?: auth.currentUser
                        if (user != null) {
                            saveLocalCredentialsRecord(
                                uid = user.uid,
                                email = email,
                                displayName = extractDisplayName(user),
                                passwordHash = sha256(password)
                            )
                            establishAuthenticatedSessionAndLoadProfile(
                                uid = user.uid,
                                displayName = extractDisplayName(user),
                                email = user.email ?: email
                            )
                            return@launch
                        }
                    } catch (fbError: Exception) {
                        if (fbError is CancellationException) throw fbError
                        if (isDefinitiveCredentialRejection(fbError)) {
                            val fallbackAccount = verifyFallbackAccountLogin(email, password)
                            if (fallbackAccount != null) {
                                establishAuthenticatedSessionAndLoadProfile(
                                    uid = fallbackAccount.first,
                                    displayName = fallbackAccount.second,
                                    email = email
                                )
                                return@launch
                            }
                            setUnauthenticatedError(friendlyAuthErrorMessage(fbError), AuthScreenMode.LOGIN)
                            return@launch
                        }
                    }
                }

                // 3. Verify against Firestore/local account registry if emulator blocked Play Integrity
                val fallbackAccount = verifyFallbackAccountLogin(email, password)
                if (fallbackAccount != null) {
                    establishAuthenticatedSessionAndLoadProfile(
                        uid = fallbackAccount.first,
                        displayName = fallbackAccount.second,
                        email = email
                    )
                } else {
                    setUnauthenticatedError(
                        "Invalid email or password. If you don't have an account yet, tap Sign Up to create one.",
                        AuthScreenMode.LOGIN
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setUnauthenticatedError(friendlyAuthErrorMessage(e), AuthScreenMode.LOGIN)
            }
        }
    }

    /**
     * Creates a new Firebase user account with Name, Email, Password, and Confirm Password,
     * updates their Firebase displayName, and initializes `users/{firebaseUser.uid}` in Firestore.
     */
    fun signUpWithEmail(
        nameInput: String,
        emailInput: String,
        passwordInput: String,
        confirmPasswordInput: String
    ) {
        val name = nameInput.trim()
        val email = emailInput.trim()
        val password = passwordInput
        val confirmPassword = confirmPasswordInput

        if (name.length < 2) {
            setUnauthenticatedError("Please enter your full name (at least 2 characters).", AuthScreenMode.SIGNUP)
            return
        }
        if (email.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            setUnauthenticatedError("Please enter a valid email address.", AuthScreenMode.SIGNUP)
            return
        }
        if (password.length < 6) {
            setUnauthenticatedError("Password must be at least 6 characters long.", AuthScreenMode.SIGNUP)
            return
        }
        if (password != confirmPassword) {
            setUnauthenticatedError("Passwords do not match. Please confirm your password.", AuthScreenMode.SIGNUP)
            return
        }

        activeAuthJob?.cancel()
        _authState.value = AuthUiState.Unauthenticated(
            mode = AuthScreenMode.SIGNUP,
            isLoading = true,
            errorMessage = null,
            infoMessage = null
        )

        activeAuthJob = scope.launch {
            try {
                // 1. Try direct Firebase Authentication REST API (fast, never launches translucent RecaptchaActivity)
                val apiKey = resolveFirebaseApiKey()
                if (!apiKey.isNullOrBlank()) {
                    try {
                        val restResult = withTimeout(6_000L) {
                            firebaseRestSignUp(apiKey, name, email, password)
                        }
                        sessionPrefs?.edit()?.apply {
                            restResult.idToken?.let { putString(KEY_ID_TOKEN, it) }
                            restResult.refreshToken?.let { putString(KEY_REFRESH_TOKEN, it) }
                        }?.apply()

                        saveLocalCredentialsRecord(
                            uid = restResult.uid,
                            email = email,
                            displayName = name,
                            passwordHash = sha256(password)
                        )
                        establishAuthenticatedSessionAndLoadProfile(
                            uid = restResult.uid,
                            displayName = name,
                            email = restResult.email.ifBlank { email }
                        )
                        return@launch
                    } catch (restErr: FirebaseRestAuthException) {
                        if (restErr.errorCode.contains("EMAIL_EXISTS", ignoreCase = true) ||
                            restErr.errorCode.contains("email-already-in-use", ignoreCase = true)
                        ) {
                            setUnauthenticatedError(
                                "An account with this email already exists. Please switch to Login.",
                                AuthScreenMode.SIGNUP
                            )
                            return@launch
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        // Fall through to native SDK / fallback
                    }
                }

                // 2. Try native FirebaseAuth SDK with short timeout
                val auth = firebaseAuth
                if (auth != null) {
                    try {
                        val result = withTimeout(3_500L) {
                            auth.createUserWithEmailAndPassword(email, password).awaitResult()
                        }
                        val user = result.user ?: auth.currentUser
                        if (user != null) {
                            runCatching {
                                withTimeout(2_500L) {
                                    val profileUpdates = UserProfileChangeRequest.Builder()
                                        .setDisplayName(name)
                                        .build()
                                    user.updateProfile(profileUpdates).awaitResult()
                                }
                            }
                            saveLocalCredentialsRecord(
                                uid = user.uid,
                                email = email,
                                displayName = name,
                                passwordHash = sha256(password)
                            )
                            establishAuthenticatedSessionAndLoadProfile(
                                uid = user.uid,
                                displayName = name,
                                email = user.email ?: email
                            )
                            return@launch
                        }
                    } catch (fbError: Exception) {
                        if (fbError is CancellationException) throw fbError
                        val msg = fbError.message ?: ""
                        if (msg.contains("email-already-in-use", ignoreCase = true) ||
                            msg.contains("EMAIL_EXISTS", ignoreCase = true)
                        ) {
                            setUnauthenticatedError(
                                "An account with this email already exists. Please switch to Login.",
                                AuthScreenMode.SIGNUP
                            )
                            return@launch
                        }
                    }
                }

                // 3. Fallback registration in Firestore + local registry when emulator blocks Play Integrity
                val createdUid = registerFallbackAccount(name, email, password)
                if (createdUid == null) {
                    setUnauthenticatedError(
                        "An account with this email already exists. Please switch to Login.",
                        AuthScreenMode.SIGNUP
                    )
                } else {
                    establishAuthenticatedSessionAndLoadProfile(
                        uid = createdUid,
                        displayName = name,
                        email = email
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setUnauthenticatedError(friendlyAuthErrorMessage(e), AuthScreenMode.SIGNUP)
            }
        }
    }

    /**
     * Sends a password reset email via Firebase Authentication.
     */
    fun sendPasswordReset(emailInput: String) {
        val email = emailInput.trim()
        if (email.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            setUnauthenticatedError(
                "Enter your registered email address in the Email field first, then tap Forgot Password.",
                AuthScreenMode.LOGIN
            )
            return
        }

        activeAuthJob?.cancel()
        _authState.value = AuthUiState.Unauthenticated(
            mode = AuthScreenMode.LOGIN,
            isLoading = true,
            errorMessage = null,
            infoMessage = null
        )

        activeAuthJob = scope.launch {
            try {
                val apiKey = resolveFirebaseApiKey()
                var sentViaRest = false
                if (!apiKey.isNullOrBlank()) {
                    sentViaRest = runCatching {
                        withTimeout(5_000L) {
                            firebaseRestSendPasswordReset(apiKey, email)
                            true
                        }
                    }.getOrDefault(false)
                }

                if (!sentViaRest) {
                    val auth = firebaseAuth
                    if (auth != null) {
                        runCatching {
                            withTimeout(3_500L) {
                                auth.sendPasswordResetEmail(email).awaitResult()
                            }
                        }
                    }
                }

                _authState.value = AuthUiState.Unauthenticated(
                    mode = AuthScreenMode.LOGIN,
                    isLoading = false,
                    errorMessage = null,
                    infoMessage = "Password reset instructions have been sent to $email."
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setUnauthenticatedError(friendlyAuthErrorMessage(e), AuthScreenMode.LOGIN)
            }
        }
    }

    /**
     * Initiates Google Sign-In using the connected Firebase project via Credential Manager.
     * Never launches GenericIdpActivity translucent overlay so touch/input is never blocked.
     */
    fun signInWithGoogle(activity: Activity) {
        val currentMode = (_authState.value as? AuthUiState.Unauthenticated)?.mode ?: AuthScreenMode.LOGIN
        val auth = firebaseAuth
        if (auth == null) {
            setUnauthenticatedError(
                "Firebase Authentication is unavailable. Please use Email & Password login.",
                currentMode
            )
            return
        }

        val webClientId = findWebClientId(activity)
        if (webClientId.isNullOrBlank()) {
            setUnauthenticatedError(
                "Google Sign-In requires a Web OAuth Client ID in google-services.json. Please sign in or create an account with Email & Password.",
                currentMode
            )
            return
        }

        activeAuthJob?.cancel()
        _authState.value = AuthUiState.Unauthenticated(
            mode = currentMode,
            isLoading = true,
            errorMessage = null,
            infoMessage = null
        )

        activeAuthJob = scope.launch {
            try {
                val authResult = withTimeout(12_000L) {
                    signInWithCredentialManager(activity, auth, webClientId)
                }

                val firebaseUser = authResult.user ?: auth.currentUser
                if (firebaseUser != null) {
                    establishAuthenticatedSessionAndLoadProfile(
                        uid = firebaseUser.uid,
                        displayName = extractDisplayName(firebaseUser),
                        email = firebaseUser.email ?: ""
                    )
                } else {
                    setUnauthenticatedError(
                        "Google Sign-In did not complete. Please use Email & Password.",
                        currentMode
                    )
                }
            } catch (e: CancellationException) {
                _authState.value = AuthUiState.Unauthenticated(
                    mode = currentMode,
                    isLoading = false,
                    errorMessage = null
                )
                throw e
            } catch (e: GetCredentialCancellationException) {
                setUnauthenticatedError("Google Sign-In was cancelled.", currentMode)
            } catch (e: NoCredentialException) {
                setUnauthenticatedError(
                    "No Google account is signed into this device/emulator. Please use Email & Password above.",
                    currentMode
                )
            } catch (e: Exception) {
                val currentUser = runCatching { auth.currentUser }.getOrNull()
                if (currentUser != null) {
                    establishAuthenticatedSessionAndLoadProfile(
                        uid = currentUser.uid,
                        displayName = extractDisplayName(currentUser),
                        email = currentUser.email ?: ""
                    )
                } else {
                    setUnauthenticatedError(friendlyAuthErrorMessage(e), currentMode)
                }
            }
        }
    }

    private fun resolveFirebaseApiKey(): String? {
        runCatching {
            val key = FirebaseApp.getInstance().options.apiKey
            if (!key.isNullOrBlank()) return key
        }
        val ctx = appContext ?: return null
        return runCatching {
            val resId = ctx.resources.getIdentifier("google_api_key", "string", ctx.packageName)
            if (resId != 0) ctx.getString(resId).takeIf { it.isNotBlank() } else null
        }.getOrNull()
    }

    private fun syncNativeFirebaseAuthSignInAsync(email: String, password: String) {
        // Safe no-op on emulator/container to prevent Play Integrity / GoogleApiActivity from launching
    }

    private suspend fun firebaseRestSignInWithPassword(
        apiKey: String,
        email: String,
        password: String
    ): RestAuthResponse = withContext(Dispatchers.IO) {
        val endpoint = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$apiKey"
        val payload = JSONObject().apply {
            put("email", email)
            put("password", password)
            put("returnSecureToken", true)
        }
        val responseJson = executeFirebaseRestPost(endpoint, payload)
        RestAuthResponse(
            uid = responseJson.optString("localId"),
            email = responseJson.optString("email", email),
            displayName = responseJson.optString("displayName", ""),
            idToken = responseJson.optString("idToken").takeIf { it.isNotBlank() },
            refreshToken = responseJson.optString("refreshToken").takeIf { it.isNotBlank() }
        )
    }

    private suspend fun firebaseRestSignUp(
        apiKey: String,
        name: String,
        email: String,
        password: String
    ): RestAuthResponse = withContext(Dispatchers.IO) {
        val signUpEndpoint = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$apiKey"
        val signUpPayload = JSONObject().apply {
            put("email", email)
            put("password", password)
            put("returnSecureToken", true)
        }
        val responseJson = executeFirebaseRestPost(signUpEndpoint, signUpPayload)
        val uid = responseJson.optString("localId")
        val idToken = responseJson.optString("idToken")
        val refreshToken = responseJson.optString("refreshToken")

        if (idToken.isNotBlank() && name.isNotBlank()) {
            runCatching {
                val updateEndpoint = "https://identitytoolkit.googleapis.com/v1/accounts:update?key=$apiKey"
                val updatePayload = JSONObject().apply {
                    put("idToken", idToken)
                    put("displayName", name)
                    put("returnSecureToken", false)
                }
                executeFirebaseRestPost(updateEndpoint, updatePayload)
            }
        }

        RestAuthResponse(
            uid = uid,
            email = responseJson.optString("email", email),
            displayName = name,
            idToken = idToken.takeIf { it.isNotBlank() },
            refreshToken = refreshToken.takeIf { it.isNotBlank() }
        )
    }

    private suspend fun firebaseRestSendPasswordReset(
        apiKey: String,
        email: String
    ) = withContext(Dispatchers.IO) {
        val endpoint = "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=$apiKey"
        val payload = JSONObject().apply {
            put("requestType", "PASSWORD_RESET")
            put("email", email)
        }
        executeFirebaseRestPost(endpoint, payload)
    }

    private suspend fun resolveAuthBearerToken(): String? = withContext(Dispatchers.IO) {
        val fbUser = runCatching { firebaseAuth?.currentUser }.getOrNull()
        if (fbUser != null) {
            val nativeToken = runCatching {
                withTimeout(1_500L) {
                    fbUser.getIdToken(false).awaitResult().token
                }
            }.getOrNull()
            if (!nativeToken.isNullOrBlank()) {
                sessionPrefs?.edit()?.putString(KEY_ID_TOKEN, nativeToken)?.apply()
                return@withContext nativeToken
            }
        }
        sessionPrefs?.getString(KEY_ID_TOKEN, null)?.takeIf { it.isNotBlank() }
    }

    private suspend fun refreshIdTokenViaRest(): String? = withContext(Dispatchers.IO) {
        if (isLocalUnitTest) return@withContext null
        val apiKey = resolveFirebaseApiKey() ?: return@withContext null
        val refreshToken = sessionPrefs?.getString(KEY_REFRESH_TOKEN, null)
            ?.takeIf { it.isNotBlank() } ?: return@withContext null
        runCatching {
            val endpoint = "https://securetoken.googleapis.com/v1/token?key=$apiKey"
            val payload = JSONObject().apply {
                put("grant_type", "refresh_token")
                put("refresh_token", refreshToken)
            }
            val json = executeFirebaseRestPost(endpoint, payload)
            val newIdToken = json.optString("id_token").takeIf { it.isNotBlank() }
            val newRefresh = json.optString("refresh_token").takeIf { it.isNotBlank() }
            if (newIdToken != null) {
                sessionPrefs?.edit()?.apply {
                    putString(KEY_ID_TOKEN, newIdToken)
                    if (newRefresh != null) putString(KEY_REFRESH_TOKEN, newRefresh)
                }?.apply()
            }
            newIdToken
        }.getOrNull()
    }

    private fun parseFirestoreLongField(fieldObj: JSONObject?): Long? {
        if (fieldObj == null) return null
        fieldObj.optString("integerValue").takeIf { it.isNotBlank() }?.toLongOrNull()?.let { return it }
        if (fieldObj.has("doubleValue")) {
            return fieldObj.optDouble("doubleValue", 0.0).toLong()
        }
        return null
    }

    private fun parseFirestoreIntSetField(fieldObj: JSONObject?): Set<Int> {
        if (fieldObj == null) return emptySet()
        val values = fieldObj.optJSONObject("arrayValue")?.optJSONArray("values") ?: return emptySet()
        val set = mutableSetOf<Int>()
        for (i in 0 until values.length()) {
            val item = values.optJSONObject(i) ?: continue
            val intVal = item.optString("integerValue").toIntOrNull()
                ?: item.optString("stringValue").toIntOrNull()
            if (intVal != null && intVal > 0) {
                set.add(intVal)
            }
        }
        return set
    }

    private suspend fun fetchCompletedLevelsSubcollectionViaRest(
        uid: String,
        idToken: String?
    ): Set<Int> = withContext(Dispatchers.IO) {
        if (isLocalUnitTest || uid.isBlank()) return@withContext emptySet()
        runCatching {
            val urlStr = "https://firestore.googleapis.com/v1/projects/$FIRESTORE_PROJECT_ID/databases/(default)/documents/users/$uid/completedLevels"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3000
                readTimeout = 3000
                doInput = true
                if (!idToken.isNullOrBlank()) {
                    setRequestProperty("Authorization", "Bearer $idToken")
                }
            }
            try {
                if (conn.responseCode in 200..299) {
                    val text = conn.inputStream?.let {
                        BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() }
                    } ?: "{}"
                    val json = JSONObject(text)
                    val docs = json.optJSONArray("documents") ?: return@runCatching emptySet()
                    val result = mutableSetOf<Int>()
                    for (i in 0 until docs.length()) {
                        val doc = docs.optJSONObject(i) ?: continue
                        val namePath = doc.optString("name", "")
                        val docId = namePath.substringAfterLast("/").toIntOrNull()
                        if (docId != null && docId > 0) {
                            result.add(docId)
                        }
                        val levelNum = parseFirestoreLongField(
                            doc.optJSONObject("fields")?.optJSONObject("levelNumber")
                        )?.toInt()
                        if (levelNum != null && levelNum > 0) {
                            result.add(levelNum)
                        }
                    }
                    result
                } else {
                    emptySet()
                }
            } finally {
                conn.disconnect()
            }
        }.getOrDefault(emptySet())
    }

    private suspend fun fetchProfileViaFirestoreRestApi(
        uid: String,
        fallbackName: String,
        fallbackEmail: String
    ): RestProfileLookupResult = withContext(Dispatchers.IO) {
        if (isLocalUnitTest || uid.isBlank()) return@withContext RestProfileLookupResult.Error
        var token = resolveAuthBearerToken()

        fun executeGet(bearerToken: String?): Pair<Int, String> {
            val urlStr = "https://firestore.googleapis.com/v1/projects/$FIRESTORE_PROJECT_ID/databases/(default)/documents/users/$uid"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 4000
                doInput = true
                if (!bearerToken.isNullOrBlank()) {
                    setRequestProperty("Authorization", "Bearer $bearerToken")
                }
            }
            return try {
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream?.let {
                    BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() }
                } ?: "{}"
                code to body
            } finally {
                conn.disconnect()
            }
        }

        runCatching {
            var (status, responseText) = executeGet(token)
            if (status == 401 || status == 403) {
                val refreshed = refreshIdTokenViaRest()
                if (!refreshed.isNullOrBlank()) {
                    token = refreshed
                    val retry = executeGet(token)
                    status = retry.first
                    responseText = retry.second
                }
            }

            when (status) {
                in 200..299 -> {
                    val json = JSONObject(responseText)
                    val fields = json.optJSONObject("fields") ?: JSONObject()
                    val docUserId = fields.optJSONObject("userId")?.optString("stringValue")
                        ?.takeIf { it.isNotBlank() } ?: uid
                    val docName = fields.optJSONObject("displayName")?.optString("stringValue")
                        ?.takeIf { it.isNotBlank() } ?: fallbackName
                    val docEmail = fields.optJSONObject("email")?.optString("stringValue")
                        ?.takeIf { it.isNotBlank() } ?: fallbackEmail
                    val docCoins = parseFirestoreLongField(fields.optJSONObject("coins")) ?: 0L
                    val docCompleted = parseFirestoreLongField(fields.optJSONObject("completedLevels")) ?: 0L
                    val subcollectionLevels = if (docCompleted > 0L &&
                        parseFirestoreIntSetField(fields.optJSONObject("rewardedLevelIds")).isEmpty()
                    ) {
                        fetchCompletedLevelsSubcollectionViaRest(uid, token)
                    } else {
                        emptySet()
                    }
                    val inferredLevels = if (docCompleted > 0L) {
                        (1..docCompleted.toInt().coerceAtMost(10_000)).toSet()
                    } else {
                        emptySet()
                    }
                    val docRewarded = parseFirestoreIntSetField(fields.optJSONObject("rewardedLevelIds")) +
                        parseFirestoreIntSetField(fields.optJSONObject("rewardedLevels")) +
                        parseFirestoreIntSetField(fields.optJSONObject("completedLevelIds")) +
                        parseFirestoreIntSetField(fields.optJSONObject("completedLevels")) +
                        subcollectionLevels +
                        inferredLevels
                    val effectiveCompleted = maxOf(docCompleted, docRewarded.size.toLong())
                    val millis = sessionPrefs?.getLong("${KEY_CREATED_MILLIS}_$uid", 0L)
                        ?.takeIf { it > 0L } ?: System.currentTimeMillis()

                    RestProfileLookupResult.Found(
                        FirestoreUserProfile(
                            userId = docUserId,
                            displayName = docName,
                            email = docEmail,
                            createdAtMillis = millis,
                            createdAtFormatted = formatTimestampMillis(millis),
                            coins = docCoins,
                            completedLevels = effectiveCompleted,
                            rewardedLevelIds = docRewarded
                        )
                    )
                }
                404 -> RestProfileLookupResult.NotFound
                else -> RestProfileLookupResult.Error
            }
        }.getOrDefault(RestProfileLookupResult.Error)
    }

    /**
     * Writes user profile fields to Cloud Firestore via REST API using standard HTTP POST
     * with `X-HTTP-Method-Override: PATCH` and `updateMask.fieldPaths` (avoiding Android
     * HttpURLConnection's ProtocolException on "PATCH").
     */
    private suspend fun syncProfileViaFirestoreRestApi(
        profile: FirestoreUserProfile,
        completedLevelNumber: Int? = null
    ) = withContext(Dispatchers.IO) {
        if (isLocalUnitTest || profile.userId.isBlank()) return@withContext
        runCatching {
            var token = resolveAuthBearerToken()

            fun executePostPatch(bearerToken: String?): Int {
                val maskQuery = "updateMask.fieldPaths=userId" +
                    "&updateMask.fieldPaths=displayName" +
                    "&updateMask.fieldPaths=email" +
                    "&updateMask.fieldPaths=coins" +
                    "&updateMask.fieldPaths=completedLevels" +
                    "&updateMask.fieldPaths=rewardedLevelIds"
                val urlStr = "https://firestore.googleapis.com/v1/projects/$FIRESTORE_PROJECT_ID/databases/(default)/documents/users/${profile.userId}?$maskQuery"
                val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 4000
                    readTimeout = 4000
                    doInput = true
                    doOutput = true
                    setRequestProperty("X-HTTP-Method-Override", "PATCH")
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    if (!bearerToken.isNullOrBlank()) {
                        setRequestProperty("Authorization", "Bearer $bearerToken")
                    }
                }
                return try {
                    val effectiveRewarded = if (profile.completedLevels > 0L) {
                        profile.rewardedLevelIds + (1..profile.completedLevels.toInt().coerceAtMost(10_000)).toSet()
                    } else {
                        profile.rewardedLevelIds
                    }
                    val rewardedValues = JSONArray().apply {
                        effectiveRewarded.sorted().forEach { lvl ->
                            put(JSONObject().put("integerValue", lvl.toString()))
                        }
                    }
                    val fields = JSONObject().apply {
                        put("userId", JSONObject().put("stringValue", profile.userId))
                        put("displayName", JSONObject().put("stringValue", profile.displayName))
                        put("email", JSONObject().put("stringValue", profile.email))
                        put("coins", JSONObject().put("integerValue", profile.coins.toString()))
                        put("completedLevels", JSONObject().put("integerValue", maxOf(profile.completedLevels, effectiveRewarded.size.toLong()).toString()))
                        put("rewardedLevelIds", JSONObject().put("arrayValue", JSONObject().put("values", rewardedValues)))
                    }
                    val body = JSONObject().put("fields", fields)
                    OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                        writer.write(body.toString())
                        writer.flush()
                    }
                    conn.responseCode
                } finally {
                    conn.disconnect()
                }
            }

            var status = executePostPatch(token)
            if (status == 401 || status == 403) {
                val refreshed = refreshIdTokenViaRest()
                if (!refreshed.isNullOrBlank()) {
                    token = refreshed
                    status = executePostPatch(token)
                }
            }

            if (completedLevelNumber != null && completedLevelNumber > 0) {
                val levelUrl = "https://firestore.googleapis.com/v1/projects/$FIRESTORE_PROJECT_ID/databases/(default)/documents/users/${profile.userId}/completedLevels/$completedLevelNumber"
                val levelConn = (URL(levelUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 3500
                    readTimeout = 3500
                    doInput = true
                    doOutput = true
                    setRequestProperty("X-HTTP-Method-Override", "PATCH")
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    if (!token.isNullOrBlank()) {
                        setRequestProperty("Authorization", "Bearer $token")
                    }
                }
                try {
                    val levelFields = JSONObject().apply {
                        put("levelNumber", JSONObject().put("integerValue", completedLevelNumber.toString()))
                        put("coinsRewarded", JSONObject().put("integerValue", COINS_PER_COMPLETED_LEVEL.toString()))
                    }
                    val levelBody = JSONObject().put("fields", levelFields)
                    OutputStreamWriter(levelConn.outputStream, Charsets.UTF_8).use { writer ->
                        writer.write(levelBody.toString())
                        writer.flush()
                    }
                    levelConn.responseCode
                } finally {
                    levelConn.disconnect()
                }
            }
        }
    }

    private fun executeFirebaseRestPost(endpointUrl: String, body: JSONObject): JSONObject {
        val connection = (URL(endpointUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 4500
            readTimeout = 4500
            doInput = true
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        }
        try {
            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(body.toString())
                writer.flush()
            }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader ->
                    reader.readText()
                }
            } ?: "{}"
            val json = runCatching { JSONObject(responseText) }.getOrElse { JSONObject() }
            if (status in 200..299) {
                return json
            } else {
                val errMsg = json.optJSONObject("error")?.optString("message")
                    ?.takeIf { it.isNotBlank() }
                    ?: "HTTP_$status"
                throw FirebaseRestAuthException(errMsg)
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun isDefinitiveRestCredentialRejection(errorCode: String): Boolean {
        return errorCode.contains("INVALID_LOGIN_CREDENTIALS", ignoreCase = true) ||
            errorCode.contains("EMAIL_NOT_FOUND", ignoreCase = true) ||
            errorCode.contains("INVALID_PASSWORD", ignoreCase = true) ||
            errorCode.contains("USER_DISABLED", ignoreCase = true) ||
            errorCode.contains("TOO_MANY_ATTEMPTS_TRY_LATER", ignoreCase = true)
    }

    private fun isDefinitiveCredentialRejection(error: Exception): Boolean {
        val msg = error.message ?: ""
        return msg.contains("INVALID_LOGIN_CREDENTIALS", ignoreCase = true) ||
            msg.contains("wrong-password", ignoreCase = true) ||
            msg.contains("invalid-credential", ignoreCase = true) ||
            msg.contains("user-not-found", ignoreCase = true)
    }

    private fun deterministicUidForEmail(email: String): String {
        val normalized = email.trim().lowercase(Locale.US)
        val uuid = UUID.nameUUIDFromBytes("arrow_escape_3d:$normalized".toByteArray(Charsets.UTF_8))
        return "usr_${uuid.toString().replace("-", "").take(24)}"
    }

    private fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun saveLocalCredentialsRecord(
        uid: String,
        email: String,
        displayName: String,
        passwordHash: String
    ) {
        val prefs = sessionPrefs ?: return
        val normalizedEmail = email.trim().lowercase(Locale.US)
        prefs.edit()
            .putString("acct_uid_$normalizedEmail", uid)
            .putString("acct_name_$normalizedEmail", displayName)
            .putString("acct_hash_$normalizedEmail", passwordHash)
            .apply()
    }

    private suspend fun registerFallbackAccount(
        name: String,
        email: String,
        password: String
    ): String? {
        val normalizedEmail = email.trim().lowercase(Locale.US)
        val existingLocalUid = sessionPrefs?.getString("acct_uid_$normalizedEmail", null)
        if (!existingLocalUid.isNullOrBlank()) {
            return null // Account already exists locally
        }

        val uid = deterministicUidForEmail(normalizedEmail)
        val passHash = sha256(password)

        // Check if document already exists in Firestore
        val db = firestore
        if (db != null) {
            val existingSnap = runCatching {
                withTimeout(4_000L) {
                    db.collection("users").document(uid).get().awaitResult()
                }
            }.getOrNull()
            if (existingSnap != null && existingSnap.exists()) {
                val storedHash = existingSnap.getString("authVerifier")
                if (!storedHash.isNullOrBlank()) {
                    return null // Already registered
                }
            }
        }

        saveLocalCredentialsRecord(uid, normalizedEmail, name, passHash)
        return uid
    }

    private suspend fun verifyFallbackAccountLogin(
        email: String,
        password: String
    ): Pair<String, String>? {
        val normalizedEmail = email.trim().lowercase(Locale.US)
        val passHash = sha256(password)

        // 1. Check local registered credentials
        val localHash = sessionPrefs?.getString("acct_hash_$normalizedEmail", null)
        val localUid = sessionPrefs?.getString("acct_uid_$normalizedEmail", null)
        val localName = sessionPrefs?.getString("acct_name_$normalizedEmail", null)
        if (!localUid.isNullOrBlank() && !localHash.isNullOrBlank()) {
            return if (localHash == passHash) {
                localUid to (localName ?: normalizedEmail.substringBefore("@"))
            } else {
                null
            }
        }

        // 2. Check Firestore document by deterministic UID
        val uid = deterministicUidForEmail(normalizedEmail)
        val db = firestore
        if (db != null) {
            val docSnap = runCatching {
                withTimeout(4_000L) {
                    db.collection("users").document(uid).get().awaitResult()
                }
            }.getOrNull()

            if (docSnap != null && docSnap.exists()) {
                val docName = docSnap.getString("displayName")
                    ?.takeIf { it.isNotBlank() }
                    ?: normalizedEmail.substringBefore("@")
                saveLocalCredentialsRecord(uid, normalizedEmail, docName, passHash)
                return uid to docName
            }
        }

        return null
    }

    private fun setUnauthenticatedError(message: String, mode: AuthScreenMode) {
        _authState.value = AuthUiState.Unauthenticated(
            mode = mode,
            isLoading = false,
            errorMessage = message,
            infoMessage = null
        )
    }

    private suspend fun signInWithCredentialManager(
        activity: Activity,
        auth: FirebaseAuth,
        webClientId: String
    ): AuthResult {
        val credentialManager = CredentialManager.create(activity)
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(webClientId)
            .setAutoSelectEnabled(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        val response = credentialManager.getCredential(activity, request)
        val credential = response.credential
        if (credential is CustomCredential &&
            credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
            val firebaseCredential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)
            return auth.signInWithCredential(firebaseCredential).awaitResult()
        } else {
            throw IllegalStateException("Unsupported Google credential type")
        }
    }

    /**
     * Called upon explicit user login / signup so that the user's existing Firestore profile
     * (`coins`, `completedLevels`, `rewardedLevelIds`, `displayName`, `email`) is restored
     * BEFORE opening the User Main/Game screen.
     */
    private suspend fun establishAuthenticatedSessionAndLoadProfile(
        uid: String,
        displayName: String,
        email: String
    ) {
        if (uid.isBlank()) return
        val cleanName = displayName.trim().ifBlank {
            email.substringBefore("@").ifBlank { "Player" }
        }
        val cleanEmail = email.trim()
        val nowMillis = System.currentTimeMillis()
        val createdMillis = sessionPrefs?.getLong("${KEY_CREATED_MILLIS}_$uid", 0L)
            ?.takeIf { it > 0L } ?: nowMillis

        sessionPrefs?.edit()
            ?.putString(KEY_UID, uid)
            ?.putString(KEY_EMAIL, cleanEmail)
            ?.putString(KEY_NAME, cleanName)
            ?.putLong("${KEY_CREATED_MILLIS}_$uid", createdMillis)
            ?.apply()

        val restoredProfile = if (!isLocalUnitTest) {
            withContext(Dispatchers.IO) {
                ensureFirestoreUserProfile(
                    uid = uid,
                    displayName = cleanName,
                    email = cleanEmail
                )
            } ?: loadLocalProfileSnapshot(uid, cleanName, cleanEmail, createdMillis)
        } else {
            loadLocalProfileSnapshot(uid, cleanName, cleanEmail, createdMillis)
        }

        saveLocalProfileSnapshot(restoredProfile)
        onAuthenticatedSessionEstablished(
            uid = uid,
            displayName = restoredProfile.displayName.ifBlank { cleanName },
            email = restoredProfile.email.ifBlank { cleanEmail },
            preloadedProfile = restoredProfile
        )
    }

    private fun onAuthenticatedSessionEstablished(
        uid: String,
        displayName: String,
        email: String,
        preloadedProfile: FirestoreUserProfile? = null
    ) {
        if (uid.isBlank()) return

        val cleanName = displayName.trim().ifBlank {
            email.substringBefore("@").ifBlank { "Player" }
        }
        val cleanEmail = email.trim()
        val isAdmin = isEmailAdmin(cleanEmail)
        val nowMillis = System.currentTimeMillis()

        // Persist session so closing and reopening the app keeps the user logged in
        val createdMillis = sessionPrefs?.getLong("${KEY_CREATED_MILLIS}_$uid", 0L)
            ?.takeIf { it > 0L } ?: nowMillis
        sessionPrefs?.edit()
            ?.putString(KEY_UID, uid)
            ?.putString(KEY_EMAIL, cleanEmail)
            ?.putString(KEY_NAME, cleanName)
            ?.putLong("${KEY_CREATED_MILLIS}_$uid", createdMillis)
            ?.apply()

        val initialProfile = preloadedProfile
            ?: loadLocalProfileSnapshot(uid, cleanName, cleanEmail, createdMillis)
        if (preloadedProfile != null || initialProfile.coins > 0L || initialProfile.completedLevels > 0L) {
            saveLocalProfileSnapshot(initialProfile)
        }

        if (isAdmin) {
            val cachedUsers = loadCachedUsersListForAdmin(initialProfile)
            _authState.update { prev ->
                val existingAdmin = prev as? AuthUiState.AuthenticatedAdmin
                val bestProfile = chooseMostCompleteProfile(existingAdmin?.profile, initialProfile)
                AuthUiState.AuthenticatedAdmin(
                    uid = uid,
                    displayName = bestProfile.displayName.ifBlank { cleanName },
                    email = bestProfile.email.ifBlank { cleanEmail },
                    profile = bestProfile,
                    usersList = existingAdmin?.usersList?.ifEmpty { cachedUsers } ?: cachedUsers,
                    redemptionRequests = loadAllRedemptionRequestsForAdmin(),
                    isLoadingUsers = true,
                    adminErrorMessage = null,
                    isPlayingGame = existingAdmin?.isPlayingGame ?: false
                )
            }
        } else {
            // Normal user enters the Main User Experience directly with the game active
            _authState.update { prev ->
                val existingUser = prev as? AuthUiState.AuthenticatedUser
                val bestProfile = chooseMostCompleteProfile(existingUser?.profile, initialProfile)
                AuthUiState.AuthenticatedUser(
                    uid = uid,
                    displayName = bestProfile.displayName.ifBlank { cleanName },
                    email = bestProfile.email.ifBlank { cleanEmail },
                    profile = bestProfile,
                    redemptionHistory = loadUserRedemptionHistory(uid, cleanEmail),
                    isPlayingGame = true,
                    openGameToSettings = existingUser?.openGameToSettings ?: false,
                    lastRewardFeedback = existingUser?.lastRewardFeedback
                )
            }
        }

        scope.launch(Dispatchers.IO) {
            if (preloadedProfile == null) {
                val syncedProfile = ensureFirestoreUserProfile(
                    uid = uid,
                    displayName = cleanName,
                    email = cleanEmail
                )
                if (syncedProfile != null) {
                    saveLocalProfileSnapshot(syncedProfile)
                    updateCurrentProfileState(syncedProfile)
                }
            }
            startObservingAuthenticatedUserProfile(uid, cleanName, cleanEmail)
            if (isAdmin) {
                startObservingAllUsersForAdmin()
            }
        }
    }

    private fun chooseMostCompleteProfile(
        first: FirestoreUserProfile?,
        second: FirestoreUserProfile
    ): FirestoreUserProfile {
        if (first == null || first.userId != second.userId) return second
        val mergedRewarded = first.rewardedLevelIds + second.rewardedLevelIds
        val mergedCompleted = maxOf(first.completedLevels, second.completedLevels, mergedRewarded.size.toLong())
        val mergedCoins = maxOf(first.coins, second.coins)
        return second.copy(
            coins = mergedCoins,
            completedLevels = mergedCompleted,
            rewardedLevelIds = mergedRewarded
        )
    }

    private fun getLocalProfileCoins(uid: String, email: String = ""): Long {
        val prefs = sessionPrefs ?: return 0L
        val byUid = prefs.getLong("profile_coins_$uid", 0L)
        val normalizedEmail = email.trim().lowercase(Locale.US)
        if (!normalizedEmail.contains("@")) return byUid
        val byEmail = prefs.getLong("profile_coins_email_$normalizedEmail", 0L)
        val legacyUid = deterministicUidForEmail(normalizedEmail)
        val byLegacyUid = if (legacyUid != uid) prefs.getLong("profile_coins_$legacyUid", 0L) else 0L
        return maxOf(byUid, byEmail, byLegacyUid)
    }

    private fun getLocalProfileCompletedLevels(uid: String, email: String = ""): Long {
        val prefs = sessionPrefs ?: return 0L
        val byUid = prefs.getLong("profile_levels_$uid", 0L)
        val normalizedEmail = email.trim().lowercase(Locale.US)
        if (!normalizedEmail.contains("@")) return byUid
        val byEmail = prefs.getLong("profile_levels_email_$normalizedEmail", 0L)
        val legacyUid = deterministicUidForEmail(normalizedEmail)
        val byLegacyUid = if (legacyUid != uid) prefs.getLong("profile_levels_$legacyUid", 0L) else 0L
        return maxOf(byUid, byEmail, byLegacyUid)
    }

    private fun parseCsvLevels(csv: String?): Set<Int> {
        if (csv.isNullOrBlank()) return emptySet()
        return csv.split(",")
            .mapNotNull { it.trim().toIntOrNull()?.takeIf { lvl -> lvl > 0 } }
            .toSet()
    }

    private fun getLocalRewardedLevels(uid: String, email: String = ""): Set<Int> {
        val prefs = sessionPrefs ?: return emptySet()
        val result = mutableSetOf<Int>()
        prefs.getStringSet("profile_rewarded_levels_$uid", emptySet())
            ?.mapNotNull { it.toIntOrNull()?.takeIf { lvl -> lvl > 0 } }
            ?.let { result.addAll(it) }
        result.addAll(parseCsvLevels(prefs.getString("profile_rewarded_csv_$uid", null)))

        val normalizedEmail = email.trim().lowercase(Locale.US)
        if (normalizedEmail.contains("@")) {
            prefs.getStringSet("profile_rewarded_levels_email_$normalizedEmail", emptySet())
                ?.mapNotNull { it.toIntOrNull()?.takeIf { lvl -> lvl > 0 } }
                ?.let { result.addAll(it) }
            result.addAll(parseCsvLevels(prefs.getString("profile_rewarded_csv_email_$normalizedEmail", null)))

            val legacyUid = deterministicUidForEmail(normalizedEmail)
            if (legacyUid != uid) {
                prefs.getStringSet("profile_rewarded_levels_$legacyUid", emptySet())
                    ?.mapNotNull { it.toIntOrNull()?.takeIf { lvl -> lvl > 0 } }
                    ?.let { result.addAll(it) }
                result.addAll(parseCsvLevels(prefs.getString("profile_rewarded_csv_$legacyUid", null)))
            }
        }
        return result
    }

    private fun saveLocalProfileSnapshot(profile: FirestoreUserProfile) {
        val prefs = sessionPrefs ?: return
        val millis = profile.createdAtMillis ?: System.currentTimeMillis()
        val existingRegistry = prefs.getStringSet(KEY_ACCOUNTS_REGISTRY, emptySet())?.toMutableSet()
            ?: mutableSetOf()
        existingRegistry.add(profile.userId)

        val inferredRewarded = if (profile.completedLevels > 0L) {
            (1..profile.completedLevels.toInt().coerceAtMost(10_000)).toSet()
        } else {
            emptySet()
        }
        val mergedRewarded = getLocalRewardedLevels(profile.userId, profile.email) +
            profile.rewardedLevelIds +
            inferredRewarded
        val rewardedStrings = HashSet(mergedRewarded.map { it.toString() })
        val rewardedCsv = mergedRewarded.sorted().joinToString(",")
        val effectiveCompleted = maxOf(
            profile.completedLevels,
            mergedRewarded.size.toLong(),
            getLocalProfileCompletedLevels(profile.userId, profile.email)
        )
        val hasRedeemed = (prefs.getLong("profile_redeemed_coins_${profile.userId}", 0L) > 0L)
        val existingLocalCoins = getLocalProfileCoins(profile.userId, profile.email)
        val effectiveCoins = if (hasRedeemed) {
            profile.coins
        } else {
            maxOf(profile.coins, existingLocalCoins)
        }

        val editor = prefs.edit()
            .putString("profile_name_${profile.userId}", profile.displayName)
            .putString("profile_email_${profile.userId}", profile.email)
            .putLong("profile_coins_${profile.userId}", effectiveCoins)
            .putLong("profile_levels_${profile.userId}", effectiveCompleted)
            .putStringSet("profile_rewarded_levels_${profile.userId}", rewardedStrings)
            .putString("profile_rewarded_csv_${profile.userId}", rewardedCsv)
            .putLong("${KEY_CREATED_MILLIS}_${profile.userId}", millis)
            .putStringSet(KEY_ACCOUNTS_REGISTRY, HashSet(existingRegistry))

        val normalizedEmail = profile.email.trim().lowercase(Locale.US)
        if (normalizedEmail.contains("@")) {
            editor
                .putString("acct_uid_$normalizedEmail", profile.userId)
                .putString("acct_name_$normalizedEmail", profile.displayName)
                .putLong("profile_coins_email_$normalizedEmail", effectiveCoins)
                .putLong("profile_levels_email_$normalizedEmail", effectiveCompleted)
                .putStringSet("profile_rewarded_levels_email_$normalizedEmail", rewardedStrings)
                .putString("profile_rewarded_csv_email_$normalizedEmail", rewardedCsv)
        }

        editor.apply()
    }

    private fun loadLocalProfileSnapshot(
        uid: String,
        fallbackName: String,
        fallbackEmail: String,
        fallbackMillis: Long
    ): FirestoreUserProfile {
        val prefs = sessionPrefs
        val name = prefs?.getString("profile_name_$uid", null)?.takeIf { it.isNotBlank() } ?: fallbackName
        val email = prefs?.getString("profile_email_$uid", null)?.takeIf { it.isNotBlank() } ?: fallbackEmail
        val rawLevels = getLocalProfileCompletedLevels(uid, email)
        val inferredLevels = if (rawLevels > 0L) {
            (1..rawLevels.toInt().coerceAtMost(10_000)).toSet()
        } else {
            emptySet()
        }
        val rewarded = getLocalRewardedLevels(uid, email) + inferredLevels
        val coins = getLocalProfileCoins(uid, email)
        val levels = maxOf(rawLevels, rewarded.size.toLong())
        val millis = prefs?.getLong("${KEY_CREATED_MILLIS}_$uid", fallbackMillis) ?: fallbackMillis
        return FirestoreUserProfile(
            userId = uid,
            displayName = name,
            email = email,
            createdAtMillis = millis,
            createdAtFormatted = formatTimestampMillis(millis),
            coins = coins,
            completedLevels = levels,
            rewardedLevelIds = rewarded
        )
    }

    private fun loadCachedUsersListForAdmin(adminProfile: FirestoreUserProfile): List<FirestoreUserProfile> {
        val prefs = sessionPrefs ?: return listOf(adminProfile)
        val uids = prefs.getStringSet(KEY_ACCOUNTS_REGISTRY, emptySet()).orEmpty()
        val map = LinkedHashMap<String, FirestoreUserProfile>()
        map[adminProfile.userId] = adminProfile
        for (id in uids) {
            val profile = loadLocalProfileSnapshot(
                uid = id,
                fallbackName = "Player",
                fallbackEmail = "",
                fallbackMillis = System.currentTimeMillis()
            )
            map[id] = profile
        }
        return map.values.sortedByDescending { it.createdAtMillis ?: 0L }
    }

    private fun updateCurrentProfileState(
        profile: FirestoreUserProfile,
        rewardFeedback: String? = null
    ) {
        _authState.update { current ->
            when (current) {
                is AuthUiState.AuthenticatedUser -> current.copy(
                    displayName = profile.displayName,
                    email = profile.email,
                    profile = profile,
                    redemptionHistory = loadUserRedemptionHistory(profile.userId, profile.email),
                    lastRewardFeedback = rewardFeedback ?: current.lastRewardFeedback
                )
                is AuthUiState.AuthenticatedAdmin -> current.copy(
                    displayName = profile.displayName,
                    email = profile.email,
                    profile = profile,
                    redemptionRequests = loadAllRedemptionRequestsForAdmin(),
                    lastRewardFeedback = rewardFeedback ?: current.lastRewardFeedback
                )
                else -> current
            }
        }
    }

    /**
     * Opens the existing Arrow Escape 3D game.
     */
    fun openGame(openToSettings: Boolean = false) {
        _authState.update { current ->
            when (current) {
                is AuthUiState.AuthenticatedUser -> current.copy(
                    isPlayingGame = true,
                    openGameToSettings = openToSettings
                )
                is AuthUiState.AuthenticatedAdmin -> current.copy(
                    isPlayingGame = true
                )
                else -> current
            }
        }
    }

    /**
     * Returns from the game preview to the Admin Panel (or keeps normal user in Main User Screen).
     */
    fun returnToAccountPanel() {
        _authState.update { current ->
            when (current) {
                is AuthUiState.AuthenticatedUser -> current.copy(
                    openGameToSettings = false
                )
                is AuthUiState.AuthenticatedAdmin -> current.copy(
                    isPlayingGame = false
                )
                else -> current
            }
        }
    }

    /**
     * Ensures `users/{firebaseUser.uid}` exists in Cloud Firestore with fields:
     * - userId
     * - displayName
     * - email
     * - createdAt
     * - coins
     * - completedLevels
     * - rewardedLevelIds
     *
     * CRITICAL: If the document already exists, NEVER resets `coins` or `completedLevels`.
     * Only populates missing fields when necessary.
     */
    suspend fun ensureFirestoreUserProfile(
        uid: String,
        displayName: String,
        email: String
    ): FirestoreUserProfile? {
        val safeUid = uid.takeIf { it.isNotBlank() }
            ?: runCatching { firebaseAuth?.currentUser?.uid }.getOrNull()
            ?: return null
        if (safeUid.isBlank()) return null

        val localSnapshot = loadLocalProfileSnapshot(safeUid, displayName, email, System.currentTimeMillis())

        // 1. First check Firestore via REST API GET (works whenever REST idToken is present, even if native FirebaseAuth is null)
        var restLookup = fetchProfileViaFirestoreRestApi(safeUid, displayName, email)
        if (restLookup is RestProfileLookupResult.NotFound && email.contains("@")) {
            val legacyUid = deterministicUidForEmail(email)
            if (legacyUid != safeUid) {
                val legacyLookup = fetchProfileViaFirestoreRestApi(legacyUid, displayName, email)
                if (legacyLookup is RestProfileLookupResult.Found) {
                    restLookup = RestProfileLookupResult.Found(legacyLookup.profile.copy(userId = safeUid))
                }
            }
        }

        // 2. Also check Native FirebaseFirestore SDK if native FirebaseAuth is authenticated for this UID
        val db = firestore
        val hasMatchingNativeAuth = runCatching { firebaseAuth?.currentUser?.uid == safeUid }.getOrDefault(false)
        var nativeSnapshot: DocumentSnapshot? = null
        var nativeDocExists = false
        var nativeLookupSucceeded = false
        if (db != null && hasMatchingNativeAuth) {
            val userDocRef = db.collection("users").document(safeUid)
            runCatching {
                withTimeout(3_500L) {
                    val snap = userDocRef.get().awaitResult()
                    nativeSnapshot = snap
                    nativeDocExists = snap.exists()
                    nativeLookupSucceeded = true
                }
            }
        }

        val remoteFromRest = (restLookup as? RestProfileLookupResult.Found)?.profile
        val remoteFromNative = if (nativeDocExists && nativeSnapshot != null) {
            snapshotToProfile(nativeSnapshot!!, safeUid, displayName, email)
        } else {
            null
        }

        val existingRemoteProfile = when {
            remoteFromRest != null && remoteFromNative != null ->
                chooseMostCompleteProfile(remoteFromRest, remoteFromNative)
            remoteFromRest != null -> remoteFromRest
            remoteFromNative != null -> remoteFromNative
            else -> null
        }

        if (existingRemoteProfile != null) {
            // Existing user document found in Firestore: NEVER reset coins, completedLevels, or rewardedLevelIds!
            val inferredRemoteRewarded = if (existingRemoteProfile.completedLevels > 0L) {
                (1..existingRemoteProfile.completedLevels.toInt().coerceAtMost(10_000)).toSet()
            } else {
                emptySet()
            }
            val mergedRewarded = existingRemoteProfile.rewardedLevelIds +
                inferredRemoteRewarded +
                localSnapshot.rewardedLevelIds
            val mergedCompleted = maxOf(
                existingRemoteProfile.completedLevels,
                localSnapshot.completedLevels,
                mergedRewarded.size.toLong()
            )
            val hasRedeemedLocally = (sessionPrefs?.getLong("profile_redeemed_coins_$safeUid", 0L) ?: 0L) > 0L
            val mergedCoins = if (hasRedeemedLocally && localSnapshot.coins > 0L) {
                minOf(existingRemoteProfile.coins, localSnapshot.coins)
            } else {
                // Firestore wins if local state has 0 coins while Firestore has > 0 coins!
                maxOf(existingRemoteProfile.coins, localSnapshot.coins)
            }

            val restoredProfile = existingRemoteProfile.copy(
                userId = safeUid,
                displayName = existingRemoteProfile.displayName.ifBlank { displayName },
                email = existingRemoteProfile.email.ifBlank { email },
                coins = mergedCoins,
                completedLevels = mergedCompleted,
                rewardedLevelIds = mergedRewarded
            )

            saveLocalProfileSnapshot(restoredProfile)

            // Only push to Firestore if local progress had higher values than remote
            if (mergedCoins > existingRemoteProfile.coins ||
                mergedCompleted > existingRemoteProfile.completedLevels ||
                mergedRewarded.size > existingRemoteProfile.rewardedLevelIds.size
            ) {
                if (db != null) {
                    runCatching {
                        withTimeout(3_000L) {
                            db.collection("users").document(safeUid).set(
                                mapOf(
                                    "userId" to safeUid,
                                    "displayName" to restoredProfile.displayName,
                                    "email" to restoredProfile.email,
                                    "coins" to restoredProfile.coins,
                                    "completedLevels" to restoredProfile.completedLevels,
                                    "rewardedLevelIds" to restoredProfile.rewardedLevelIds.sorted()
                                ),
                                SetOptions.merge()
                            ).awaitResult()
                        }
                    }
                }
                syncProfileViaFirestoreRestApi(restoredProfile)
            }

            return restoredProfile
        }

        // Document was NOT found: check if it genuinely does not exist (404 NotFound or native !exists())
        val confirmedNewDocument = (restLookup is RestProfileLookupResult.NotFound) ||
            (nativeLookupSucceeded && !nativeDocExists)

        if (confirmedNewDocument) {
            if (db != null) {
                runCatching {
                    withTimeout(3_000L) {
                        val initialData = hashMapOf<String, Any>(
                            "userId" to safeUid,
                            "displayName" to displayName,
                            "email" to email,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "coins" to localSnapshot.coins,
                            "completedLevels" to localSnapshot.completedLevels,
                            "rewardedLevelIds" to localSnapshot.rewardedLevelIds.sorted()
                        )
                        db.collection("users").document(safeUid).set(initialData, SetOptions.merge()).awaitResult()
                    }
                }
            }
            syncProfileViaFirestoreRestApi(localSnapshot)
            saveLocalProfileSnapshot(localSnapshot)
            return localSnapshot
        }

        // If both lookups failed due to network error (not 404), only sync to Firestore if local has positive progress
        if (localSnapshot.coins > 0L || localSnapshot.completedLevels > 0L) {
            syncProfileViaFirestoreRestApi(localSnapshot)
        }
        return localSnapshot
    }

    private fun startObservingAuthenticatedUserProfile(
        uid: String,
        fallbackName: String,
        fallbackEmail: String
    ) {
        val db = firestore ?: return
        runCatching { profileListener?.remove() }
        runCatching {
            profileListener = db.collection("users").document(uid)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener

                    val firestoreProfile = snapshotToProfile(
                        snapshot = snapshot,
                        fallbackUid = uid,
                        fallbackName = fallbackName,
                        fallbackEmail = fallbackEmail
                    )
                    val localRewarded = getLocalRewardedLevels(uid, fallbackEmail)
                    val localCoins = getLocalProfileCoins(uid, fallbackEmail)
                    val mergedRewarded = firestoreProfile.rewardedLevelIds + localRewarded
                    val mergedCoins = maxOf(firestoreProfile.coins, localCoins)
                    val mergedCompleted = maxOf(firestoreProfile.completedLevels, mergedRewarded.size.toLong())

                    val profile = firestoreProfile.copy(
                        coins = mergedCoins,
                        completedLevels = mergedCompleted,
                        rewardedLevelIds = mergedRewarded
                    )
                    saveLocalProfileSnapshot(profile)
                    updateCurrentProfileState(profile)
                }
        }
    }

    /**
     * Observes all user profiles in `users` collection ONLY if the currently authenticated
     * user is verified as [ADMIN_EMAIL].
     */
    private fun startObservingAllUsersForAdmin() {
        if (!isVerifiedCurrentUserAdmin()) return
        val db = firestore ?: return

        runCatching { adminUsersListener?.remove() }
        runCatching {
            adminUsersListener = db.collection("users")
                .addSnapshotListener { querySnapshot, error ->
                    if (!isVerifiedCurrentUserAdmin()) return@addSnapshotListener
                    if (error != null) {
                        _authState.update { state ->
                            if (state is AuthUiState.AuthenticatedAdmin) {
                                val fallbackList = loadCachedUsersListForAdmin(
                                    state.profile ?: FirestoreUserProfile(
                                        userId = state.uid,
                                        displayName = state.displayName,
                                        email = state.email
                                    )
                                )
                                state.copy(
                                    usersList = state.usersList.ifEmpty { fallbackList },
                                    isLoadingUsers = false,
                                    adminErrorMessage = null
                                )
                            } else {
                                state
                            }
                        }
                        return@addSnapshotListener
                    }

                    if (querySnapshot != null) {
                        val firestoreUsers = querySnapshot.documents.map { doc ->
                            val p = snapshotToProfile(
                                snapshot = doc,
                                fallbackUid = doc.id,
                                fallbackName = "Player",
                                fallbackEmail = ""
                            )
                            saveLocalProfileSnapshot(p)
                            p
                        }
                        val mergedMap = LinkedHashMap<String, FirestoreUserProfile>()
                        for (u in firestoreUsers) {
                            mergedMap[u.userId] = u
                        }
                        val currentState = _authState.value as? AuthUiState.AuthenticatedAdmin
                        val adminSelf = currentState?.profile
                        if (adminSelf != null) {
                            mergedMap.putIfAbsent(adminSelf.userId, adminSelf)
                            for (cached in loadCachedUsersListForAdmin(adminSelf)) {
                                mergedMap.putIfAbsent(cached.userId, cached)
                            }
                        }

                        val users = mergedMap.values.sortedByDescending { it.createdAtMillis ?: 0L }

                        _authState.update { state ->
                            if (state is AuthUiState.AuthenticatedAdmin) {
                                state.copy(
                                    usersList = users,
                                    isLoadingUsers = false,
                                    adminErrorMessage = null
                                )
                            } else {
                                state
                            }
                        }
                    }
                }
        }
    }

    /**
     * Manual refresh of all users for the Admin Panel.
     * Strictly gated by [isVerifiedCurrentUserAdmin].
     */
    fun refreshAdminUsersList() {
        if (!isVerifiedCurrentUserAdmin()) return
        val db = firestore ?: return

        _authState.update { state ->
            if (state is AuthUiState.AuthenticatedAdmin) {
                state.copy(isLoadingUsers = true, adminErrorMessage = null)
            } else {
                state
            }
        }

        scope.launch(Dispatchers.IO) {
            try {
                val querySnapshot = withTimeout(5_000L) {
                    db.collection("users").get().awaitResult()
                }
                if (!isVerifiedCurrentUserAdmin()) return@launch
                val firestoreUsers = querySnapshot.documents.map { doc ->
                    val p = snapshotToProfile(
                        snapshot = doc,
                        fallbackUid = doc.id,
                        fallbackName = "Player",
                        fallbackEmail = ""
                    )
                    saveLocalProfileSnapshot(p)
                    p
                }
                val mergedMap = LinkedHashMap<String, FirestoreUserProfile>()
                for (u in firestoreUsers) {
                    mergedMap[u.userId] = u
                }
                val currentState = _authState.value as? AuthUiState.AuthenticatedAdmin
                val adminSelf = currentState?.profile
                if (adminSelf != null) {
                    mergedMap.putIfAbsent(adminSelf.userId, adminSelf)
                    for (cached in loadCachedUsersListForAdmin(adminSelf)) {
                        mergedMap.putIfAbsent(cached.userId, cached)
                    }
                }

                val users = mergedMap.values.sortedByDescending { it.createdAtMillis ?: 0L }

                _authState.update { state ->
                    if (state is AuthUiState.AuthenticatedAdmin) {
                        state.copy(
                            usersList = users,
                            isLoadingUsers = false,
                            adminErrorMessage = null
                        )
                    } else {
                        state
                    }
                }
            } catch (_: Exception) {
                _authState.update { state ->
                    if (state is AuthUiState.AuthenticatedAdmin) {
                        val fallback = state.profile?.let { loadCachedUsersListForAdmin(it) }.orEmpty()
                        state.copy(
                            usersList = state.usersList.ifEmpty { fallback },
                            isLoadingUsers = false,
                            adminErrorMessage = null
                        )
                    } else {
                        state
                    }
                }
            }
        }
    }

    private fun stopListeners() {
        runCatching { profileListener?.remove() }
        runCatching { adminUsersListener?.remove() }
        profileListener = null
        adminUsersListener = null
    }

    override suspend fun refreshAuthenticatedProfile(): FirestoreUserProfile? {
        val uid = getVerifiedAuthenticatedUid() ?: return null
        val currentUser = runCatching { firebaseAuth?.currentUser }.getOrNull()
        val email = currentUser?.email ?: sessionPrefs?.getString(KEY_EMAIL, "") ?: ""
        val name = currentUser?.let { extractDisplayName(it) }
            ?: sessionPrefs?.getString(KEY_NAME, "Player")
            ?: "Player"

        return ensureFirestoreUserProfile(
            uid = uid,
            displayName = name,
            email = email
        )
    }

    fun signOut(context: Context? = null) {
        activeAuthJob?.cancel()
        activeAuthJob = null
        stopListeners()
        sessionPrefs?.edit()
            ?.remove(KEY_UID)
            ?.remove(KEY_EMAIL)
            ?.remove(KEY_NAME)
            ?.remove(KEY_ID_TOKEN)
            ?.remove(KEY_REFRESH_TOKEN)
            ?.apply()
        runCatching { firebaseAuth?.signOut() }
        _authState.value = AuthUiState.Unauthenticated(
            mode = AuthScreenMode.LOGIN,
            isLoading = false,
            errorMessage = null,
            infoMessage = null
        )
    }

    private fun extractRewardedLevels(snapshot: DocumentSnapshot): Set<Int> {
        val set = mutableSetOf<Int>()
        val candidateFields = listOf("rewardedLevelIds", "rewardedLevels", "completedLevelIds")
        for (field in candidateFields) {
            val raw = snapshot.get(field) as? Iterable<*> ?: continue
            for (item in raw) {
                when (item) {
                    is Number -> if (item.toInt() > 0) set.add(item.toInt())
                    is String -> item.toIntOrNull()?.takeIf { it > 0 }?.let { set.add(it) }
                }
            }
        }
        val rawCompleted = snapshot.get("completedLevels")
        if (rawCompleted is Iterable<*>) {
            for (item in rawCompleted) {
                when (item) {
                    is Number -> if (item.toInt() > 0) set.add(item.toInt())
                    is String -> item.toIntOrNull()?.takeIf { it > 0 }?.let { set.add(it) }
                }
            }
        }
        return set
    }

    private fun snapshotToProfile(
        snapshot: DocumentSnapshot,
        fallbackUid: String,
        fallbackName: String,
        fallbackEmail: String
    ): FirestoreUserProfile {
        val resolvedEmail = snapshot.getString("email")?.takeIf { it.isNotBlank() } ?: fallbackEmail
        val rawCompletedCount = snapshot.getLong("completedLevels") ?: 0L
        val inferredFromCount = if (rawCompletedCount > 0L) {
            (1..rawCompletedCount.toInt().coerceAtMost(10_000)).toSet()
        } else {
            emptySet()
        }
        val rewarded = extractRewardedLevels(snapshot) +
            getLocalRewardedLevels(fallbackUid, resolvedEmail) +
            inferredFromCount
        val localRedeemedCoins = sessionPrefs?.getLong("profile_redeemed_coins_$fallbackUid", 0L) ?: 0L
        val firestoreCoins = snapshot.getLong("coins") ?: 0L
        val localCoins = getLocalProfileCoins(fallbackUid, resolvedEmail)
        val coinsValue = if (localRedeemedCoins > 0L && localCoins > 0L) {
            minOf(firestoreCoins, localCoins)
        } else {
            maxOf(firestoreCoins, localCoins)
        }
        val completedLevelsValue = maxOf(
            rawCompletedCount,
            rewarded.size.toLong(),
            getLocalProfileCompletedLevels(fallbackUid, resolvedEmail)
        )
        val rawCreatedAt = snapshot.get("createdAt")
        val millis = extractMillis(rawCreatedAt)
            ?: sessionPrefs?.getLong("${KEY_CREATED_MILLIS}_$fallbackUid", 0L)?.takeIf { it > 0L }
            ?: System.currentTimeMillis()
        val formattedDate = formatTimestampMillis(millis)

        return FirestoreUserProfile(
            userId = snapshot.getString("userId")?.takeIf { it.isNotBlank() } ?: fallbackUid,
            displayName = snapshot.getString("displayName")?.takeIf { it.isNotBlank() } ?: fallbackName,
            email = resolvedEmail,
            createdAt = rawCreatedAt,
            createdAtMillis = millis,
            createdAtFormatted = formattedDate,
            coins = coinsValue,
            completedLevels = completedLevelsValue,
            rewardedLevelIds = rewarded
        )
    }

    private fun extractMillis(rawCreatedAt: Any?): Long? {
        return when (rawCreatedAt) {
            is Timestamp -> rawCreatedAt.toDate().time
            is Date -> rawCreatedAt.time
            is Long -> rawCreatedAt
            is Number -> rawCreatedAt.toLong()
            else -> null
        }
    }

    private fun formatTimestampMillis(millis: Long): String {
        return try {
            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US)
            sdf.format(Date(millis))
        } catch (_: Exception) {
            "Active Account"
        }
    }

    private fun extractDisplayName(user: FirebaseUser): String {
        val name = user.displayName?.trim()
        if (!name.isNullOrEmpty()) return name
        val emailPrefix = user.email?.substringBefore("@")?.trim()
        if (!emailPrefix.isNullOrEmpty()) return emailPrefix
        return "Player"
    }

    private fun findWebClientId(context: Context): String? {
        return runCatching {
            val resId = context.resources.getIdentifier(
                "default_web_client_id",
                "string",
                context.packageName
            )
            if (resId != 0) context.getString(resId).takeIf { it.isNotBlank() } else null
        }.getOrNull()
    }

    private fun friendlyAuthErrorMessage(error: Throwable): String {
        val msg = error.message ?: ""
        return when {
            msg.contains("INVALID_LOGIN_CREDENTIALS", ignoreCase = true) ||
                msg.contains("EMAIL_NOT_FOUND", ignoreCase = true) ||
                msg.contains("INVALID_PASSWORD", ignoreCase = true) ||
                msg.contains("wrong-password", ignoreCase = true) ||
                msg.contains("invalid-credential", ignoreCase = true) ||
                msg.contains("user-not-found", ignoreCase = true) ->
                "Invalid email or password. Please check your credentials or create an account."
            msg.contains("email-already-in-use", ignoreCase = true) ||
                msg.contains("EMAIL_EXISTS", ignoreCase = true) ->
                "An account with this email already exists. Please log in instead."
            msg.contains("weak-password", ignoreCase = true) ||
                msg.contains("WEAK_PASSWORD", ignoreCase = true) ->
                "Password is too weak. Please use at least 6 characters."
            msg.contains("invalid-email", ignoreCase = true) ||
                msg.contains("INVALID_EMAIL", ignoreCase = true) ->
                "Please enter a valid email address."
            msg.contains("canceled", ignoreCase = true) ||
                msg.contains("cancelled", ignoreCase = true) ->
                "Sign-in was cancelled."
            msg.contains("network", ignoreCase = true) ||
                msg.contains("Unable to resolve host", ignoreCase = true) ->
                "Network error. Please check your internet connection and try again."
            msg.contains("too-many-requests", ignoreCase = true) ||
                msg.contains("TOO_MANY_ATTEMPTS_TRY_LATER", ignoreCase = true) ->
                "Too many attempts. Please wait a moment and try again."
            else ->
                error.localizedMessage?.takeIf { it.isNotBlank() }
                    ?: "Authentication failed. Please try again."
        }
    }
}

private suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { result ->
        if (cont.isActive) cont.resume(result)
    }
    addOnFailureListener { e ->
        if (cont.isActive) cont.resumeWithException(e)
    }
    addOnCanceledListener {
        if (cont.isActive) cont.cancel()
    }
}
