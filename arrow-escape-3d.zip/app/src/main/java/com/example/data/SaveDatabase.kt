package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.model.GraphicsQuality
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

/**
 * Room Entity storing per-level completion, stars, and best score.
 */
@Entity(tableName = "level_progress")
data class LevelProgressEntity(
    @PrimaryKey val levelNumber: Int,
    val completed: Boolean = false,
    val stars: Int = 0, // 1..3
    val bestScore: Int = 0,
    val completedAtTimestamp: Long = System.currentTimeMillis()
)

/**
 * Room Entity storing the player's global profile, economy, lives, and settings.
 */
@Entity(tableName = "player_state")
data class PlayerStateEntity(
    @PrimaryKey val id: Int = 1,
    val currentLevel: Int = 1,
    val highestUnlockedLevel: Int = 1,
    val coins: Int = 100,
    val hints: Int = 3,
    val hearts: Int = 3,
    val lastHeartRestoreTimestamp: Long = System.currentTimeMillis(),
    val bestTotalScore: Int = 0,
    val soundEnabled: Boolean = true,
    val musicEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val graphicsQualityOrdinal: Int = GraphicsQuality.HIGH.ordinal,
    val gameSeed: Long = 2026L
)

@Dao
interface GameDao {
    @Query("SELECT * FROM player_state WHERE id = 1")
    fun observePlayerState(): Flow<PlayerStateEntity?>

    @Query("SELECT * FROM player_state WHERE id = 1")
    suspend fun getPlayerStateOnce(): PlayerStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlayerState(state: PlayerStateEntity)

    @Query("SELECT * FROM level_progress ORDER BY levelNumber ASC")
    fun observeAllLevelProgress(): Flow<List<LevelProgressEntity>>

    @Query("SELECT * FROM level_progress WHERE levelNumber = :levelNumber")
    suspend fun getLevelProgress(levelNumber: Int): LevelProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLevelProgress(progress: LevelProgressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAllLevelProgress(progressList: List<LevelProgressEntity>)

    @Query("DELETE FROM level_progress")
    suspend fun clearAllLevelProgress()
}

@Database(
    entities = [LevelProgressEntity::class, PlayerStateEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "arrow_escape_3d.db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

/**
 * Optional Cloud Sync abstraction so Firebase / Cloud Save can be plugged in seamlessly
 * while always retaining a local Room Database fallback.
 */
interface CloudSyncProvider {
    suspend fun syncPlayerState(state: PlayerStateEntity): Boolean
    suspend fun syncLevelProgress(progress: LevelProgressEntity): Boolean
}

/**
 * Default safe no-op cloud sync provider when cloud credentials are not active.
 */
class NoOpCloudSyncProvider : CloudSyncProvider {
    override suspend fun syncPlayerState(state: PlayerStateEntity): Boolean = false
    override suspend fun syncLevelProgress(progress: LevelProgressEntity): Boolean = false
}

/**
 * SaveManager handles persistent storage of player state and settings with error resilience.
 */
class SaveManager(
    private val gameDao: GameDao,
    private val cloudSyncProvider: CloudSyncProvider = NoOpCloudSyncProvider()
) {
    val playerStateFlow: Flow<PlayerStateEntity?> = gameDao.observePlayerState()
    val levelProgressFlow: Flow<List<LevelProgressEntity>> = gameDao.observeAllLevelProgress()

    suspend fun getOrCreatePlayerState(): PlayerStateEntity {
        return try {
            val existing = gameDao.getPlayerStateOnce()
            if (existing != null) {
                existing
            } else {
                val initial = PlayerStateEntity()
                gameDao.savePlayerState(initial)
                initial
            }
        } catch (e: Exception) {
            PlayerStateEntity()
        }
    }

    suspend fun updatePlayerState(transform: (PlayerStateEntity) -> PlayerStateEntity): PlayerStateEntity {
        return try {
            val current = getOrCreatePlayerState()
            val updated = transform(current)
            gameDao.savePlayerState(updated)
            runCatching { cloudSyncProvider.syncPlayerState(updated) }
            updated
        } catch (e: Exception) {
            PlayerStateEntity()
        }
    }

    suspend fun resetAllProgress(): PlayerStateEntity {
        return try {
            val current = getOrCreatePlayerState()
            gameDao.clearAllLevelProgress()
            val reset = PlayerStateEntity(
                id = 1,
                currentLevel = 1,
                highestUnlockedLevel = 1,
                coins = 100,
                hints = 3,
                hearts = 3,
                soundEnabled = current.soundEnabled,
                musicEnabled = current.musicEnabled,
                vibrationEnabled = current.vibrationEnabled,
                graphicsQualityOrdinal = current.graphicsQualityOrdinal,
                gameSeed = current.gameSeed
            )
            gameDao.savePlayerState(reset)
            reset
        } catch (e: Exception) {
            PlayerStateEntity()
        }
    }
}

/**
 * ProgressManager tracks level completion, star ratings, unlocking, and rewards.
 */
class ProgressManager(
    private val gameDao: GameDao,
    private val saveManager: SaveManager,
    private val cloudSyncProvider: CloudSyncProvider = NoOpCloudSyncProvider()
) {
    suspend fun recordLevelCompleted(
        levelNumber: Int,
        starsEarned: Int,
        scoreEarned: Int,
        coinsEarned: Int
    ): PlayerStateEntity {
        var alreadyCompleted = false
        try {
            val existing = gameDao.getLevelProgress(levelNumber)
            alreadyCompleted = existing?.completed == true
            val updatedProgress = LevelProgressEntity(
                levelNumber = levelNumber,
                completed = true,
                stars = maxOf(existing?.stars ?: 0, starsEarned.coerceIn(1, 3)),
                bestScore = maxOf(existing?.bestScore ?: 0, scoreEarned),
                completedAtTimestamp = System.currentTimeMillis()
            )
            gameDao.saveLevelProgress(updatedProgress)
            runCatching { cloudSyncProvider.syncLevelProgress(updatedProgress) }
        } catch (_: Exception) {
            // Ignore DB error, ensure gameplay continues smoothly
        }

        val effectiveCoinsEarned = if (alreadyCompleted) 0 else coinsEarned
        return saveManager.updatePlayerState { state ->
            val nextLevel = maxOf(state.currentLevel, levelNumber + 1)
            state.copy(
                currentLevel = nextLevel,
                highestUnlockedLevel = maxOf(state.highestUnlockedLevel, levelNumber + 1),
                coins = state.coins + effectiveCoinsEarned,
                bestTotalScore = state.bestTotalScore + scoreEarned
            )
        }
    }

    suspend fun syncFromAuthenticatedProfile(
        rewardedLevels: Set<Int>,
        authoritativeCoins: Int
    ) {
        try {
            val existingMap = getCompletedMap()
            if (existingMap.keys != rewardedLevels) {
                if (rewardedLevels.isEmpty()) {
                    gameDao.clearAllLevelProgress()
                } else {
                    val entities = rewardedLevels.map { lvl ->
                        val existing = existingMap[lvl]
                        LevelProgressEntity(
                            levelNumber = lvl,
                            completed = true,
                            stars = existing?.stars?.takeIf { it > 0 } ?: 3,
                            bestScore = existing?.bestScore?.takeIf { it > 0 } ?: 300
                        )
                    }
                    gameDao.clearAllLevelProgress()
                    gameDao.saveAllLevelProgress(entities)
                }
            }
            val highestCompleted = rewardedLevels.maxOrNull() ?: 0
            val nextPlayable = (highestCompleted + 1).coerceAtLeast(1)
            val currentPlayer = saveManager.getOrCreatePlayerState()
            if (currentPlayer.coins != authoritativeCoins ||
                currentPlayer.currentLevel != nextPlayable ||
                currentPlayer.highestUnlockedLevel != nextPlayable
            ) {
                saveManager.updatePlayerState { state ->
                    state.copy(
                        coins = authoritativeCoins,
                        currentLevel = nextPlayable,
                        highestUnlockedLevel = nextPlayable
                    )
                }
            }
        } catch (_: Exception) {
            // Ignore sync error
        }
    }

    suspend fun getCompletedMap(): Map<Int, LevelProgressEntity> {
        return try {
            val list = gameDao.observeAllLevelProgress().firstOrNull() ?: emptyList()
            list.associateBy { it.levelNumber }
        } catch (e: Exception) {
            emptyMap()
        }
    }
}
