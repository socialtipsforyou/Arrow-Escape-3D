package com.example.model

import kotlin.math.abs

/**
 * 3D cardinal directions on the puzzle board.
 */
enum class Direction3D(
    val dx: Int,
    val dy: Int,
    val dz: Int,
    val label: String,
    val symbol: String
) {
    UP(0, -1, 0, "Up", "↑"),
    DOWN(0, 1, 0, "Down", "↓"),
    LEFT(-1, 0, 0, "Left", "←"),
    RIGHT(1, 0, 0, "Right", "→");

    fun opposite(): Direction3D = when (this) {
        UP -> DOWN
        DOWN -> UP
        LEFT -> RIGHT
        RIGHT -> LEFT
    }

    companion object {
        fun fromDelta(dx: Int, dy: Int): Direction3D? = when {
            dx == 0 && dy < 0 -> UP
            dx == 0 && dy > 0 -> DOWN
            dx < 0 && dy == 0 -> LEFT
            dx > 0 && dy == 0 -> RIGHT
            else -> null
        }
    }
}

/**
 * Discrete 3D coordinate on the puzzle board.
 * x: column [0, gridWidth - 1]
 * y: row [0, gridHeight - 1]
 * z: elevation layer [0, layers - 1]
 */
data class GridPos3D(
    val x: Int,
    val y: Int,
    val z: Int = 0
) {
    fun step(dir: Direction3D, amount: Int = 1): GridPos3D =
        GridPos3D(x + dir.dx * amount, y + dir.dy * amount, z + dir.dz * amount)

    fun manhattanDistance(other: GridPos3D): Int =
        abs(x - other.x) + abs(y - other.y) + abs(z - other.z)
}

/**
 * Represents a 3D arrow block/path on the board.
 * [cells] are ordered from tail (cells.first()) to head (cells.last()).
 * A block can be a compact 1-2 cell 3D arrow block or a multi-segment bent 3D arrow path.
 */
data class ArrowBlock(
    val id: Int,
    val cells: List<GridPos3D>,
    val direction: Direction3D,
    val colorIndex: Int = 0
) {
    val head: GridPos3D
        get() = cells.last()

    val tail: GridPos3D
        get() = cells.first()

    val layer: Int
        get() = head.z
}

/**
 * Five distinct game modes / puzzle variations required by the specification.
 */
enum class GameMode(
    val title: String,
    val subtitle: String,
    val description: String
) {
    TAP_AWAY_ARROWS(
        title = "Tap Away Arrows",
        subtitle = "Classic 3D Escape",
        description = "Tap 3D arrow blocks whose forward path is completely clear to slide them off the board."
    ),
    FIND_FREE_PATH(
        title = "Find the Free Path",
        subtitle = "Intricate Mazes",
        description = "Larger shaped boards with interlocking bent arrow paths. Find the exact untangling sequence!"
    ),
    CLEAR_THE_BOARD(
        title = "Clear the Board",
        subtitle = "Dense Formations",
        description = "High-density 3D arrow formations across multiple directions and tight corridors."
    ),
    ROTATING_3D_BOARD(
        title = "Rotating 3D Boards",
        subtitle = "Multi-Layer 3D Depth",
        description = "Stacked 3D layers! Rotate the 3D camera to inspect upper and lower layers and clear top blocks first."
    ),
    SPECIAL_CHALLENGE(
        title = "Special Challenge",
        subtitle = "Time & Move Trials",
        description = "High-stakes challenge levels with countdown timers, strict move limits, or sudden-death hearts!"
    )
}

/**
 * Difficulty progression tiers matching level ranges:
 * 1-20: Easy, 21-50: Normal, 51-100: Hard, 101-200: Expert, 201+: Master
 */
enum class DifficultyTier(
    val displayName: String,
    val baseCoinReward: Int,
    val scoreMultiplier: Int
) {
    EASY("Easy", 25, 10),
    NORMAL("Normal", 45, 20),
    HARD("Hard", 75, 35),
    EXPERT("Expert", 110, 50),
    MASTER("Master", 160, 75);

    companion object {
        fun forLevel(levelNumber: Int): DifficultyTier = when {
            levelNumber <= 20 -> EASY
            levelNumber <= 50 -> NORMAL
            levelNumber <= 100 -> HARD
            levelNumber <= 200 -> EXPERT
            else -> MASTER
        }
    }
}

enum class GraphicsQuality(val label: String) {
    HIGH("High (3D Shadows + Particles)"),
    BALANCED("Balanced (Standard 3D)"),
    PERFORMANCE("Performance (Fast 60fps)")
}

/**
 * Complete procedural level configuration.
 */
data class LevelConfig(
    val levelNumber: Int,
    val seed: Long,
    val difficulty: DifficultyTier,
    val gameMode: GameMode,
    val shapeName: String,
    val gridWidth: Int,
    val gridHeight: Int,
    val layers: Int,
    val initialBlocks: List<ArrowBlock>,
    val solutionOrder: List<Int>,
    val timeLimitSeconds: Int? = null,
    val moveLimit: Int? = null,
    val maxHearts: Int = 3
)

/**
 * Result of checking if an ArrowBlock can move in its direction.
 */
sealed class PathCheckResult {
    data object Clear : PathCheckResult()
    data class BlockedByPath(
        val blockingBlockId: Int,
        val collisionCell: GridPos3D,
        val freeStepsBeforeCollision: Int
    ) : PathCheckResult()

    data class BlockedByUpperLayer(
        val blockingBlockId: Int,
        val collisionCell: GridPos3D
    ) : PathCheckResult()
}

/**
 * Active animation state for an arrow sliding/flying off the 3D board.
 */
data class FlyingArrowState(
    val block: ArrowBlock,
    val progress: Float, // 0f -> 1f
    val startTimeMs: Long
)

/**
 * Active animation state for a blocked arrow shaking/bumping into an obstacle.
 */
data class BlockedArrowState(
    val blockId: Int,
    val blockingBlockId: Int,
    val collisionCell: GridPos3D,
    val progress: Float, // 0f -> 1f
    val startTimeMs: Long
)

/**
 * 3D particle emitted when an arrow escapes or collides.
 */
data class Particle3D(
    val x: Float,
    val y: Float,
    val z: Float,
    val vx: Float,
    val vy: Float,
    val vz: Float,
    val colorIndex: Int,
    val isError: Boolean = false,
    val life: Float = 1f, // 1f -> 0f
    val size: Float = 6f
)

/**
 * Celebration confetti particle for Level Complete overlay.
 */
data class ConfettiParticle(
    val x: Float, // normalized 0..1
    val y: Float, // normalized 0..1
    val vx: Float,
    val vy: Float,
    val rotation: Float,
    val vRot: Float,
    val colorHex: Long,
    val sizeDp: Float
)

/**
 * Undo history record for a valid move.
 */
data class MoveRecord(
    val removedBlock: ArrowBlock,
    val scoreDelta: Int
)
