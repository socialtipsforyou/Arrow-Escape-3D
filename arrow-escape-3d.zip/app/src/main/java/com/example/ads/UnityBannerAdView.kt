package com.example.ads

import android.app.Activity
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize

/**
 * Safe, non-intrusive Banner Ad component for Unity Ads (BP_Banner_Android).
 *
 * Placed in its own dedicated bottom container with navigation bar safe padding,
 * so it strictly never overlaps the 3D game board, arrows, buttons, or input fields.
 *
 * Automatically waits for Unity Ads initialization to complete before loading the banner,
 * eliminating the initialization race condition.
 */
@Composable
fun UnityBannerAdView(
    modifier: Modifier = Modifier
) {
    if (UnityAdsManager.isLocalUnitTest) return

    val context = LocalContext.current
    val activity = context as? Activity ?: return

    val isInitialized by UnityAdsManager.isInitializedFlow.collectAsState()

    if (!isInitialized) return

    Box(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .background(Color(0xFF070F1E))
            .padding(vertical = 4.dp)
            .testTag("unity_banner_container"),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            modifier = Modifier
                .height(50.dp)
                .fillMaxWidth(),
            factory = { ctx ->
                FrameLayout(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    fun loadBanner(container: FrameLayout, placementId: String, isFallback: Boolean) {
                        try {
                            UnityAdsManager.logEvent("UnityAdsManager", "[BANNER] Initializing BannerView for $placementId (320x50)")
                            val banner = BannerView(activity, placementId, UnityBannerSize(320, 50))
                            banner.listener = object : BannerView.IListener {
                                override fun onBannerLoaded(bannerView: BannerView?) {
                                    UnityAdsManager.onBannerLoadedCallback(placementId)
                                }

                                override fun onBannerShown(bannerView: BannerView?) {
                                    UnityAdsManager.onBannerShownCallback(placementId)
                                }

                                override fun onBannerFailedToLoad(
                                    bannerView: BannerView?,
                                    errorInfo: BannerErrorInfo?
                                ) {
                                    val errMsg = errorInfo?.errorMessage
                                    UnityAdsManager.onBannerFailedCallback(placementId, errMsg)

                                    if (!isFallback && (errMsg?.contains("no fill", ignoreCase = true) == true ||
                                                        errMsg?.contains("adMarkup", ignoreCase = true) == true)) {
                                        UnityAdsManager.logEvent("UnityAdsManager", "[BANNER] Placement $placementId failed ($errMsg). Attempting waterfall banner fallback: ${UnityAdsManager.FALLBACK_BANNER}")
                                        container.post {
                                            try {
                                                container.removeAllViews()
                                                bannerView?.destroy()
                                                loadBanner(container, UnityAdsManager.FALLBACK_BANNER, isFallback = true)
                                            } catch (t: Throwable) {
                                                UnityAdsManager.onBannerFailedCallback(UnityAdsManager.FALLBACK_BANNER, t.message)
                                            }
                                        }
                                    }
                                }

                                override fun onBannerClick(bannerView: BannerView?) {
                                    UnityAdsManager.logEvent("UnityAdsManager", "[BANNER] Banner clicked")
                                }

                                override fun onBannerLeftApplication(bannerView: BannerView?) {
                                    UnityAdsManager.logEvent("UnityAdsManager", "[BANNER] Banner left application")
                                }
                            }
                            container.addView(banner)
                            UnityAdsManager.logEvent("UnityAdsManager", "[BANNER] Banner attached ($placementId). Requesting load...")
                            banner.load()
                            container.tag = banner
                        } catch (e: Throwable) {
                            UnityAdsManager.onBannerFailedCallback(placementId, e.message)
                        }
                    }

                    loadBanner(this, UnityAdsManager.PLACEMENT_BANNER, isFallback = false)
                }
            },
            onRelease = { container ->
                val banner = container.tag as? BannerView
                try {
                    banner?.destroy()
                } catch (_: Throwable) {}
                container.removeAllViews()
            }
        )
    }
}
