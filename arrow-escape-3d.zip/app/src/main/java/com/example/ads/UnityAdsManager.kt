package com.example.ads

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Authoritative Unity Ads Monetization & Diagnostic Manager for Arrow Escape 3D.
 *
 * Configuration:
 * - Game ID: 800387173
 * - Rewarded Placement ID: BP_Rewarded_Android
 * - Interstitial Placement ID: BP_Interstitial_Android
 * - Banner Placement ID: BP_Banner_Android
 * - Test Mode: true (preserved for development and runtime verification)
 */
object UnityAdsManager {
    private const val TAG = "UnityAdsManager"

    const val GAME_ID = "800387173"
    const val PLACEMENT_REWARDED = "BP_Rewarded_Android"
    const val PLACEMENT_INTERSTITIAL = "BP_Interstitial_Android"
    const val PLACEMENT_BANNER = "BP_Banner_Android"
    const val IS_TEST_MODE = true

    // Direct standalone waterfall placement fallbacks in case Unity Monetization Dashboard
    // configured BP_ placements as Header Bidding units requiring mediation adMarkup:
    const val FALLBACK_REWARDED = "Rewarded_Android"
    const val FALLBACK_INTERSTITIAL = "Interstitial_Android"
    const val FALLBACK_BANNER = "Banner_Android"

    var activeLoadedRewardedPlacement: String = PLACEMENT_REWARDED
        private set
    var activeLoadedInterstitialPlacement: String = PLACEMENT_INTERSTITIAL
        private set
    var activeLoadedBannerPlacement: String = PLACEMENT_BANNER
        private set

    // Interstitial cooldown: minimum 60 seconds during gameplay
    const val INTERSTITIAL_MIN_COOLDOWN_MS = 60_000L

    private val isInitializing = AtomicBoolean(false)
    private val isInitialized = AtomicBoolean(false)
    private val isAdCurrentlyDisplaying = AtomicBoolean(false)

    val isLocalUnitTest: Boolean = runCatching {
        android.os.Build.FINGERPRINT.equals("robolectric", ignoreCase = true)
    }.getOrDefault(false)

    // Flow states for Compose observation
    private val _isInitializedFlow = MutableStateFlow(false)
    val isInitializedFlow: StateFlow<Boolean> = _isInitializedFlow.asStateFlow()

    private val _initStatus = MutableStateFlow("NOT_INITIALIZED")
    val initStatus: StateFlow<String> = _initStatus.asStateFlow()

    private val _isRewardedLoaded = MutableStateFlow(false)
    val isRewardedLoaded: StateFlow<Boolean> = _isRewardedLoaded.asStateFlow()

    private val _isInterstitialLoaded = MutableStateFlow(false)
    val isInterstitialLoaded: StateFlow<Boolean> = _isInterstitialLoaded.asStateFlow()

    private val _isBannerLoaded = MutableStateFlow(false)
    val isBannerLoaded: StateFlow<Boolean> = _isBannerLoaded.asStateFlow()

    private val _lastAdError = MutableStateFlow("None")
    val lastAdError: StateFlow<String> = _lastAdError.asStateFlow()

    private val _lastAdEvent = MutableStateFlow("App Launched")
    val lastAdEvent: StateFlow<String> = _lastAdEvent.asStateFlow()

    private val _recentEvents = MutableStateFlow<List<String>>(emptyList())
    val recentEvents: StateFlow<List<String>> = _recentEvents.asStateFlow()

    private val _networkStatus = MutableStateFlow("Checking...")
    val networkStatus: StateFlow<String> = _networkStatus.asStateFlow()

    private var lastInterstitialTimeMs: Long = System.currentTimeMillis()
    private var appContext: Context? = null

    // Callback reference for the current active rewarded ad
    private var activeRewardedCallback: ((completionToken: String) -> Unit)? = null
    private var activeRewardedAdDismissed: (() -> Unit)? = null
    private var activeRewardClaimed: Boolean = false
    private var currentRewardedToken: String = ""

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun isAnyAdShowing(): Boolean = isAdCurrentlyDisplaying.get()

    fun getTestModeString(): String = if (IS_TEST_MODE) "ON" else "OFF"

    fun getRewardedStatusString(): String = if (_isRewardedLoaded.value) "LOADED" else "NOT LOADED"

    fun getInterstitialStatusString(): String = if (_isInterstitialLoaded.value) "LOADED" else "NOT LOADED"

    fun getBannerStatusString(): String = if (_isBannerLoaded.value) "LOADED" else "NOT LOADED"

    fun logEvent(tag: String, message: String) {
        val timestamp = timeFormat.format(Date())
        val fullMsg = "[$timestamp] $message"
        Log.i(tag, fullMsg)
        _lastAdEvent.value = fullMsg
        val currentList = _recentEvents.value.toMutableList()
        currentList.add(0, fullMsg)
        if (currentList.size > 25) {
            currentList.removeAt(currentList.lastIndex)
        }
        _recentEvents.value = currentList
    }

    fun logError(tag: String, errorMsg: String) {
        val timestamp = timeFormat.format(Date())
        val fullMsg = "[$timestamp] $errorMsg"
        Log.e(tag, fullMsg)
        _lastAdError.value = fullMsg
        logEvent(tag, "ERROR: $errorMsg")
    }

    fun isInterstitialEligible(): Boolean {
        val now = System.currentTimeMillis()
        val elapsed = now - lastInterstitialTimeMs
        return (elapsed >= INTERSTITIAL_MIN_COOLDOWN_MS) && !isAdCurrentlyDisplaying.get()
    }

    fun getCooldownRemainingSeconds(): Int {
        val now = System.currentTimeMillis()
        val elapsed = now - lastInterstitialTimeMs
        val remaining = (INTERSTITIAL_MIN_COOLDOWN_MS - elapsed) / 1000L
        return remaining.coerceAtLeast(0L).toInt()
    }

    fun checkNetworkConnectivity(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val network = cm?.activeNetwork
            val caps = cm?.getNetworkCapabilities(network)
            val hasInternet = caps != null && (
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            )
            val statusDesc = if (hasInternet) "CONNECTED (Online)" else "DISCONNECTED (No Internet)"
            _networkStatus.value = statusDesc
            hasInternet
        } catch (e: Throwable) {
            _networkStatus.value = "Unknown (${e.message})"
            true
        }
    }

    /**
     * Initializes the Unity Ads SDK once.
     */
    fun initialize(context: Context) {
        appContext = context.applicationContext
        checkNetworkConnectivity(context)

        // Check if Unity Ads SDK was already initialized
        if (runCatching { UnityAds.isInitialized }.getOrDefault(false)) {
            logEvent(TAG, "[INIT] UnityAds.isInitialized is already true. Marking ready & preloading.")
            isInitialized.set(true)
            isInitializing.set(false)
            _isInitializedFlow.value = true
            _initStatus.value = "READY"
            _lastAdError.value = "None"
            preloadRewardedAd()
            preloadInterstitialAd()
            return
        }

        if (isInitialized.get()) {
            logEvent(TAG, "[INIT] Already initialized successfully")
            return
        }
        if (isInitializing.getAndSet(true)) {
            logEvent(TAG, "[INIT] Initialization already in progress")
            return
        }

        if (isLocalUnitTest) {
            logEvent(TAG, "[INIT] Robolectric unit test detected. Mocking initialized state.")
            isInitialized.set(true)
            isInitializing.set(false)
            _isInitializedFlow.value = true
            _initStatus.value = "READY (Mock Unit Test)"
            _isRewardedLoaded.value = true
            _isInterstitialLoaded.value = true
            _isBannerLoaded.value = true
            return
        }

        _initStatus.value = "INITIALIZING..."
        val sdkVersion = "4.12.5"
        logEvent(TAG, "[INIT] Starting Unity Ads SDK init: Game ID=$GAME_ID, testMode=$IS_TEST_MODE, SDK Version=$sdkVersion")

        try {
            UnityAds.initialize(
                context.applicationContext,
                GAME_ID,
                IS_TEST_MODE,
                object : IUnityAdsInitializationListener {
                    override fun onInitializationComplete() {
                        logEvent(TAG, "[INIT] SUCCESS: Unity Ads initialized. Preloading ads...")
                        isInitialized.set(true)
                        isInitializing.set(false)
                        _isInitializedFlow.value = true
                        _initStatus.value = "READY"
                        _lastAdError.value = "None"
                        preloadRewardedAd()
                        preloadInterstitialAd()
                    }

                    override fun onInitializationFailed(
                        error: UnityAds.UnityAdsInitializationError?,
                        message: String?
                    ) {
                        val errMsg = "Initialization failed: error=$error, message=$message"
                        logError(TAG, "[INIT] $errMsg")
                        isInitialized.set(false)
                        isInitializing.set(false)
                        _isInitializedFlow.value = false
                        _initStatus.value = "FAILED: $error ($message)"
                    }
                }
            )
        } catch (e: Throwable) {
            val errMsg = "Exception during initialize: ${e.message}"
            logError(TAG, "[INIT] $errMsg")
            isInitializing.set(false)
            _initStatus.value = "FAILED: ${e.javaClass.simpleName}"
        }
    }

    /**
     * Preloads the rewarded ad placement.
     * Attempts the primary configured placement (BP_Rewarded_Android) first.
     * If the Unity Ads SDK reports INVALID_ARGUMENT (adMarkup is missing) because the placement was configured
     * as a Header Bidding unit requiring a mediation adapter, it automatically falls back to Rewarded_Android.
     */
    fun preloadRewardedAd() {
        if (!isInitialized.get() || isLocalUnitTest) {
            logEvent(TAG, "[REWARDED] Preload skipped: initialized=${isInitialized.get()}, isTest=$isLocalUnitTest")
            return
        }
        logEvent(TAG, "[REWARDED] Load requested for placement: $PLACEMENT_REWARDED")
        try {
            UnityAds.load(
                PLACEMENT_REWARDED,
                object : IUnityAdsLoadListener {
                    override fun onUnityAdsAdLoaded(placementId: String?) {
                        logEvent(TAG, "[REWARDED] Load SUCCESS: placementId=$placementId")
                        activeLoadedRewardedPlacement = placementId ?: PLACEMENT_REWARDED
                        _isRewardedLoaded.value = true
                    }

                    override fun onUnityAdsFailedToLoad(
                        placementId: String?,
                        error: UnityAds.UnityAdsLoadError?,
                        message: String?
                    ) {
                        val errMsg = "Rewarded load failed: placement=$placementId, error=$error, msg=$message"
                        logError(TAG, "[REWARDED] $errMsg")
                        _isRewardedLoaded.value = false

                        // If bidding placement failed because adMarkup is missing, fall back to standard waterfall
                        if (placementId == PLACEMENT_REWARDED &&
                            (message?.contains("adMarkup", ignoreCase = true) == true ||
                             error == UnityAds.UnityAdsLoadError.INVALID_ARGUMENT)
                        ) {
                            logEvent(TAG, "[REWARDED] Bidding placement requires mediation adMarkup. Attempting waterfall fallback placement: $FALLBACK_REWARDED")
                            loadWaterfallRewardedFallback()
                        }
                    }
                }
            )
        } catch (e: Throwable) {
            logError(TAG, "[REWARDED] Exception calling UnityAds.load: ${e.message}")
            _isRewardedLoaded.value = false
        }
    }

    private fun loadWaterfallRewardedFallback() {
        try {
            UnityAds.load(
                FALLBACK_REWARDED,
                object : IUnityAdsLoadListener {
                    override fun onUnityAdsAdLoaded(placementId: String?) {
                        logEvent(TAG, "[REWARDED] Waterfall fallback load SUCCESS: placementId=$placementId")
                        activeLoadedRewardedPlacement = placementId ?: FALLBACK_REWARDED
                        _isRewardedLoaded.value = true
                    }

                    override fun onUnityAdsFailedToLoad(
                        placementId: String?,
                        error: UnityAds.UnityAdsLoadError?,
                        message: String?
                    ) {
                        val errMsg = "Waterfall rewarded fallback failed: placement=$placementId, error=$error, msg=$message"
                        logError(TAG, "[REWARDED] $errMsg")
                        _isRewardedLoaded.value = false
                    }
                }
            )
        } catch (e: Throwable) {
            logError(TAG, "[REWARDED] Exception calling waterfall fallback load: ${e.message}")
            _isRewardedLoaded.value = false
        }
    }

    /**
     * Preloads the interstitial ad placement.
     * Attempts the primary configured placement (BP_Interstitial_Android) first.
     * If the Unity Ads SDK reports INVALID_ARGUMENT (adMarkup is missing), it automatically falls back to Interstitial_Android.
     */
    fun preloadInterstitialAd() {
        if (!isInitialized.get() || isLocalUnitTest) {
            logEvent(TAG, "[INTERSTITIAL] Preload skipped: initialized=${isInitialized.get()}, isTest=$isLocalUnitTest")
            return
        }
        logEvent(TAG, "[INTERSTITIAL] Load requested for placement: $PLACEMENT_INTERSTITIAL")
        try {
            UnityAds.load(
                PLACEMENT_INTERSTITIAL,
                object : IUnityAdsLoadListener {
                    override fun onUnityAdsAdLoaded(placementId: String?) {
                        logEvent(TAG, "[INTERSTITIAL] Load SUCCESS: placementId=$placementId")
                        activeLoadedInterstitialPlacement = placementId ?: PLACEMENT_INTERSTITIAL
                        _isInterstitialLoaded.value = true
                    }

                    override fun onUnityAdsFailedToLoad(
                        placementId: String?,
                        error: UnityAds.UnityAdsLoadError?,
                        message: String?
                    ) {
                        val errMsg = "Interstitial load failed: placement=$placementId, error=$error, msg=$message"
                        logError(TAG, "[INTERSTITIAL] $errMsg")
                        _isInterstitialLoaded.value = false

                        // If bidding placement failed because adMarkup is missing, fall back to standard waterfall
                        if (placementId == PLACEMENT_INTERSTITIAL &&
                            (message?.contains("adMarkup", ignoreCase = true) == true ||
                             error == UnityAds.UnityAdsLoadError.INVALID_ARGUMENT)
                        ) {
                            logEvent(TAG, "[INTERSTITIAL] Bidding placement requires mediation adMarkup. Attempting waterfall fallback placement: $FALLBACK_INTERSTITIAL")
                            loadWaterfallInterstitialFallback()
                        }
                    }
                }
            )
        } catch (e: Throwable) {
            logError(TAG, "[INTERSTITIAL] Exception calling UnityAds.load: ${e.message}")
            _isInterstitialLoaded.value = false
        }
    }

    private fun loadWaterfallInterstitialFallback() {
        try {
            UnityAds.load(
                FALLBACK_INTERSTITIAL,
                object : IUnityAdsLoadListener {
                    override fun onUnityAdsAdLoaded(placementId: String?) {
                        logEvent(TAG, "[INTERSTITIAL] Waterfall fallback load SUCCESS: placementId=$placementId")
                        activeLoadedInterstitialPlacement = placementId ?: FALLBACK_INTERSTITIAL
                        _isInterstitialLoaded.value = true
                    }

                    override fun onUnityAdsFailedToLoad(
                        placementId: String?,
                        error: UnityAds.UnityAdsLoadError?,
                        message: String?
                    ) {
                        val errMsg = "Waterfall interstitial fallback failed: placement=$placementId, error=$error, msg=$message"
                        logError(TAG, "[INTERSTITIAL] $errMsg")
                        _isInterstitialLoaded.value = false
                    }
                }
            )
        } catch (e: Throwable) {
            logError(TAG, "[INTERSTITIAL] Exception calling waterfall fallback load: ${e.message}")
            _isInterstitialLoaded.value = false
        }
    }

    /**
     * Shows the rewarded video ad.
     *
     * Rules enforced:
     * - Only awards +10 coins on official COMPLETED callback.
     * - Does NOT award on load, start, skip, cancel, close without finish, or failure.
     * - Prevents duplicate rewards via single-use token and boolean flag.
     * - If ad is not preloaded, attempts an immediate load and show or notifies gracefully.
     * - Gameplay continues normally if ad fails.
     */
    fun showRewardedAd(
        activity: Activity,
        onRewardGranted: (completionToken: String) -> Unit,
        onAdClosed: () -> Unit = {}
    ) {
        logEvent(TAG, "[REWARDED] Show requested by user: isLoaded=${_isRewardedLoaded.value}, isShowing=${isAdCurrentlyDisplaying.get()}")

        if (isLocalUnitTest) {
            logEvent(TAG, "[REWARDED] Mock Unit Test: Granting reward and closing.")
            onRewardGranted(UUID.randomUUID().toString())
            onAdClosed()
            return
        }

        if (isAdCurrentlyDisplaying.getAndSet(true)) {
            val msg = "Cannot show rewarded ad: another ad is already displaying."
            logError(TAG, "[REWARDED] $msg")
            onAdClosed()
            return
        }

        val token = UUID.randomUUID().toString()
        currentRewardedToken = token
        activeRewardClaimed = false
        activeRewardedCallback = onRewardGranted
        activeRewardedAdDismissed = onAdClosed

        // If ad is not loaded but initialized, attempt immediate load before showing
        if (!_isRewardedLoaded.value) {
            logEvent(TAG, "[REWARDED] Ad not loaded yet. Attempting on-demand load and show for $PLACEMENT_REWARDED...")
            try {
                UnityAds.load(
                    PLACEMENT_REWARDED,
                    object : IUnityAdsLoadListener {
                        override fun onUnityAdsAdLoaded(placementId: String?) {
                            logEvent(TAG, "[REWARDED] On-demand load SUCCESS: $placementId. Now showing...")
                            _isRewardedLoaded.value = true
                            executeShowRewarded(activity)
                        }

                        override fun onUnityAdsFailedToLoad(
                            placementId: String?,
                            error: UnityAds.UnityAdsLoadError?,
                            message: String?
                        ) {
                            val errMsg = "On-demand rewarded load failed: $error - $message"
                            logError(TAG, "[REWARDED] $errMsg")
                            isAdCurrentlyDisplaying.set(false)
                            activeRewardedCallback = null
                            activeRewardedAdDismissed?.invoke()
                            activeRewardedAdDismissed = null
                        }
                    }
                )
                return
            } catch (e: Throwable) {
                logError(TAG, "[REWARDED] On-demand load exception: ${e.message}")
                isAdCurrentlyDisplaying.set(false)
                activeRewardedCallback = null
                activeRewardedAdDismissed?.invoke()
                activeRewardedAdDismissed = null
                return
            }
        }

        executeShowRewarded(activity)
    }

    private fun executeShowRewarded(activity: Activity) {
        try {
            _isRewardedLoaded.value = false
            val placementToShow = activeLoadedRewardedPlacement
            logEvent(TAG, "[REWARDED] Executing UnityAds.show for $placementToShow")
            UnityAds.show(
                activity,
                placementToShow,
                UnityAdsShowOptions(),
                object : IUnityAdsShowListener {
                    override fun onUnityAdsShowFailure(
                        placementId: String?,
                        error: UnityAds.UnityAdsShowError?,
                        message: String?
                    ) {
                        val errMsg = "Rewarded show failure: placement=$placementId, error=$error, msg=$message"
                        logError(TAG, "[REWARDED] $errMsg")
                        isAdCurrentlyDisplaying.set(false)
                        activeRewardedCallback = null
                        activeRewardedAdDismissed?.invoke()
                        activeRewardedAdDismissed = null
                        preloadRewardedAd()
                    }

                    override fun onUnityAdsShowStart(placementId: String?) {
                        logEvent(TAG, "[REWARDED] Show STARTED for $placementId")
                    }

                    override fun onUnityAdsShowClick(placementId: String?) {
                        logEvent(TAG, "[REWARDED] Ad CLICKED for $placementId")
                    }

                    override fun onUnityAdsShowComplete(
                        placementId: String?,
                        state: UnityAds.UnityAdsShowCompletionState?
                    ) {
                        logEvent(TAG, "[REWARDED] Show COMPLETE for $placementId with state=$state")
                        isAdCurrentlyDisplaying.set(false)
                        if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
                            if (!activeRewardClaimed) {
                                activeRewardClaimed = true
                                logEvent(TAG, "[REWARDED] Reward EARNED: granting +10 Coins (Token: $currentRewardedToken)")
                                val callback = activeRewardedCallback
                                activeRewardedCallback = null
                                callback?.invoke(currentRewardedToken)
                            }
                        } else {
                            logEvent(TAG, "[REWARDED] Ad not completed (state=$state). No reward granted.")
                            activeRewardedCallback = null
                        }

                        activeRewardedAdDismissed?.invoke()
                        activeRewardedAdDismissed = null
                        preloadRewardedAd()
                    }
                }
            )
        } catch (e: Throwable) {
            val errMsg = "Exception during showRewarded: ${e.message}"
            logError(TAG, "[REWARDED] $errMsg")
            isAdCurrentlyDisplaying.set(false)
            activeRewardedCallback = null
            activeRewardedAdDismissed?.invoke()
            activeRewardedAdDismissed = null
            preloadRewardedAd()
        }
    }

    /**
     * Shows an interstitial ad if the minimum 60-second cooldown has elapsed,
     * no other ad is showing, and the interstitial is loaded.
     *
     * Resets the cooldown upon showing.
     */
    fun showInterstitialIfAppropriate(
        activity: Activity,
        onAdDismissed: () -> Unit = {}
    ) {
        if (isLocalUnitTest) {
            logEvent(TAG, "[INTERSTITIAL] Mock Unit Test: Dismissing.")
            onAdDismissed()
            return
        }
        val now = System.currentTimeMillis()
        val cooldownPassed = (now - lastInterstitialTimeMs) >= INTERSTITIAL_MIN_COOLDOWN_MS

        if (!cooldownPassed || isAdCurrentlyDisplaying.get() || !_isInterstitialLoaded.value) {
            val remainingSec = getCooldownRemainingSeconds()
            logEvent(TAG, "[INTERSTITIAL] Opportunity skipped: cooldownPassed=$cooldownPassed (${remainingSec}s left), adShowing=${isAdCurrentlyDisplaying.get()}, loaded=${_isInterstitialLoaded.value}")
            // If interstitial was not loaded, trigger preload so it is ready next time
            if (!_isInterstitialLoaded.value) {
                preloadInterstitialAd()
            }
            onAdDismissed()
            return
        }

        if (isAdCurrentlyDisplaying.getAndSet(true)) {
            logEvent(TAG, "[INTERSTITIAL] Skipping: another ad display is active.")
            onAdDismissed()
            return
        }

        try {
            _isInterstitialLoaded.value = false
            val placementToShow = activeLoadedInterstitialPlacement
            logEvent(TAG, "[INTERSTITIAL] Showing interstitial for $placementToShow")
            UnityAds.show(
                activity,
                placementToShow,
                UnityAdsShowOptions(),
                object : IUnityAdsShowListener {
                    override fun onUnityAdsShowFailure(
                        placementId: String?,
                        error: UnityAds.UnityAdsShowError?,
                        message: String?
                    ) {
                        val errMsg = "Interstitial show failure: placement=$placementId, error=$error, msg=$message"
                        logError(TAG, "[INTERSTITIAL] $errMsg")
                        lastInterstitialTimeMs = System.currentTimeMillis()
                        isAdCurrentlyDisplaying.set(false)
                        onAdDismissed()
                        preloadInterstitialAd()
                    }

                    override fun onUnityAdsShowStart(placementId: String?) {
                        logEvent(TAG, "[INTERSTITIAL] Show STARTED for $placementId")
                    }

                    override fun onUnityAdsShowClick(placementId: String?) {
                        logEvent(TAG, "[INTERSTITIAL] Ad CLICKED for $placementId")
                    }

                    override fun onUnityAdsShowComplete(
                        placementId: String?,
                        state: UnityAds.UnityAdsShowCompletionState?
                    ) {
                        logEvent(TAG, "[INTERSTITIAL] Show COMPLETE for $placementId, state=$state")
                        lastInterstitialTimeMs = System.currentTimeMillis()
                        isAdCurrentlyDisplaying.set(false)
                        onAdDismissed()
                        preloadInterstitialAd()
                    }
                }
            )
        } catch (e: Throwable) {
            val errMsg = "Exception during showInterstitial: ${e.message}"
            logError(TAG, "[INTERSTITIAL] $errMsg")
            lastInterstitialTimeMs = System.currentTimeMillis()
            isAdCurrentlyDisplaying.set(false)
            onAdDismissed()
            preloadInterstitialAd()
        }
    }

    /**
     * Updates the banner loaded state and logs event.
     */
    fun onBannerLoadedCallback(placementId: String?) {
        logEvent(TAG, "[BANNER] Banner loaded successfully for placement: $placementId")
        _isBannerLoaded.value = true
    }

    fun onBannerShownCallback(placementId: String?) {
        logEvent(TAG, "[BANNER] Banner shown on screen for placement: $placementId")
        _isBannerLoaded.value = true
    }

    fun onBannerFailedCallback(placementId: String?, errorMessage: String?) {
        val errMsg = "Banner failed to load: placement=$placementId, error=$errorMessage"
        logError(TAG, "[BANNER] $errMsg")
        _isBannerLoaded.value = false
    }

    /**
     * Creates and loads a BannerView for the safe non-intrusive container.
     */
    fun createBannerView(activity: Activity): BannerView? {
        if (!isInitialized.get() || isLocalUnitTest) {
            logEvent(TAG, "[BANNER] Creation skipped: initialized=${isInitialized.get()}")
            return null
        }
        return try {
            logEvent(TAG, "[BANNER] Creating BannerView for $PLACEMENT_BANNER (320x50)")
            val banner = BannerView(activity, PLACEMENT_BANNER, UnityBannerSize(320, 50))
            banner.listener = object : BannerView.IListener {
                override fun onBannerLoaded(bannerView: BannerView?) {
                    onBannerLoadedCallback(PLACEMENT_BANNER)
                }

                override fun onBannerShown(bannerView: BannerView?) {
                    onBannerShownCallback(PLACEMENT_BANNER)
                }

                override fun onBannerFailedToLoad(
                    bannerView: BannerView?,
                    errorInfo: BannerErrorInfo?
                ) {
                    onBannerFailedCallback(PLACEMENT_BANNER, errorInfo?.errorMessage)
                }

                override fun onBannerClick(bannerView: BannerView?) {
                    logEvent(TAG, "[BANNER] Banner clicked")
                }

                override fun onBannerLeftApplication(bannerView: BannerView?) {
                    logEvent(TAG, "[BANNER] Banner left application")
                }
            }
            banner.load()
            banner
        } catch (e: Throwable) {
            logError(TAG, "[BANNER] Exception creating BannerView: ${e.message}")
            _isBannerLoaded.value = false
            null
        }
    }
}
