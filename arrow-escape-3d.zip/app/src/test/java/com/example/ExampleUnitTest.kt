package com.example

import com.example.ads.UnityAdsManager
import com.example.data.FirebaseAuthProfileManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun `unity ads configuration complies with exact dashboard requirements`() {
        assertEquals("800387173", UnityAdsManager.GAME_ID)
        assertEquals("BP_Rewarded_Android", UnityAdsManager.PLACEMENT_REWARDED)
        assertEquals("BP_Interstitial_Android", UnityAdsManager.PLACEMENT_INTERSTITIAL)
        assertEquals("BP_Banner_Android", UnityAdsManager.PLACEMENT_BANNER)
        assertTrue("Test mode must remain strictly enabled during testing/development", UnityAdsManager.IS_TEST_MODE)
    }

    @Test
    fun `rewarded ad awards exactly 10 coins while level completion reward remains 20 coins`() {
        assertEquals(20L, FirebaseAuthProfileManager.COINS_PER_COMPLETED_LEVEL)
        assertEquals(10L, FirebaseAuthProfileManager.COINS_PER_REWARDED_AD)
    }
}
