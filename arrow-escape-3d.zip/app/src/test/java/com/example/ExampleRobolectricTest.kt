package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.ProgressManager
import com.example.data.SaveManager
import com.example.domain.AudioManager
import com.example.domain.BoardManager
import com.example.domain.GameManager
import com.example.domain.LevelGenerator
import com.example.domain.ScreenDestination
import com.example.model.ArrowBlock
import com.example.model.DifficultyTier
import com.example.model.Direction3D
import com.example.model.GameMode
import com.example.model.GridPos3D
import com.example.model.PathCheckResult
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    private lateinit var db: AppDatabase
    private lateinit var saveManager: SaveManager
    private lateinit var progressManager: ProgressManager
    private lateinit var gameManager: GameManager

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.gameDao()
        saveManager = SaveManager(dao)
        progressManager = ProgressManager(dao, saveManager)
        gameManager = GameManager(
            saveManager = saveManager,
            progressManager = progressManager,
            audioManager = AudioManager(null)
        )
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `procedural level generator creates deterministic and solvable levels across all tiers`() {
        val generator = LevelGenerator()
        val testLevels = (1..35).toList() + listOf(42, 50, 75, 100, 120, 239, 500)

        for (lvl in testLevels) {
            val configA = generator.generateLevel(lvl, gameSeed = 2026L)
            val configB = generator.generateLevel(lvl, gameSeed = 2026L)

            // Verify deterministic seed reproduction
            assertEquals(configA.seed, configB.seed)
            assertEquals(configA.initialBlocks, configB.initialBlocks)
            assertTrue(configA.initialBlocks.isNotEmpty())

            // Verify no two arrows ever touch, overlap, clip, or cross
            assertTrue(
                "Level $lvl arrows must have proper spacing and never touch or cross",
                generator.validateLevelArrowsNoTouchOrCross(configA.initialBlocks)
            )

            // Verify difficulty progression
            val expectedTier = DifficultyTier.forLevel(lvl)
            assertEquals(expectedTier, configA.difficulty)

            // Verify every generated level is 100% solvable
            val solution = BoardManager.findSolutionOrder(
                width = configA.gridWidth,
                height = configA.gridHeight,
                layers = configA.layers,
                blocks = configA.initialBlocks
            )
            assertNotNull("Level $lvl must have a valid solution sequence", solution)
            assertEquals(configA.initialBlocks.size, solution!!.size)
        }
    }

    @Test
    fun `tapping free vs blocked arrows, undo, hints, hearts, game over and level completion work`() {
        // Construct a controlled board where Block 1 (pointing RIGHT) is blocked by Block 2 (pointing UP)
        val block1Blocked = ArrowBlock(
            id = 1,
            cells = listOf(GridPos3D(1, 2, 0), GridPos3D(2, 2, 0)),
            direction = Direction3D.RIGHT,
            colorIndex = 0
        )
        val block2Free = ArrowBlock(
            id = 2,
            cells = listOf(GridPos3D(4, 3, 0), GridPos3D(4, 2, 0)),
            direction = Direction3D.UP,
            colorIndex = 1
        )

        val board = gameManager.boardManager
        board.loadBoard(6, 6, 1, listOf(block1Blocked, block2Free))

        // Block 1 path is blocked by Block 2 at (4, 2, 0)
        val check1 = board.checkBlockPath(1)
        assertTrue(check1 is PathCheckResult.BlockedByPath)
        assertEquals(2, (check1 as PathCheckResult.BlockedByPath).blockingBlockId)

        // Block 2 path UP is completely clear
        val check2 = board.checkBlockPath(2)
        assertTrue(check2 is PathCheckResult.Clear)

        // Start level 1 in GameManager and verify full gameplay loop
        gameManager.startLevel(1)
        val initialCount = gameManager.uiState.value.remainingBlockCount
        assertTrue(initialCount > 0)
        assertEquals(3, gameManager.uiState.value.hearts)

        // Use hint -> highlights a movable block
        gameManager.useHint()
        composeTestRule.waitForIdle()
        val hintedId = gameManager.uiState.value.activeHintBlockId
        assertNotNull(hintedId)

        // Tap the hinted (free) block -> removes it without losing a heart
        gameManager.onBlockTapped(hintedId!!)
        assertEquals(initialCount - 1, gameManager.uiState.value.remainingBlockCount)
        assertEquals(3, gameManager.uiState.value.hearts)
        assertTrue(gameManager.uiState.value.canUndo)

        // Undo -> restores the removed block
        gameManager.undoLastMove()
        assertEquals(initialCount, gameManager.uiState.value.remainingBlockCount)
        assertFalse(gameManager.uiState.value.canUndo)

        // Clear the entire board using movable blocks to verify Level Complete
        var safetyCounter = 0
        while (!gameManager.uiState.value.isLevelComplete && safetyCounter < 200) {
            val movable = gameManager.boardManager.getMovableBlocks()
            assertTrue("Board must always have a movable block", movable.isNotEmpty())
            gameManager.onBlockTapped(movable.first().id)
            safetyCounter++
        }

        assertTrue(gameManager.uiState.value.isLevelComplete)
        assertEquals(0, gameManager.uiState.value.remainingBlockCount)
    }

    @Test
    fun `main menu, navigation, gameplay HUD, pause and level select UI interactions`() {
        composeTestRule.waitForIdle()

        // Main Menu should display Play and Level Select buttons
        composeTestRule.onNodeWithTag("play_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("level_select_button").performScrollTo().assertIsDisplayed()

        // Navigate to Level Select and back
        composeTestRule.onNodeWithTag("level_select_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("level_select_grid").assertIsDisplayed()
        composeTestRule.onNodeWithTag("level_select_back_button").performClick()
        composeTestRule.waitForIdle()

        // Start Gameplay from Play button
        composeTestRule.onNodeWithTag("play_button").performClick()
        composeTestRule.waitForIdle()

        // Verify HUD elements are displayed
        composeTestRule.onNodeWithTag("hud_level_title").assertIsDisplayed()
        composeTestRule.onNodeWithTag("remaining_arrows_badge").assertIsDisplayed()
        composeTestRule.onNodeWithTag("hearts_display").assertIsDisplayed()
        composeTestRule.onNodeWithTag("hint_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("board_3d_canvas").assertIsDisplayed()

        // Test Pause overlay
        composeTestRule.onNodeWithTag("hud_pause_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("pause_overlay").assertIsDisplayed()
        composeTestRule.onNodeWithTag("resume_button").performClick()
        composeTestRule.waitForIdle()
    }

    @Test
    fun `save and load progress persists across sessions`() = runBlocking {
        val initialState = saveManager.getOrCreatePlayerState()
        assertEquals(1, initialState.currentLevel)

        progressManager.recordLevelCompleted(
            levelNumber = 1,
            starsEarned = 3,
            scoreEarned = 450,
            coinsEarned = 55
        )

        val updatedState = saveManager.getOrCreatePlayerState()
        assertEquals(2, updatedState.currentLevel)
        assertEquals(2, updatedState.highestUnlockedLevel)
        assertEquals(155, updatedState.coins)

        val completedMap = progressManager.getCompletedMap()
        assertTrue(completedMap[1]?.completed == true)
        assertEquals(3, completedMap[1]?.stars)
    }

    @Test
    fun `authentication validation and admin email authorization work correctly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val authManager = com.example.data.FirebaseAuthProfileManager(context)

        // Verify strict Admin email check for pawantailor3333@gmail.com
        assertTrue(com.example.data.FirebaseAuthProfileManager.isEmailAdmin("pawantailor3333@gmail.com"))
        assertTrue(com.example.data.FirebaseAuthProfileManager.isEmailAdmin("  PAWANTAILOR3333@GMAIL.COM "))
        assertFalse(com.example.data.FirebaseAuthProfileManager.isEmailAdmin("normaluser@gmail.com"))
        assertFalse(com.example.data.FirebaseAuthProfileManager.isEmailAdmin(""))
        assertFalse(com.example.data.FirebaseAuthProfileManager.isEmailAdmin(null))

        // Verify Login validation catches empty email
        authManager.signInWithEmail("", "password123")
        val stateAfterEmptyEmail = authManager.authState.value as com.example.data.AuthUiState.Unauthenticated
        assertNotNull(stateAfterEmptyEmail.errorMessage)

        // Verify Sign Up validation catches mismatched passwords and short passwords
        authManager.signUpWithEmail("Test Player", "player@example.com", "secret123", "different123")
        val stateAfterMismatch = authManager.authState.value as com.example.data.AuthUiState.Unauthenticated
        assertEquals(com.example.data.AuthScreenMode.SIGNUP, stateAfterMismatch.mode)
        assertTrue(stateAfterMismatch.errorMessage?.contains("match", ignoreCase = true) == true)
    }

    @Test
    fun `level completion awards 20 coins once per level and prevents duplicate replay rewards`() {
        var profileCoins = 0L
        val profileRewarded = mutableSetOf<Int>()

        gameManager.onAuthenticatedLevelCompleted = { lvl ->
            if (profileRewarded.contains(lvl)) {
                0
            } else {
                profileRewarded.add(lvl)
                profileCoins += 20L
                20
            }
        }

        // Bind User A (starts with 0 coins, 0 completed levels) -> opens Level 1 directly
        gameManager.bindAuthenticatedProfile(
            uid = "user_a_uid",
            coins = profileCoins,
            rewardedLevelIds = profileRewarded
        )
        assertEquals(1, gameManager.uiState.value.currentLevelNumber)
        assertEquals(0, gameManager.uiState.value.coins)

        // Complete Level 1 -> +20 coins (total 20, completedLevels = 1)
        var safety = 0
        while (!gameManager.uiState.value.isLevelComplete && safety < 200) {
            val movable = gameManager.boardManager.getMovableBlocks()
            gameManager.onBlockTapped(movable.first().id)
            safety++
        }
        assertTrue(gameManager.uiState.value.isLevelComplete)
        assertEquals(20, gameManager.uiState.value.coinsEarnedThisLevel)
        assertEquals(20, gameManager.uiState.value.coins)
        assertEquals(20L, profileCoins)
        assertEquals(1, profileRewarded.size)

        // Replay Level 1 -> 0 extra coins (total remains 20, completedLevels remains 1)
        gameManager.startLevel(1)
        safety = 0
        while (!gameManager.uiState.value.isLevelComplete && safety < 200) {
            val movable = gameManager.boardManager.getMovableBlocks()
            gameManager.onBlockTapped(movable.first().id)
            safety++
        }
        assertTrue(gameManager.uiState.value.isLevelComplete)
        assertEquals(0, gameManager.uiState.value.coinsEarnedThisLevel)
        assertEquals(20, gameManager.uiState.value.coins)
        assertEquals(20L, profileCoins)
        assertEquals(1, profileRewarded.size)

        // Complete Level 2 -> +20 coins (total becomes 40, completedLevels becomes 2)
        gameManager.startLevel(2)
        safety = 0
        while (!gameManager.uiState.value.isLevelComplete && safety < 200) {
            val movable = gameManager.boardManager.getMovableBlocks()
            gameManager.onBlockTapped(movable.first().id)
            safety++
        }
        assertTrue(gameManager.uiState.value.isLevelComplete)
        assertEquals(20, gameManager.uiState.value.coinsEarnedThisLevel)
        assertEquals(40, gameManager.uiState.value.coins)
        assertEquals(40L, profileCoins)
        assertEquals(2, profileRewarded.size)

        // Switch to User B -> separate coin balance (0 coins)
        gameManager.bindAuthenticatedProfile(
            uid = "user_b_uid",
            coins = 0L,
            rewardedLevelIds = emptySet()
        )
        assertEquals(0, gameManager.uiState.value.coins)
        assertEquals(0, gameManager.uiState.value.completedLevels.size)
    }

    @Test
    fun `redeem conversion uses 1000 coins equals 10 rupees with fixed 1 rupee charge and deducts no extra coins`() {
        val options = com.example.data.RedeemOption.entries
        assertEquals(5, options.size)

        // Verify all 5 exact redemption options:
        // 1000 Coins → ₹10 → ₹1 charge → User receives ₹9
        assertEquals(1000L, com.example.data.RedeemOption.REDEEM_10.coinsRequired)
        assertEquals(10, com.example.data.RedeemOption.REDEEM_10.redeemValueRupees)
        assertEquals(1, com.example.data.RedeemOption.REDEEM_10.processingChargeRupees)
        assertEquals(9, com.example.data.RedeemOption.REDEEM_10.userReceivesRupees)

        // 2000 Coins → ₹20 → ₹1 charge → User receives ₹19
        assertEquals(2000L, com.example.data.RedeemOption.REDEEM_20.coinsRequired)
        assertEquals(20, com.example.data.RedeemOption.REDEEM_20.redeemValueRupees)
        assertEquals(1, com.example.data.RedeemOption.REDEEM_20.processingChargeRupees)
        assertEquals(19, com.example.data.RedeemOption.REDEEM_20.userReceivesRupees)

        // 5000 Coins → ₹50 → ₹1 charge → User receives ₹49
        assertEquals(5000L, com.example.data.RedeemOption.REDEEM_50.coinsRequired)
        assertEquals(50, com.example.data.RedeemOption.REDEEM_50.redeemValueRupees)
        assertEquals(1, com.example.data.RedeemOption.REDEEM_50.processingChargeRupees)
        assertEquals(49, com.example.data.RedeemOption.REDEEM_50.userReceivesRupees)

        // 10000 Coins → ₹100 → ₹1 charge → User receives ₹99
        assertEquals(10000L, com.example.data.RedeemOption.REDEEM_100.coinsRequired)
        assertEquals(100, com.example.data.RedeemOption.REDEEM_100.redeemValueRupees)
        assertEquals(1, com.example.data.RedeemOption.REDEEM_100.processingChargeRupees)
        assertEquals(99, com.example.data.RedeemOption.REDEEM_100.userReceivesRupees)

        // 35000 Coins → ₹350 → ₹1 charge → User receives ₹349
        assertEquals(35000L, com.example.data.RedeemOption.REDEEM_350.coinsRequired)
        assertEquals(350, com.example.data.RedeemOption.REDEEM_350.redeemValueRupees)
        assertEquals(1, com.example.data.RedeemOption.REDEEM_350.processingChargeRupees)
        assertEquals(349, com.example.data.RedeemOption.REDEEM_350.userReceivesRupees)
    }

    @Test
    fun `existing user session and re-login restores coins completed levels and next playable level without duplicating rewards`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val existingUid = "firebase_uid_existing_player_123"

        // Simulate TEST 1: User completes 3 levels -> Coins = 60, Completed levels = 3, Next level = Level 4
        var persistedCoins = 0L
        var persistedCompletedLevels = 0L
        val persistedRewardedLevels = mutableSetOf<Int>()

        gameManager.onAuthenticatedLevelCompleted = { lvl ->
            if (persistedRewardedLevels.contains(lvl)) {
                0
            } else {
                persistedRewardedLevels.add(lvl)
                persistedCompletedLevels = maxOf(persistedCompletedLevels, persistedRewardedLevels.size.toLong())
                persistedCoins += 20L
                20
            }
        }

        gameManager.bindAuthenticatedProfile(
            uid = existingUid,
            coins = persistedCoins,
            completedLevelsCount = persistedCompletedLevels,
            rewardedLevelIds = persistedRewardedLevels
        )
        assertEquals(1, gameManager.uiState.value.currentLevelNumber)
        assertEquals(0, gameManager.uiState.value.coins)

        // Complete Levels 1, 2, and 3
        for (expectedLevel in 1..3) {
            if (gameManager.uiState.value.currentLevelNumber != expectedLevel) {
                gameManager.startLevel(expectedLevel)
            }
            var safety = 0
            while (!gameManager.uiState.value.isLevelComplete && safety < 250) {
                val movable = gameManager.boardManager.getMovableBlocks()
                gameManager.onBlockTapped(movable.first().id)
                safety++
            }
            assertTrue("Level $expectedLevel should be completed", gameManager.uiState.value.isLevelComplete)
            assertEquals(20, gameManager.uiState.value.coinsEarnedThisLevel)
        }

        assertEquals(60L, persistedCoins)
        assertEquals(3L, persistedCompletedLevels)
        assertEquals(setOf(1, 2, 3), persistedRewardedLevels)
        assertEquals(60, gameManager.uiState.value.coins)
        assertEquals(3, gameManager.uiState.value.completedLevels.size)
        assertEquals(4, gameManager.uiState.value.highestUnlockedLevel)

        // Simulate TEST 2 & TEST 3: App close/reload or logout + re-login with the SAME email/UID
        // Even if a fresh GameManager instance starts with default local state (Level 1, 0 coins),
        // binding the restored Firestore profile must restore Coins = 60, Completed = 3, Next playable level = Level 4.
        val freshDb = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val freshSaveManager = SaveManager(freshDb.gameDao())
        val freshProgressManager = ProgressManager(freshDb.gameDao(), freshSaveManager)
        val freshGameManager = GameManager(
            saveManager = freshSaveManager,
            progressManager = freshProgressManager,
            audioManager = AudioManager(null)
        )

        freshGameManager.onAuthenticatedLevelCompleted = gameManager.onAuthenticatedLevelCompleted

        // Bind restored profile for the same authenticated user
        freshGameManager.bindAuthenticatedProfile(
            uid = existingUid,
            coins = persistedCoins,
            completedLevelsCount = persistedCompletedLevels,
            rewardedLevelIds = persistedRewardedLevels
        )

        // Expected after reopen / re-login:
        // Coins = 60, Completed levels = 3 (Levels 1, 2, 3), Next playable level = Level 4 (NOT Level 1 or 0 Coins)
        assertEquals(60, freshGameManager.uiState.value.coins)
        assertEquals(3, freshGameManager.uiState.value.completedLevels.size)
        assertTrue(freshGameManager.uiState.value.completedLevels.containsKey(1))
        assertTrue(freshGameManager.uiState.value.completedLevels.containsKey(2))
        assertTrue(freshGameManager.uiState.value.completedLevels.containsKey(3))
        assertEquals(4, freshGameManager.uiState.value.highestUnlockedLevel)
        assertEquals(4, freshGameManager.uiState.value.currentLevelNumber)

        // Simulate TEST 4: Replaying previously rewarded levels (1, 2, or 3) must NOT give another +20 coins
        freshGameManager.selectLevelFromMap(1)
        assertEquals(1, freshGameManager.uiState.value.currentLevelNumber)
        var replaySafety = 0
        while (!freshGameManager.uiState.value.isLevelComplete && replaySafety < 250) {
            val movable = freshGameManager.boardManager.getMovableBlocks()
            freshGameManager.onBlockTapped(movable.first().id)
            replaySafety++
        }
        assertTrue(freshGameManager.uiState.value.isLevelComplete)
        assertEquals(0, freshGameManager.uiState.value.coinsEarnedThisLevel)
        assertEquals(60, freshGameManager.uiState.value.coins)
        assertEquals(60L, persistedCoins)

        freshDb.close()
    }
}
